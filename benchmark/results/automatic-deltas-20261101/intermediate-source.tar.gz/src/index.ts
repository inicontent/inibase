import "dotenv/config";
import { AsyncLocalStorage } from "node:async_hooks";
import { randomBytes, randomUUID, scryptSync } from "node:crypto";
import { appendFileSync, existsSync, readFileSync } from "node:fs";
import {
	copyFile,
	glob,
	mkdir,
	readdir,
	readFile,
	rename,
	rm,
	stat,
	unlink,
	writeFile,
} from "node:fs/promises";
import { basename, join, parse, resolve } from "node:path";
import { inspect } from "node:util";
import Inison from "inison";
import { observeEqualityScan } from "./automatic.js";
import {
	type BinaryOp,
	buildFieldIndex,
	type CompiledExpressionNode,
	type ComputedFieldSpec,
	type ComputedFunctionName,
	collectFieldDeps,
	type FieldRef,
	parseExpression,
	type ResolveContext,
	resolveExpression,
	resolveFramePath,
	topoSortComputedFields,
} from "./expression.js";
import * as File from "./file.js";
import {
	FORMAT_FILE,
	readFormat,
	serializeFormat,
	type TableFormat,
	unsupportedFormatReason,
	writeFormat,
} from "./format.js";
import { DatabaseJournal, Journal, type JournalFileOp } from "./journal.js";
import { lookupLines, prepareKeyIndex } from "./key-index.js";
import { TableOverlay } from "./overlay.js";
import {
	type DatabaseResources,
	registerDatabase,
	releaseDatabase,
} from "./resources.js";
import { DEFAULT_BLOCK_BYTES, prepareSeekable } from "./seek.js";
import {
	buildFrames,
	DEFAULT_MAX_FRAME_BYTES,
	UPDATES_LOG_NAME,
	type UpdateRecord,
} from "./updatelog.js";
import * as Utils from "./utils.js";
import * as UtilsServer from "./utils.server.js";

/**
 * Default accumulation bounds for a format-2 table. Before each append the
 * writer compacts when the log would exceed `maxLogBytes()` bytes or the
 * overlay would exceed `maxOverlayRecords()` distinct rows; the log resets to
 * empty on compaction, so these bound *between* compactions, not total writes.
 * Both are overridable per deployment via environment for large tables.
 */
const maxLogBytes = () =>
	Number(process.env.INIBASE_MAX_LOG_BYTES) || 64 * 1024 * 1024;
const maxOverlayRecords = () =>
	Number(process.env.INIBASE_MAX_OVERLAY_RECORDS) || 100_000;

export interface Data {
	id?: string | number;
	[key: string]: any;
	createdAt?: number;
	updatedAt?: number;
}

export type FieldType =
	| "string"
	| "number"
	| "boolean"
	| "date"
	| "email"
	| "url"
	| "table"
	| "object"
	| "array"
	| "password"
	| "html"
	| "ip"
	| "json"
	| "id";

export type Field = {
	id?: number;
	key: string;
	type: FieldType | FieldType[];
	required?: boolean;
	table?: string;
	unique?: boolean | number | string;
	children?: FieldType | FieldType[] | Schema;
	regex?: string;
	/** Computed-fields expression (see the README). Either a raw expression
	 *  string, or the persisted `{ expr, ast }` spec written by Inibase once
	 *  the expression has been compiled. */
	computed?: string | ComputedFieldSpec;
};

export type Schema = Field[];

export interface Options {
	page?: number;
	perPage?: number;
	columns?: string[] | string;
	sort?:
		| Record<string, 1 | -1 | "asc" | "ASC" | "desc" | "DESC">
		| string[]
		| string;
}

/** Options for the aggregate actions (`sum`, and later avg/min/max). */
export interface AggregateOptions {
	/**
	 * Aggregate over the *elements* of an array-of-objects column instead of
	 * whole rows. The summed columns must be single-level child paths of the
	 * same array root (e.g. `"items.quantity"`); `where` keys that resolve as
	 * children of that root become per-element predicates.
	 */
	nested?: boolean;
}

export interface TableConfig {
	compression?: boolean;
	cache?: boolean;
	prepend?: boolean;
	decodeID?: boolean;
}

/** Persisted compatibility state; not application table options. */
interface StoredTableConfig extends TableConfig {
	/**
	 * Opt a table into the incremental update log (format 2): `put` appends a
	 * small frame instead of rewriting whole columns, and reads merge the log
	 * over the base columns. Requires a schema of simple top-level fields and
	 * is incompatible with `prepend`, transactions and DDL on the table
	 * (those need compaction, shipped in 3.9).
	 */
	log?: boolean;
	/** Opt-in format-3 durable deletes; requires log and append layout. */
	tombstones?: boolean;
	/** Opt-in independently seekable, legacy-readable column blocks. */
	seekable?: boolean;
	/** Application-key equality indexes. Internal IDs are indexed automatically. */
	indexes?: string[];
	/** Uncompressed block bytes: 65536, 131072 (default), or 262144. */
	blockBytes?: number;
}

interface SeekConfig {
	v: 1;
	blockBytes: number;
	indexes: string[];
}

export interface TableObject {
	schema?: Schema;
	config: TableConfig;
}

interface StoredTableObject {
	schema?: Schema;
	config: StoredTableConfig;
}

/**
 * Per-table state maintained while a database transaction is open: the writer
 * lock is held for the whole transaction, pagination state is staged in
 * memory (the live files only change at commit()), and `staged` collects the
 * journaled ops that commit() publishes (one per table per transaction).
 */
export interface TxnTableEntry {
	locked: boolean;
	/** Live pagination path the first staged op builds on. */
	paginationFrom: string;
	/** Staged last-id / row count (chained across ops in the txn). */
	lastId: number;
	total: number;
	staged: {
		ops: JournalFileOp[];
		pagination: { from: string; to: string } | null;
	}[];
}

export type ComparisonOperator =
	| "="
	| "!="
	| ">"
	| "<"
	| ">="
	| "<="
	| "*"
	| "!*"
	| "[]"
	| "![]";

export type pageInfo = {
	total?: number;
	totalPages?: number;
} & Options;

export type Criteria =
	| ({
			[logic in "and" | "or"]?: Criteria | (string | number | boolean | null)[];
	  } & {
			[key: string]:
				| string
				| number
				| boolean
				| undefined
				| Criteria
				| (string | number | boolean)[];
	  })
	| null;

type Entries<T> = {
	[K in keyof T]: [K, T[K]];
}[keyof T][];

declare global {
	interface ObjectConstructor {
		entries<T extends object>(o: T): Entries<T>;
	}
}

export const ERROR_CODES = [
	"GROUP_UNIQUE",
	"FIELD_UNIQUE",
	"FIELD_REQUIRED",
	"NO_SCHEMA",
	"TABLE_EMPTY",
	"INVALID_ID",
	"INVALID_TYPE",
	"INVALID_PARAMETERS",
	"NO_ENV",
	"TABLE_EXISTS",
	"TABLE_NOT_EXISTS",
	"INVALID_REGEX_MATCH",
	"INVALID_NAME",
	"COMPUTED_FIELD_SYNTAX",
	"COMPUTED_FIELD_UNKNOWN_FIELD",
	"COMPUTED_FIELD_INVALID_LINK",
	"COMPUTED_FIELD_INVALID_TARGET",
	"COMPUTED_FIELD_CONFLICT",
	"COMPUTED_FIELD_CYCLE",
	"COMPUTED_FIELD_SETTABLE",
	"COMPUTED_FIELD_DANGLING_LINK",
	"COMPUTED_FIELD_ARITHMETIC",
	"UPDATE_LOG_CORRUPT",
	"UPDATE_LOG_FRAME_TOO_LARGE",
	"MAINTENANCE_REQUIRED",
	"UNSUPPORTED_FORMAT",
] as const;
export type ErrorCode = (typeof ERROR_CODES)[number];
export type ErrorLang = "en" | "ar" | "fr" | "es";

// hide ExperimentalWarning glob()
// Guard against non-Node environments (e.g. accidental import in a browser bundle)
if (
	typeof process !== "undefined" &&
	typeof process.removeAllListeners === "function"
) {
	process.removeAllListeners("warning");
}

export const globalConfig: {
	[database: string]: {
		tables?: Map<string, StoredTableObject & { timestamp?: Date }>;
	};
} & { salt?: string | Buffer } = {};

/** Topological evaluation plan for a table's computed fields. */
interface ComputedPlan {
	fields: ComputedPlanField[];
	index: Map<number, FieldRef>;
	/** True when any expression contains a link hop (a path with more than
	 *  one segment), i.e. the plan can read rows of other tables. */
	hasHops: boolean;
}

interface ComputedPlanField {
	id: number;
	/** Column path the field flattens to: bare key for top-level computed
	 *  fields, dotted (`items.lineTotal`) for element computed fields. */
	key: string;
	ast: CompiledExpressionNode;
	deps: Set<number>;
	/** Set for computed *children* of an array-of-objects field: the field is
	 *  evaluated per element of that array (frame = element, strip =
	 *  `${root.key}.`), not per row. */
	elementRoot?: { id: number; key: string } | null;
}

/**
 * Values an evaluation pass produces for one line. Element computed fields
 * contribute their per-element array under the dotted column key.
 */
type ComputedLineValues = Record<
	string,
	number | string | null | (number | string | null)[]
>;

/** Per-node evaluation environment (frame-aware). */
interface ComputedEvalEnv {
	/** Table the current frame belongs to. */
	table: string;
	/** Id index of the current frame's table. */
	index: Map<number, FieldRef>;
	/** Structured frame paths resolve against in place: the row being
	 *  written, a raw array element (helper iteration), or a linked row at
	 *  a hop. No flattened copy is ever built (see `resolveFramePath`). */
	frame: Record<string, any>;
	/** Structured row of the table being written (helper iteration). */
	row: Data;
	/** Prefix stripped from ref keys inside array-element frames, else "". */
	strip: string;
	/** Key of the computed field being evaluated (error context). */
	ownKey: string;
	/** Shared cache of linked-table id indexes. */
	indexCache: Map<string, Map<number, FieldRef>>;
	/** Batch-scoped link-hop reader (only during batched evaluation of a
	 *  plan that contains hops). Every read goes through it so each distinct
	 *  (table, column, id) triple resolves once per batch. */
	links?: LinkedRowReader;
	/** Collection pass (batched link evaluation only): link hops record the
	 *  target triple instead of reading, unresolved hops read as null, and
	 *  arithmetic over them is not an error — the pass exists solely to
	 *  discover which linked rows the batch needs. */
	collect?: boolean;
	/** Element computed evaluation: missing (null) operands are read as `0`
	 *  instead of raising `COMPUTED_FIELD_ARITHMETIC`. */
	nullAsZero?: boolean;
}

/**
 * Batch-scoped link-hop reader for computed-field evaluation: a dry pass
 * records every (table, column, id) triple the expressions need, each
 * distinct triple is resolved exactly once by the engine's `readLinkedRow`
 * (deduplicated across rows and fields of the batch), and subsequent passes
 * are served from a warm per-(table, column) cache.
 */
class LinkedRowReader {
	private readonly pending = new Map<string, Set<string | number>>();
	private readonly cache = new Map<string, Map<string | number, Data | null>>();

	constructor(
		private readonly readRow: (
			table: string,
			column: string,
			id: string | number,
		) => Promise<Data | null>,
	) {}

	get hasPending(): boolean {
		return this.pending.size > 0;
	}

	record(table: string, column: string, id: string | number): void {
		const key = `${table}\u0000${column}`;
		let ids = this.pending.get(key);
		if (!ids) {
			ids = new Set();
			this.pending.set(key, ids);
		}
		ids.add(id);
	}

	async read(
		table: string,
		column: string,
		id: string | number,
	): Promise<Data | null> {
		const key = `${table}\u0000${column}`;
		let map = this.cache.get(key);
		if (!map) {
			map = await this.resolve(key, this.pending.get(key) ?? new Set());
			this.pending.delete(key);
			this.cache.set(key, map);
		}
		return (map.get(id) as Data) ?? null;
	}

	/** Resolve every pending bucket now (called between the collection pass
	 *  and the real evaluation pass). */
	async resolveAll(): Promise<void> {
		for (const [key, ids] of this.pending)
			this.cache.set(key, await this.resolve(key, ids));
		this.pending.clear();
	}

	private async resolve(
		key: string,
		ids: Set<string | number>,
	): Promise<Map<string | number, Data | null>> {
		const separator = key.indexOf("\u0000");
		const table = key.slice(0, separator);
		const column = key.slice(separator + 1);
		const map = new Map<string | number, Data | null>();
		// One engine read per distinct triple; the buckets' triples are
		// independent so they resolve concurrently. A missing row caches as
		// null so repeated dangling hops fail once, exactly like a direct
		// readLinkedRow would per hop.
		await Promise.all(
			Array.from(ids).map(async (id) => {
				map.set(id, await this.readRow(table, column, id));
			}),
		);
		return map;
	}
}

/** True when an expression tree contains any link hop (multi-segment path). */
function astHasHops(node: CompiledExpressionNode): boolean {
	switch (node.kind) {
		case "num":
			return false;
		case "path":
			return node.ids.length > 1;
		case "bin":
			return astHasHops(node.left) || astHasHops(node.right);
		case "fn":
			return astHasHops(node.arg);
	}
}

/**
 * Await a batch of column-write promises and surface the first rejection.
 * `Promise.allSettled` never short-circuits, so a swallowed failure would let
 * the caller publish a partial column set — the pagination row count and the
 * column line counts would diverge. Every batch that fills a `renameList` must
 * be inspected through here before the journal/pagination is touched.
 */
async function settleWrites(
	results: PromiseSettledResult<unknown>[],
): Promise<void> {
	const failed = results.find(
		(result): result is PromiseRejectedResult => result.status === "rejected",
	);
	if (failed) throw failed.reason;
}

/**
 * @param {string} database - Database name
 * @param {string} [mainFolder="."] - Main folder path
 * @param {ErrorLang} [language="en"] - Language for error messages
 */
export default class Inibase {
	public pageInfo: Record<string, pageInfo>;
	public language: ErrorLang;
	public fileExtension = ".txt";
	public totalItems: Map<string, number>;
	/** Tracks whether a decodeID table's stored ids are the dense sequence
	 *  1..rowCount (no rows ever deleted). When true, `get`/`put`/`delete` can
	 *  resolve numeric ids to line numbers arithmetically instead of scanning
	 *  the id file. Set false by any partial row deletion. */
	private idDensity = new Map<string, boolean>();
	/** Per-table computed-plan cache (null = table has no computed fields).
	 *  A plan depends only on the table's persisted schema (compiled ASTs are
	 *  id-based and rename-proof), so it is rebuilt only when the schema
	 *  changes: see the invalidation in `getTable`'s reload branch,
	 *  `createTable` and `updateTableLocked`. Bounded by the number of tables. */
	private readonly computedPlanCache = new Map<string, ComputedPlan | null>();
	/** Per-table `.format` marker + live update-log overlays (format 2 tables).
	 *  Keyed by `databasePath\0tableName` so two databases in one process never
	 *  share state. Populated lazily by `getOverlay`. */
	private readonly tableFormats = new Map<string, TableFormat>();
	private readonly overlays = new Map<string, TableOverlay>();
	/** Last observed identity of each table's `.format` file (`mtime:size:ino`),
	 *  used to detect a compaction by another process without re-reading the
	 *  marker on every access. */
	private readonly formatStamps = new Map<string, string>();
	private databasePath: string;
	private resources: DatabaseResources;
	private closed = false;
	private readonly fallbackUniqueMap = new Map<
		string | number,
		{ exclude: Set<number>; columnsValues: Map<number, Set<string | number>> }
	>();
	private readonly uniqueContext = new AsyncLocalStorage<
		typeof this.fallbackUniqueMap
	>();
	private get uniqueMap() {
		return this.uniqueContext.getStore() ?? this.fallbackUniqueMap;
	}
	private schemaFileExtension = process.env.INIBASE_SCHEMA_EXTENSION ?? "json";

	/**
	 * Open database transaction (see begin/commit/rollback). Holds the
	 * database lock (`<db>/.tmp/.locked`) for its whole lifetime and the
	 * per-table writer lock of every table it mutates, so mutations stage into
	 * the database journal and publish only on commit().
	 */
	private activeTransaction: {
		id: string;
		journal: DatabaseJournal;
		tables: Map<string, TxnTableEntry>;
	} | null = null;

	constructor(database: string, mainFolder = ".", language: ErrorLang = "en") {
		this.language = language;

		this.validateName(database);

		this.databasePath = join(mainFolder, database);

		this.pageInfo = {};

		this.totalItems = new Map();

		if (!globalConfig[this.databasePath])
			globalConfig[this.databasePath] = { tables: new Map() };

		if (!process?.env.INIBASE_SECRET) {
			if (
				existsSync(".env") &&
				readFileSync(".env").includes("INIBASE_SECRET=")
			)
				throw this.createError("NO_ENV");
			globalConfig.salt = scryptSync(randomBytes(16), randomBytes(16), 32);
			appendFileSync(
				".env",
				`\nINIBASE_SECRET=${globalConfig.salt.toString("hex")}\n`,
			);
		} else globalConfig.salt = Buffer.from(process.env.INIBASE_SECRET, "hex");
		this.resources = registerDatabase(this.databasePath);
	}

	public createError(
		name: ErrorCode,
		variable?: string | number | (string | number)[],
	): Error {
		return Utils.createError(this.language, name, variable);
	}

	/** Engine-owned cache accounting; caller materialized results and V8 are separate. */
	public memoryUsage() {
		return this.resources.stats();
	}

	/** Release private overlay scratch files and idle reusable descriptors. */
	public async close(): Promise<void> {
		if (this.closed) return;
		if (this.activeTransaction) await this.rollback();
		this.closed = true;
		await this.resources.drainMaintenance();
		for (const overlay of this.overlays.values()) await overlay.dispose();
		this.overlays.clear();
		await releaseDatabase(this.databasePath);
		this.closed = true;
	}

	private validateName(name: string): void {
		Utils.validateName(name, this.language);
	}

	/**
	 * Validates column paths used in the `columns` option.
	 *
	 * Each column may be a nested path of dot-separated names
	 * (e.g. "address.street", "hobbies.name") and may optionally
	 * start with "!" for exclusion. The "*" wildcard (select all)
	 * and its "!*" counterpart are special values and are skipped.
	 * Every segment of a path is validated individually.
	 */
	private validateColumns(columns: string[]): void {
		for (const column of columns) {
			if (column === "*" || column === "!*") continue;

			const path = column.startsWith("!") ? column.slice(1) : column;
			for (const segment of path.split(".")) {
				if (!segment) this.validateName(column);
				else this.validateName(segment);
			}
		}
	}

	private validateSchema(schema: Schema): void {
		Utils.validateSchema(schema, this.language);
	}

	private getFileExtension(tableName: string) {
		let mainExtension = this.fileExtension;
		// TODO: ADD ENCRYPTION
		// if(globalConfig[this.databasePath].tables?.get(tableName)?.config.encryption)
		// 	mainExtension += ".enc"
		if (
			globalConfig[this.databasePath].tables?.get(tableName)?.config.compression
		)
			mainExtension += ".gz";
		return mainExtension;
	}

	private schemaToIdsPath(tableName: string, schema: Schema, prefix = "") {
		const RETURN: any = {};
		for (const field of schema)
			if (
				(field.type === "array" || field.type === "object") &&
				field.children &&
				Utils.isArrayOfObjects(field.children)
			)
				Utils.deepMerge(
					RETURN,
					this.schemaToIdsPath(
						tableName,
						field.children,
						`${(prefix ?? "") + field.key}.`,
					),
				);
			else if (field.id)
				RETURN[field.id] =
					`${(prefix ?? "") + field.key}${this.getFileExtension(tableName)}`;

		return RETURN;
	}

	/**
	 * Create a new table inside database, with predefined schema and config
	 *
	 * @param {string} tableName
	 * @param {Schema} [schema]
	 * @param {StoredTableConfig} [config]
	 */
	public async createTable(
		tableName: string,
		schema?: Schema,
		config?: TableConfig,
	) {
		return File.runWithLockStore(() =>
			this._createTable(tableName, schema, config),
		);
	}

	private async _createTable(
		tableName: string,
		schema?: Schema,
		config?: StoredTableConfig,
	) {
		this.validateName(tableName);

		// DDL does not participate in the write-ahead journal: schema surgery
		// inside a transaction would escape the atomic publish/rollback scope.
		if (this.activeTransaction) throw this.createError("INVALID_PARAMETERS");
		await this.ensureDatabaseRecovered();

		if (schema) this.validateSchema(schema);

		const tablePath = join(this.databasePath, tableName);

		if (await File.isExists(tablePath))
			throw this.createError("TABLE_EXISTS", tableName);

		await mkdir(join(tablePath, ".tmp"), { recursive: true });
		await mkdir(join(tablePath, ".cache"));

		// if config not set => load default global env config
		if (!config)
			config = {
				compression: process.env.INIBASE_COMPRESSION === "true",
				cache: process.env.INIBASE_CACHE === "true",
				prepend: process.env.INIBASE_PREPEND === "true",
				decodeID: process.env.INIBASE_ENCODEID === "true",
			};

		if (config) {
			if (config.tombstones && !config.log)
				throw this.createError("INVALID_PARAMETERS", "tombstones requires log");
			if (config.seekable || config.indexes?.length) {
				const seek = this.seekConfig(config);
				for (const key of seek.indexes) {
					this.validateColumns([key]);
					if (
						!schema?.some(
							(field) => field.key === key && this.isSimpleField(field.type),
						)
					)
						throw this.createError("INVALID_PARAMETERS", `index ${key}`);
				}
				await File.write(join(tablePath, ".seek.config"), JSON.stringify(seek));
			}
			if (config.compression)
				await File.write(join(tablePath, ".compression.config"), "");
			if (config.cache) await File.write(join(tablePath, ".cache.config"), "");
			if (config.prepend)
				await File.write(join(tablePath, ".prepend.config"), "");
			if (config.decodeID)
				await File.write(join(tablePath, ".decodeID.config"), "");
			if (config.log) {
				if (config.prepend)
					throw this.createError(
						"UNSUPPORTED_FORMAT",
						"append layout (no prepend)",
					);
				if (schema) this.assertLogCompatibleSchema(schema);
				// Publish the marker before the log: a missing log reads as an
				// empty log, whereas a log without a marker would be legacy.
				await writeFormat(tablePath, {
					format: config.tombstones ? 3 : 2,
					log: true,
					baseGen: 0,
					...(config.tombstones ? { tombstones: true } : {}),
				});
				await File.write(join(tablePath, UPDATES_LOG_NAME), "");
				this.tableFormats.set(tableName, {
					format: config.tombstones ? 3 : 2,
					log: true,
					baseGen: 0,
					...(config.tombstones ? { tombstones: true } : {}),
				});
			}
		}
		if (schema) {
			const lastSchemaID = { value: 0 };
			// Compile computed expressions only after ids are assigned (the
			// persisted AST carries ids, making it rename-proof), and before
			// the schema is written so a bad expression never lands on disk.
			schema = await this.compileComputedFields(
				Utils.addIdToSchema(schema, lastSchemaID),
			);
			await File.write(
				join(tablePath, `schema.${this.schemaFileExtension}`),
				this.schemaFileExtension === "json"
					? JSON.stringify(schema, null, 2)
					: Inison.stringify(schema),
			);
			await File.write(join(tablePath, `${lastSchemaID.value}.schema`), "");
		} else await File.write(join(tablePath, "0.schema"), "");

		await File.write(join(tablePath, "0-0.pagination"), "");

		// Make the new table's metadata durable before acknowledging creation.
		await File.syncDir(tablePath);
		await File.syncDir(join(tablePath, ".tmp"));

		this.idDensity.set(tableName, true);

		// Defensive: a table of the same name may have had a cached plan from
		// before a delete+recreate.
		this.computedPlanCache.delete(tableName);
	}

	// Function to replace the string in one schema file
	private async replaceStringInFile(
		filePath: string,
		targetString: string,
		replaceString: string,
	) {
		const data = await readFile(filePath, "utf8");

		if (data.includes(targetString)) {
			const updatedContent = data.replaceAll(targetString, replaceString);
			// File.write fsyncs the replacement so a link-update after a table
			// rename survives a crash.
			await File.write(filePath, updatedContent);
		}
	}

	/**
	 * Update table schema or config
	 *
	 * @param {string} tableName
	 * @param {Schema} [schema]
	 * @param {(StoredTableConfig&{name?: string})} [config]
	 */
	public async updateTable(
		tableName: string,
		schema?: Schema,
		config?: TableConfig & { name?: string },
	) {
		return File.runWithLockStore(() =>
			this._updateTable(tableName, schema, config),
		);
	}

	private async _updateTable(
		tableName: string,
		schema?: Schema,
		config?: StoredTableConfig & { name?: string },
	) {
		this.validateName(tableName);

		// DDL does not participate in the write-ahead journal: schema surgery
		// inside a transaction would escape the atomic publish/rollback scope.
		if (this.activeTransaction) throw this.createError("INVALID_PARAMETERS");
		await this.ensureDatabaseRecovered();

		if (config?.name) this.validateName(config.name);

		const table = await this.loadTable(tableName);
		if (!table) return;
		const tablePath = join(this.databasePath, tableName);

		// DDL is serialized with DML writers on the same per-table lock, so a
		// post/put/delete can never interleave with schema/file surgery.
		try {
			await File.lock(join(tablePath, ".tmp"));
			await this.updateTableLocked(tableName, table, tablePath, schema, config);
		} finally {
			await File.unlock(join(tablePath, ".tmp"));
			// Renaming the table moves its .tmp (and with it the lock file)
			// to the new directory, so the unlock above only released the old
			// path. Release the lock at its new location too, or the renamed
			// table is left with a perpetual live-owner lock no writer can
			// steal.
			if (config?.name && config.name !== tableName)
				await File.unlock(join(join(this.databasePath, config.name), ".tmp"));
		}
	}

	private async updateTableLocked(
		tableName: string,
		table: StoredTableObject,
		tablePath: string,
		schema?: Schema,
		config?: StoredTableConfig & { name?: string },
	) {
		await this.leaveAutomaticDeltas(tableName);
		// A log table cannot be reshaped in place yet: its log frames reference
		// column names and its overlay would have to be materialised into the
		// base columns first (compaction, 3.9). Rename/other config are fine.
		if (this.isLogTable(tableName)) {
			if (schema)
				throw this.createError(
					"MAINTENANCE_REQUIRED",
					`${tableName} (schema change on update-log table)`,
				);
			if (config?.prepend)
				throw this.createError(
					"MAINTENANCE_REQUIRED",
					`${tableName} (prepend layout on update-log table)`,
				);
			if (config?.log === false)
				throw this.createError(
					"MAINTENANCE_REQUIRED",
					`${tableName} (disabling the update log needs compaction)`,
				);
		} else if (config?.log) {
			if (config.prepend || table.config.prepend)
				throw this.createError(
					"UNSUPPORTED_FORMAT",
					"append layout (no prepend)",
				);
			if (table.schema?.length) this.assertLogCompatibleSchema(table.schema);
			// Durable migration (§9): publish the marker durably and atomically
			// *before* the table is treated as log-format. Format 2 shares the
			// format-1 base layout, so no column rewrite is needed. A missing
			// `updates.log` reads as an empty log, so creating it after the
			// marker is safe.
			try {
				await writeFormat(tablePath, {
					format: config.tombstones ? 3 : 2,
					log: true,
					baseGen: 0,
					...(config.tombstones ? { tombstones: true } : {}),
				});
				await File.write(join(tablePath, UPDATES_LOG_NAME), "");
				await File.syncDir(tablePath);
			} catch (error) {
				// Re-read the marker to decide: if it never became visible the
				// table is unchanged and must stay legacy; if it did become
				// visible, keep treating it as log-format rather than writing
				// through the legacy path over a log-format table.
				const landed = await readFormat(tablePath);
				if (!landed.log) this.tableFormats.delete(tableName);
				else this.tableFormats.set(tableName, landed);
				throw error;
			}
			this.tableFormats.set(tableName, {
				format: config.tombstones ? 3 : 2,
				log: true,
				baseGen: 0,
				...(config.tombstones ? { tombstones: true } : {}),
			});
		}
		if (table.config.tombstones && config?.tombstones === false)
			throw this.createError("MAINTENANCE_REQUIRED", "disabling tombstones");
		if (config?.tombstones && !table.config.tombstones) {
			const format = await this.currentFormat(tableName);
			if (!format?.log)
				throw this.createError("INVALID_PARAMETERS", "tombstones requires log");
			await writeFormat(tablePath, { ...format, format: 3, tombstones: true });
		}

		if (schema) {
			this.validateSchema(schema);
			// remove id from schema
			schema = schema.filter(
				({ key }) => !["id", "createdAt", "updatedAt"].includes(key),
			);

			let schemaIdFilePath: string = "";
			for await (const fileName of glob("*.schema", { cwd: tablePath }))
				schemaIdFilePath = join(tablePath, fileName);

			const lastSchemaID = {
				value: schemaIdFilePath ? Number(parse(schemaIdFilePath).name) : 0,
			};

			schema = Utils.addIdToSchema(schema, lastSchemaID);

			// Compile computed expressions now that ids are assigned (the
			// persisted AST only stores ids, so later renames never retarget
			// an expression). Compilation happens before any file surgery so
			// a bad expression aborts the migration cleanly.
			schema = await this.compileComputedFields(schema);

			// Row count is needed for the computed backfill below, so read the
			// pagination before the schema is rewritten.
			let totalLines = 0;
			for await (const paginationFileName of glob("*.pagination", {
				cwd: tablePath,
			}))
				totalLines = parse(paginationFileName).name.split("-").map(Number)[1];

			// if schema file exists, update columns files names based on field id
			if (
				(await File.isExists(
					join(tablePath, `schema.${this.schemaFileExtension}`),
				)) &&
				table.schema?.length
			) {
				const replaceOldPathes = Utils.findChangedProperties(
					this.schemaToIdsPath(
						tableName,
						table.schema.filter(
							({ key }) => !["createdAt", "updatedAt"].includes(key),
						),
					),
					this.schemaToIdsPath(tableName, schema),
				);
				if (replaceOldPathes)
					await Promise.allSettled(
						Object.entries(replaceOldPathes).map(async ([oldPath, newPath]) => {
							if (await File.isExists(join(tablePath, oldPath))) {
								// if newPath is null, it means the field was removed
								if (newPath === null) await unlink(join(tablePath, oldPath));
								else
									await rename(
										join(tablePath, oldPath),
										join(tablePath, newPath),
									);
							}
						}),
					);
			}

			// Computed-field backfill: a computed expression that is added or
			// changed by this migration must be (re)derived for every existing
			// row. Evaluation happens BEFORE the schema is rewritten, so a
			// failed migration (dangling link, arithmetic error, unknown
			// field, ...) leaves the old schema and column values untouched.
			const oldComputed = new Map(
				this.computedEntries(table.schema ?? []).map(({ key, expr }) => [
					key,
					expr,
				]),
			);
			const changedComputedKeys = new Set(
				totalLines > 0
					? this.computedEntries(schema)
							.filter(({ key, expr }) => oldComputed.get(key) !== expr)
							.map(({ key }) => key)
					: [],
			);
			const backfillReplacers = changedComputedKeys.size
				? await (async () => {
						const plan = await this.buildComputedPlan(tableName, schema);
						if (!plan) return undefined;
						const lineNumbers = Array.from(
							{ length: totalLines },
							(_, index) => index + 1,
						);
						const existing = await this.processSchemaData<Data>(
							tableName,
							schema.filter((field) => typeof field.computed === "undefined"),
							lineNumbers,
						);
						return this.evaluateComputedRows(tableName, plan, existing);
					})()
				: undefined;

			// Publish the backfilled values before the schema write.
			if (backfillReplacers) {
				const backfillRenameList: (string | null)[][] = [];
				for (const key of changedComputedKeys) {
					const lines: Record<number, string | number | boolean | null> = {};
					for (const [line, values] of Object.entries(backfillReplacers))
						if (Object.hasOwn(values, key))
							lines[Number(line)] = File.encode(values[key]);
					if (!Object.keys(lines).length) continue;
					backfillRenameList.push(
						await File.replace(
							join(tablePath, `${key}${this.getFileExtension(tableName)}`),
							lines,
						),
					);
				}
				for (const [tmp, live] of backfillRenameList)
					if (tmp && live) await rename(tmp, live);
			}

			// Data-bearing schema writes go through File.write so they are
			// fsynced before updateTable returns.
			await File.write(
				join(tablePath, `schema.${this.schemaFileExtension}`),
				this.schemaFileExtension === "json"
					? JSON.stringify(schema, null, 2)
					: Inison.stringify(schema),
			);
			if (schemaIdFilePath)
				await rename(
					schemaIdFilePath,
					join(tablePath, `${lastSchemaID.value}.schema`),
				);
			else
				await File.write(join(tablePath, `${lastSchemaID.value}.schema`), "");

			// Fields added by this migration have no backing file yet. If the
			// first post after the migration writes such a file from scratch it
			// starts at line 1 and every existing row becomes misaligned (the
			// new value lands on the wrong record). Materialize missing column
			// files padded with one empty line per existing row so appends keep
			// line-aligned with the other column files (decode("") is
			// undefined/null, matching the "no value yet" semantics).
			await Promise.allSettled(
				schema.map(async ({ key }) => {
					const filePath = join(
						tablePath,
						`${key}${this.getFileExtension(tableName)}`,
					);
					if (!(await File.isExists(filePath)))
						await File.write(filePath, "\n".repeat(totalLines));
				}),
			);
		}

		if (config) {
			if (
				config.compression !== undefined &&
				config.compression !== table.config.compression
			) {
				// Toggle compression crash-safely: the shell only decompresses
				// to a temp file (streamed), the publish step fsyncs each temp
				// before renaming it over the original, then the config marker
				// is fsynced. A crash mid-toggle leaves valid (uncompressed or
				// compressed) files, never a truncated one.
				const toggleFiles = (await readdir(tablePath)).filter((name) =>
					config.compression
						? name.endsWith(this.fileExtension) &&
							!name.endsWith(`${this.fileExtension}.gz`)
						: name.endsWith(`${this.fileExtension}.gz`),
				);
				for (const name of toggleFiles) {
					const src = join(tablePath, name);
					const tmp = `${src}.recompressed`;
					const target = config.compression ? `${src}.gz` : src.slice(0, -3); // strip ".gz"
					await UtilsServer.exec(
						`${config.compression ? "gzip" : "gunzip"} -c ${File.escapeShellPath(src)} > ${File.escapeShellPath(tmp)}`,
					);
					await File.syncFile(tmp);
					await rename(tmp, target);
				}
				if (config.compression)
					await File.write(join(tablePath, ".compression.config"), "");
				else await unlink(join(tablePath, ".compression.config"));
			}
			if (config.cache !== undefined && config.cache !== table.config.cache) {
				if (config.cache)
					await File.write(join(tablePath, ".cache.config"), "");
				else {
					await this.clearCache(tableName);
					await unlink(join(tablePath, ".cache.config"));
				}
			}
			if (
				config.decodeID !== undefined &&
				config.decodeID !== table.config.decodeID
			) {
				if (config.decodeID)
					await File.write(join(tablePath, ".decodeID.config"), "");
				else await unlink(join(tablePath, ".decodeID.config"));
			}
			if (
				config.prepend !== undefined &&
				config.prepend !== table.config.prepend
			) {
				// Reverse every column file so the "first" row stays first after
				// toggling prepend. The (streaming) shell only writes `<file>.reversed`
				// temp files; the publish step below fsyncs each temp before renaming
				// it into place, so a crash mid-toggle never leaves a half-reversed
				// live file (the old file stays valid until the rename).
				await UtilsServer.execFile(
					"find",
					[
						tableName,
						"-type",
						"f",
						"-name",
						`*${this.fileExtension}${config.compression ? ".gz" : ""}`,
						"-exec",
						"sh",
						"-c",
						`for file; do ${
							config.compression
								? `zcat "$file" | ${process.platform === "darwin" ? "tail -r" : "tac"} | gzip > "$file.reversed"`
								: `${process.platform === "darwin" ? "tail -r" : "tac"} "$file" > "$file.reversed"`
						}; done`,
						"_",
						"{}",
						"+",
					],
					{ cwd: this.databasePath },
				);

				const reversedSuffix = `${this.fileExtension}${
					config.compression ? ".gz" : ""
				}.reversed`;
				for (const fileName of await readdir(tablePath)) {
					if (!fileName.endsWith(reversedSuffix)) continue;
					const reversedPath = join(tablePath, fileName);
					await File.syncFile(reversedPath);
					await rename(
						reversedPath,
						join(tablePath, fileName.slice(0, -".reversed".length)),
					);
				}
				if (config.prepend)
					await File.write(join(tablePath, ".prepend.config"), "");
				else await unlink(join(tablePath, ".prepend.config"));
			}
			if (config.name) {
				await rename(tablePath, join(this.databasePath, config.name));
				// replace table name in other linked tables (relationship).
				// glob() returns paths relative to `cwd`, so resolve them
				// against the database path before touching the files.
				for await (const schemaPath of glob(
					`**/schema.${this.schemaFileExtension}`,
					{
						cwd: this.databasePath,
					},
				))
					await this.replaceStringInFile(
						resolve(this.databasePath, schemaPath),
						// TODO: escape caracters in table name
						this.schemaFileExtension === "json"
							? `"table": "${tableName}"`
							: `table:${tableName}`,
						this.schemaFileExtension === "json"
							? `"table": "${config.name}"`
							: `table:${config.name}`,
					);
			}
		}

		// Flush the directory entries touched by this DDL (renames, unlinks,
		// fresh config markers) before updateTable returns so the schema/config
		// change survives a crash.
		await File.syncDir(config?.name ? this.databasePath : tablePath);

		globalConfig[this.databasePath].tables?.delete(tableName);
		// The schema on disk changed under the DDL lock: drop the cached plan
		// (also under the old name when the table was renamed) so the next DML
		// rebuilds from the reloaded schema.
		this.computedPlanCache.delete(tableName);
		if (config?.name && config.name !== tableName)
			this.computedPlanCache.delete(config.name);
		// Drop log/format caches for the touched table(s) so next access re-reads
		// the (possibly moved) marker and overlay from disk.
		for (const name of config?.name ? [tableName, config.name] : [tableName]) {
			this.tableFormats.delete(name);
			this.formatStamps.delete(name);
			await this.overlays.get(this.overlayKey(name))?.dispose();
			this.overlays.delete(this.overlayKey(name));
		}
	}

	/**
	 * Get table schema and config
	 *
	 * @param {string} tableName
	 * @return {*}  {Promise<StoredTableObject | undefined>}
	 */
	public async getTable(tableName: string): Promise<TableObject | undefined> {
		const table = await this.loadTable(tableName);
		if (!table) return undefined;
		return {
			...table,
			config: {
				decodeID: table.config.decodeID === true,
				prepend: table.config.prepend === true,
				compression: table.config.compression === true,
				cache: table.config.cache === true,
			},
		};
	}

	private async loadTable(
		tableName: string,
	): Promise<StoredTableObject | undefined> {
		this.validateName(tableName);

		const tablePath = join(this.databasePath, tableName);

		if (!(await File.isExists(tablePath)))
			throw this.createError("TABLE_NOT_EXISTS", tableName);

		if (
			!globalConfig[this.databasePath].tables?.has(tableName) ||
			globalConfig[this.databasePath].tables?.get(tableName)?.timestamp !==
				(await File.getFileDate(
					join(tablePath, `schema.${this.schemaFileExtension}`),
				))
		) {
			const format = await this.readValidatedFormat(tableName, tablePath);
			this.tableFormats.set(tableName, format);
			await this.stampFormat(tableName);
			const config: StoredTableConfig = {
				compression: await File.isExists(
					join(tablePath, ".compression.config"),
				),
				cache: await File.isExists(join(tablePath, ".cache.config")),
				prepend: await File.isExists(join(tablePath, ".prepend.config")),
				decodeID: await File.isExists(join(tablePath, ".decodeID.config")),
			};
			// Only surface `log` when enabled, so the public config shape of a
			// legacy table is byte-for-byte what it was before 3.8.
			if (format.log) config.log = true;
			if (format.tombstones) config.tombstones = true;
			const seek = await this.readSeekConfig(tablePath);
			if (seek)
				Object.assign(config, {
					seekable: true,
					indexes: seek.indexes,
					blockBytes: seek.blockBytes,
				});
			globalConfig[this.databasePath].tables?.set(tableName, {
				schema: await this.getTableSchema(tableName),
				config,
				timestamp: await File.getFileDate(
					join(tablePath, `schema.${this.schemaFileExtension}`),
				),
			});
			this.computedPlanCache.delete(tableName);
		}
		// A format migration need not change the schema timestamp.
		const format = await this.currentFormat(tableName);
		const config =
			globalConfig[this.databasePath].tables?.get(tableName)?.config;
		if (config && format?.log) config.log = true;
		if (config && format?.tombstones) config.tombstones = true;
		return globalConfig[this.databasePath].tables?.get(tableName);
	}

	/** Explicit format-2 -> 3 migration; base columns and old frames are unchanged. */
	public async enableTombstones(tableName: string): Promise<void> {
		return File.runWithLockStore(async () => {
			this.validateName(tableName);
			if (this.activeTransaction) throw this.createError("INVALID_PARAMETERS");
			await this.loadTable(tableName);
			if (!this.isLogTable(tableName))
				await this._updateTable(tableName, undefined, { log: true });
			const tablePath = join(this.databasePath, tableName);
			await File.lock(join(tablePath, ".tmp"));
			try {
				const format = await this.currentFormat(tableName);
				if (!format) throw this.createError("UNSUPPORTED_FORMAT", tableName);
				await writeFormat(tablePath, {
					...format,
					format: 3,
					tombstones: true,
				});
				await this.overlays.get(this.overlayKey(tableName))?.dispose();
				this.overlays.delete(this.overlayKey(tableName));
				this.tableFormats.delete(tableName);
				globalConfig[this.databasePath].tables?.delete(tableName);
			} finally {
				await File.unlock(join(tablePath, ".tmp"));
			}
		});
	}

	private seekConfig(
		config: Pick<StoredTableConfig, "indexes" | "blockBytes">,
	): SeekConfig {
		const blockBytes = config.blockBytes ?? DEFAULT_BLOCK_BYTES;
		if (![65536, 131072, 262144].includes(blockBytes))
			throw this.createError("INVALID_PARAMETERS", "blockBytes");
		return {
			v: 1,
			blockBytes,
			indexes: Array.from(new Set(config.indexes ?? [])),
		};
	}

	private async readSeekConfig(tablePath: string): Promise<SeekConfig | null> {
		let raw: string;
		try {
			raw = await readFile(join(tablePath, ".seek.config"), "utf8");
		} catch (error: any) {
			if (error?.code === "ENOENT") return null;
			throw error;
		}
		const config = JSON.parse(raw);
		if (config.v !== 1 || !Array.isArray(config.indexes))
			throw this.createError("UNSUPPORTED_FORMAT", "seek directory config");
		return this.seekConfig(config);
	}

	/** Explicit, journaled accelerator migration. Existing gzip readers remain compatible. */
	public async optimize(
		tableName: string,
		options: Pick<StoredTableConfig, "indexes" | "blockBytes"> = {},
	): Promise<void> {
		return File.runWithLockStore(async () => {
			this.validateName(tableName);
			if (this.activeTransaction) throw this.createError("INVALID_PARAMETERS");
			await this.ensureDatabaseRecovered();
			const tablePath = join(this.databasePath, tableName);
			await File.lock(join(tablePath, ".tmp"));
			try {
				await this.optimizeLocked(tableName, tablePath, options);
			} finally {
				await File.unlock(join(tablePath, ".tmp"));
			}
		});
	}

	private async optimizeLocked(
		tableName: string,
		tablePath: string,
		options: Pick<StoredTableConfig, "indexes" | "blockBytes">,
		budget?: { remainingBytes: number },
	): Promise<void> {
		const pairs: (string | null)[][] = [];
		try {
			const table = await this.loadTable(tableName);
			const config = this.seekConfig(options);
			for (const key of config.indexes) {
				this.validateColumns([key]);
				if (
					!table?.schema?.some(
						(field) => field.key === key && this.isSimpleField(field.type),
					)
				)
					throw this.createError("INVALID_PARAMETERS", `index ${key}`);
			}
			const extension = this.getFileExtension(tableName);
			for (const name of await readdir(tablePath)) {
				if (!name.endsWith(extension)) continue;
				const live = join(tablePath, name);
				const tmp = join(tablePath, ".tmp", `${name}.optimize-${randomUUID()}`);
				await copyFile(live, tmp);
				pairs.push([tmp, live]);
			}
			await this.prepareAccelerators(tablePath, pairs, config, budget);
			const tmp = join(tablePath, ".tmp", `seek.config-${randomUUID()}`);
			await File.write(tmp, JSON.stringify(config));
			pairs.push([tmp, join(tablePath, ".seek.config")]);
			await this.commitFiles(tablePath, pairs, null);
			globalConfig[this.databasePath].tables?.delete(tableName);
		} finally {
			for (const [tmp] of pairs) if (tmp) await unlink(tmp).catch(() => {});
		}
	}

	/** Conservative automatic accelerator build; authoritative formats never change. */
	private async buildAutomaticIndex(
		tableName: string,
		key: string,
	): Promise<void> {
		return File.runWithIndependentLockStore(async () => {
			if (this.closed || this.activeTransaction) return;
			const tablePath = join(this.databasePath, tableName);
			const databaseJournal = join(this.databasePath, ".tmp", "journal.jsonl");
			if (await File.isExists(databaseJournal)) return;
			if (!(await File.tryLock(join(tablePath, ".tmp")))) return;
			try {
				if (await File.isExists(databaseJournal)) return;
				const table = await this.loadTable(tableName);
				const field = table?.schema?.find((field) => field.key === key);
				if (!field || field.computed || !this.isSimpleField(field.type)) return;
				const previous = await this.readSeekConfig(tablePath);
				if (
					previous?.indexes.includes(key) ||
					(previous?.indexes.length ?? 0) >= 8
				)
					return;
				const extension = this.getFileExtension(tableName);
				let primaryBytes = 0,
					indexBytes = 0,
					rows = 0;
				for (const name of await readdir(tablePath)) {
					if (name.endsWith(extension))
						primaryBytes += (await stat(join(tablePath, name))).size;
					if (name.endsWith(".lookup"))
						indexBytes += (await stat(join(tablePath, name))).size;
					if (name.endsWith(".pagination"))
						rows = Number(parse(name).name.split("-")[1]);
				}
				// Until segment publication exists, bound this whole-column operation.
				if (
					rows < 128 ||
					rows > 100000 ||
					indexBytes + rows * 68 >
						Math.min(
							64 * 1024 * 1024,
							Math.max(1024 * 1024, primaryBytes * 2),
						) ||
					primaryBytes > 8 * 1024 * 1024 ||
					this.resources.limit < 4 * 1024 * 1024
				)
					return;
				await this.resources.withWorking(2 * 1024 * 1024, () =>
					this.optimizeLocked(
						tableName,
						tablePath,
						{
							indexes: [...(previous?.indexes ?? []), key],
							blockBytes: previous?.blockBytes,
						},
						{ remainingBytes: 16 * 1024 * 1024 },
					),
				);
			} finally {
				await File.unlock(join(tablePath, ".tmp"));
			}
		});
	}

	private async prepareAccelerators(
		tablePath: string,
		pairs: (string | null)[][],
		explicit?: SeekConfig,
		budget?: { remainingBytes: number },
	): Promise<void> {
		const config = explicit ?? (await this.readSeekConfig(tablePath));
		if (!config) return;
		const tableName = basename(tablePath);
		const extension = this.getFileExtension(tableName);
		const idLive = join(tablePath, `id${extension}`);
		const idPair = pairs.find(([, live]) => live === idLive);
		const idTmp = idPair ? idPair[0] : idLive;
		const columns = pairs.filter(([, live]) => live?.endsWith(extension));
		for (const pair of columns) {
			const [tmp, live] = pair;
			if (!live) continue;
			if (!tmp) {
				for (const suffix of [".seek", ".lookup"])
					if (await File.isExists(live + suffix))
						pairs.push([null, live + suffix]);
				continue;
			}
			if (pairs.some(([, path]) => path === `${live}.seek`)) continue;
			pairs.push(
				await prepareSeekable(
					tmp,
					live,
					config.blockBytes,
					File.appendPrefixOf(pair),
					budget
						? (bytes) => {
								budget.remainingBytes -= bytes;
								if (budget.remainingBytes < 0)
									throw new Error("AUTOMATIC_BUILD_BUDGET");
							}
						: undefined,
				),
			);
		}
		// Every new primary inode must be final before capturing the ID stamp.
		for (const [tmp, live] of columns) {
			if (!tmp || !live || pairs.some(([, path]) => path === `${live}.lookup`))
				continue;
			if (
				idTmp &&
				(live === idLive ||
					config.indexes.includes(basename(live).slice(0, -extension.length)))
			)
				pairs.push(
					await prepareKeyIndex(
						tmp,
						live,
						idTmp,
						idLive,
						budget ? 65536 : Infinity,
					),
				);
		}
	}

	/* -----------------------------------------------------------------------
	 * Update-log overlay (format 2 tables)
	 * --------------------------------------------------------------------- */

	private overlayKey(tableName: string): string {
		return `${this.databasePath}\u0000${tableName}`;
	}

	/** True when the table opted into the incremental update log. */
	private isLogTable(tableName: string): boolean {
		const cached = this.tableFormats.get(tableName);
		if (cached) return cached.log;
		return (
			globalConfig[this.databasePath].tables?.get(tableName)?.config.log ===
			true
		);
	}

	/** Bound automatic point batches before constructing frames/ID selections. */
	private deltaPayloadFits(data: unknown, copies = 1): boolean {
		const rows = Array.isArray(data) ? data : [data];
		if (!rows.length || rows.length > 256) return false;
		let bytes = 256;
		for (const row of rows) {
			if (!row || typeof row !== "object") return false;
			// Preserve the existing metadata/ID mutation semantics via the base path.
			if (Object.hasOwn(row, "id") || Object.hasOwn(row, "createdAt"))
				return false;
			for (const [key, value] of Object.entries(row)) {
				if (value !== null && typeof value === "object") return false;
				bytes +=
					6 * (Buffer.byteLength(key) + Buffer.byteLength(String(value))) + 128;
				if (bytes * copies > Math.min(65536, this.resources.limit / 16))
					return false;
			}
		}
		return true;
	}

	/** The caller holds the writer lock throughout transition and mutation. */
	private async leaveAutomaticDeltas(tableName: string): Promise<void> {
		const format = await this.currentFormat(tableName);
		if (!format?.automatic || !format.log) return;
		await this.compactLogTable(tableName);
		const tablePath = join(this.databasePath, tableName);
		const legacy = { format: 1, log: false, baseGen: 0 };
		await writeFormat(tablePath, legacy);
		await this.overlays.get(this.overlayKey(tableName))?.dispose();
		this.overlays.delete(this.overlayKey(tableName));
		this.tableFormats.set(tableName, legacy);
		await this.stampFormat(tableName);
		// Compaction can rename pagination; a transaction must resolve it anew.
		const entry = this.activeTransaction?.tables.get(tableName);
		if (entry && !entry.staged.length) {
			entry.paginationFrom = "";
			entry.lastId = 0;
			entry.total = 0;
		}
	}

	private async automaticDeltaWrite<T>(
		tableName: string,
		eligible: boolean,
		write: () => Promise<T>,
	): Promise<T> {
		this.validateName(tableName);
		if (this.activeTransaction) {
			await this.ensureTxnLock(tableName);
			return write();
		}
		await this.ensureDatabaseRecovered();
		await this.loadTable(tableName);
		const tablePath = join(this.databasePath, tableName);
		await File.lock(
			join(tablePath, ".tmp"),
			undefined,
			undefined,
			this.resources,
		);
		try {
			const table = await this.loadTable(tableName);
			const compatible =
				eligible &&
				!table?.config.prepend &&
				Boolean(
					table?.schema?.every(
						(field) =>
							typeof field.computed === "undefined" &&
							this.isSimpleField(field.type),
					),
				);
			let format = await this.currentFormat(tableName);
			if (format?.automatic && !compatible) {
				await this.leaveAutomaticDeltas(tableName);
				format = await this.currentFormat(tableName);
			}
			if (
				compatible &&
				!format?.log &&
				(await this.resolvePagination(tableName)).total >= 128
			) {
				// Persist an empty log name before publishing the marker. A crash
				// before the marker leaves an unused file; after it, an empty log.
				const logPath = join(tablePath, UPDATES_LOG_NAME);
				await File.write(logPath, "");
				await File.syncFile(logPath);
				const next = {
					format: 3,
					log: true,
					baseGen: 0,
					tombstones: true,
					automatic: true,
				};
				await writeFormat(tablePath, next);
				this.tableFormats.set(tableName, next);
				format = next;
				await this.stampFormat(tableName);
			}
			return await (format?.automatic && compatible
				? this.resources.withWorking(
						Math.min(this.resources.limit, 512 * 1024),
						write,
					)
				: write());
		} finally {
			await File.unlock(join(tablePath, ".tmp"));
		}
	}

	/**
	 * Resolve a table's format marker, revalidating a cached *log* table when
	 * its `.format` file changed underneath us. A compaction by another process
	 * bumps `baseGen` and empties the log; without re-reading the marker this
	 * process would scan the new (empty) log with the old `baseGen`, and once a
	 * post-compaction frame appears the generation gap would look like
	 * corruption. Legacy tables never change format implicitly, so they skip
	 * the stat entirely and keep the pre-3.8 read path cost.
	 */
	/**
	 * Read a table's `.format` marker and refuse a table written by a newer
	 * engine (§4.1) *before* any column is read: a higher `format`, or a
	 * `minReader` above this build, throws UNSUPPORTED_FORMAT rather than being
	 * silently mis-read as format 2/legacy.
	 */
	private async readValidatedFormat(
		tableName: string,
		tablePath: string,
	): Promise<TableFormat> {
		const format = await readFormat(tablePath);
		const reason = unsupportedFormatReason(format);
		if (reason)
			throw this.createError("UNSUPPORTED_FORMAT", `${tableName} (${reason})`);
		return format;
	}

	private async currentFormat(tableName: string): Promise<TableFormat | null> {
		const cached = this.tableFormats.get(tableName);

		const tablePath = join(this.databasePath, tableName);
		let stamp = "none";
		try {
			const stat_ = await stat(join(tablePath, FORMAT_FILE));
			stamp = `${stat_.mtimeMs}:${stat_.size}:${stat_.ino}`;
		} catch {
			stamp = "none";
		}
		if (cached && this.formatStamps.get(tableName) === stamp) return cached;

		const format = await this.readValidatedFormat(tableName, tablePath);
		this.tableFormats.set(tableName, format);
		this.formatStamps.set(tableName, stamp);
		// A changed baseGen invalidates the cached overlay: rebuild from the
		// (possibly now empty) log at the new generation.
		const key = this.overlayKey(tableName);
		const overlay = this.overlays.get(key);
		if (
			overlay &&
			(overlay.baseGen !== format.baseGen ||
				overlay.tombstones !== Boolean(format.tombstones))
		) {
			await overlay.dispose();
			this.overlays.delete(key);
		}
		return format;
	}

	/**
	 * Load (or refresh) a table's live overlay. Returns null for legacy tables
	 * (no `.format` marker) so every existing code path stays untouched. With
	 * `forWrite`, repairs a torn tail and rebuilds to the committed boundary;
	 * the caller must already hold the table writer lock.
	 */
	private async getOverlay(
		tableName: string,
		forWrite = false,
	): Promise<TableOverlay | null> {
		const format = await this.currentFormat(tableName);
		if (!format?.log) return null;

		const key = this.overlayKey(tableName);
		let overlay = this.overlays.get(key);
		if (
			!overlay ||
			overlay.baseGen !== format.baseGen ||
			overlay.tombstones !== Boolean(format.tombstones)
		) {
			await overlay?.dispose();
			overlay = new TableOverlay(
				join(this.databasePath, tableName),
				format.baseGen,
				Boolean(format.tombstones),
			);
			this.overlays.set(key, overlay);
		}
		if (forWrite) await overlay.refreshForWrite();
		else await overlay.refresh();
		return overlay;
	}

	private async stampFormat(tableName: string): Promise<void> {
		let stamp = "none";
		try {
			const stat_ = await stat(join(this.databasePath, tableName, FORMAT_FILE));
			stamp = `${stat_.mtimeMs}:${stat_.size}:${stat_.ino}`;
		} catch {
			stamp = "none";
		}
		this.formatStamps.set(tableName, stamp);
	}

	/**
	 * The format-2 update log stores one encoded cell per changed *top-level
	 * simple* column; nested (object/array/table) and computed fields are not
	 * representable without a compaction step (3.9). A log table whose schema
	 * violates this is rejected at DDL time so the write path can always take
	 * the log and never needs to interleave a whole-column rewrite.
	 */
	private assertLogCompatibleSchema(schema: Schema): void {
		for (const field of schema) {
			if (["id", "createdAt", "updatedAt"].includes(field.key)) continue;
			if (typeof field.computed !== "undefined")
				throw this.createError(
					"UNSUPPORTED_FORMAT",
					`simple top-level fields (computed field "${field.key}" is not supported with log)`,
				);
			if (!this.isSimpleField(field.type))
				throw this.createError(
					"UNSUPPORTED_FORMAT",
					`simple top-level fields (field "${field.key}" is ${field.type})`,
				);
		}
	}

	private idFieldOf(tableName: string): Field {
		const schema =
			globalConfig[this.databasePath].tables?.get(tableName)?.schema ?? [];
		return (
			schema.find((field) => field.key === "id") ?? { key: "id", type: "id" }
		);
	}

	/** Read the internal numeric id for each requested line (stable overlay key). */
	private async overlayLineIds(
		tableName: string,
		lines: number[],
	): Promise<Map<number, number>> {
		const map = new Map<number, number>();
		if (!lines.length) return map;
		const filePath = join(
			this.databasePath,
			tableName,
			`id${this.getFileExtension(tableName)}`,
		);
		// Streaming reader (no shell spawn): like the sparse column read path,
		// stop at the last requested line instead of shelling out to `sed -n`,
		// which costs ~ms per call on a log-table read.
		const values = await File.getLines(filePath, lines, {
			...this.idFieldOf(tableName),
			key: "id",
			type: "number",
		});
		for (const [line, value] of Object.entries(values))
			map.set(Number(line), Number(value));
		return map;
	}

	/**
	 * Per-line raw-cell overrides for one column, from the overlay. Used by
	 * `File.search` so criteria, uniqueness and aggregate scans see the merged
	 * (un-compacted) values. Returns undefined when the table has no overlay or
	 * the column is never overlaid.
	 */
	private async overlayColumnOverrides(
		tableName: string,
		columnKey: string,
	): Promise<File.ColumnOverrides | undefined> {
		const overlay = await this.getOverlay(tableName);
		if (!overlay || overlay.size === 0) return undefined;
		if (!overlay.deletedCount && !overlay.columns.has(columnKey))
			return undefined;
		const ids = File.lines(
			join(
				this.databasePath,
				tableName,
				`id${this.getFileExtension(tableName)}`,
			),
		);
		const idPath = join(
			this.databasePath,
			tableName,
			`id${this.getFileExtension(tableName)}`,
		);
		let current: IteratorResult<[number, string]> | undefined;
		return {
			size: overlay.size,
			value: async (line, base) => {
				while (!current || (!current.done && current.value[0] < line))
					current = await ids.next();
				if (current.done || current.value[0] !== line) return base;
				const entry = await overlay.get(Number(current.value[1]));
				if (entry?.deleted) return File.DELETED_ROW;
				return entry && Object.hasOwn(entry.cols, columnKey)
					? (entry.cols[columnKey] as string | number | boolean | null)
					: base;
			},
			at: async (line, base) => {
				const values = await File.getLines(idPath, [line], {
					key: "id",
					type: "number",
				});
				const entry = await overlay.get(Number(values[line]));
				if (entry?.deleted) return File.DELETED_ROW;
				return entry && Object.hasOwn(entry.cols, columnKey)
					? (entry.cols[columnKey] as string | number | boolean | null)
					: base;
			},
			candidates: async (matches) => {
				const result: number[] = [];
				if (!overlay.columns.has(columnKey)) return result;
				for await (const [id, entry] of overlay.byId.entries()) {
					if (entry.deleted) continue;
					if (
						!Object.hasOwn(entry.cols, columnKey) ||
						!matches(entry.cols[columnKey])
					)
						continue;
					const found = await lookupLines(idPath, [id]);
					if (found) result.push(...found);
					else {
						const [, , lines] = await File.search(
							idPath,
							"=",
							Number(id),
							undefined,
							undefined,
							{ key: "id", type: "number" },
						);
						if (lines) result.push(...lines);
					}
				}
				return result;
			},
			close: async () => {
				await ids.return(undefined);
			},
		};
	}

	/**
	 * Fold every logged update into the base columns and reset the log.
	 *
	 * Safe to call on any table: legacy tables (no `.format` marker) are a
	 * no-op. Semantically neutral — it only materializes already-acknowledged
	 * updates, so a failure never makes an acknowledged `put` disappear.
	 * Returns the new `baseGen` for a compacted table, or `null` when there was
	 * nothing to fold.
	 */
	public async compact(tableName: string): Promise<number | null> {
		this.validateName(tableName);
		if (this.activeTransaction)
			throw this.createError(
				"MAINTENANCE_REQUIRED",
				`${tableName} (compaction inside a transaction)`,
			);
		await this.ensureDatabaseRecovered();

		const tablePath = join(this.databasePath, tableName);
		if (!(await File.isExists(tablePath)))
			throw this.createError("TABLE_NOT_EXISTS", tableName);

		const format = await this.currentFormat(tableName);
		if (!format?.log) return null; // legacy table: nothing to fold

		await File.lock(join(tablePath, ".tmp"));
		try {
			return await this.compactLogTable(tableName);
		} finally {
			await File.unlock(join(tablePath, ".tmp"));
		}
	}

	/**
	 * Compaction core. The caller must hold the table writer lock. Streams each
	 * overlaid base column through `File.replace` (which handles compression),
	 * then publishes the new columns, an empty `updates.log`, and a `.format`
	 * marker with the bumped generation in one journaled commit, so a crash
	 * either rolls every file back (old base + old log + old `baseGen`) or
	 * forward (new base + empty log + new `baseGen`). No acknowledged update is
	 * ever lost.
	 */
	private async compactLogTable(tableName: string): Promise<number | null> {
		const tablePath = join(this.databasePath, tableName);
		const overlay = await this.getOverlay(tableName, true);
		if (!overlay || overlay.size === 0) return null; // already compact
		// Cached, previously checked prefixes are immutable between generations.
		// Scrub all authoritative frames before retiring a generation, so older
		// prefix corruption cannot be silently erased by compaction.
		await overlay.log.scan(overlay.baseGen + 1);

		const schema = (await this.loadTable(tableName))?.schema ?? [];
		const schemaKeys = new Set(schema.map((field) => field.key));
		const format = await this.currentFormat(tableName);

		// Only columns that some frame actually overlaid need rewriting; the
		// untouched base columns are left exactly as they are.
		const overlaidKeys = new Set<string>();
		if (overlay.deletedCount)
			for (const field of schema) overlaidKeys.add(field.key);
		for await (const [, entry] of overlay.byId.entries())
			for (const key of Object.keys(entry.cols))
				if (schemaKeys.has(key)) overlaidKeys.add(key);
		if (!overlaidKeys.size) return null;

		const extension = this.getFileExtension(tableName);
		const renameList: (string | null)[][] = [];

		for (const key of overlaidKeys) {
			if (!(await File.isExists(join(tablePath, `${key}${extension}`))))
				continue;
			const overrides = await this.overlayColumnOverrides(tableName, key);
			if (!overrides || overrides instanceof Map) continue;
			try {
				renameList.push(
					await File.rewriteCells(
						join(tablePath, `${key}${extension}`),
						(line, raw) => overrides.value(line, raw),
					),
				);
			} finally {
				await overrides.close();
			}
		}
		if (!renameList.length) return null;

		const newGen = overlay.committedGen;
		const staging = (name: string) =>
			join(
				tablePath,
				".tmp",
				`${name}.compact-${process.pid}-${randomUUID().slice(0, 8)}`,
			);

		// Empty log (frames are now folded into base) and the bumped marker,
		// committed atomically with the column swaps.
		const logTmp = staging(UPDATES_LOG_NAME);
		await File.write(logTmp, "");
		renameList.push([logTmp, join(tablePath, UPDATES_LOG_NAME)]);

		const fmtTmp = staging(FORMAT_FILE);
		await File.write(
			fmtTmp,
			serializeFormat({
				format: format?.format ?? 2,
				log: true,
				baseGen: newGen,
				...(format?.tombstones ? { tombstones: true } : {}),
				...(format?.automatic ? { automatic: true } : {}),
			}),
		);
		renameList.push([fmtTmp, join(tablePath, FORMAT_FILE)]);

		const pagination = await this.resolvePagination(tableName);
		const newTotal = pagination.total - overlay.deletedCount;
		await this.commitFiles(
			tablePath,
			renameList,
			overlay.deletedCount
				? {
						from: pagination.filePath,
						to: join(tablePath, `${pagination.lastId}-${newTotal}.pagination`),
					}
				: null,
		);

		// In-memory: the base now carries every update; drop the overlay so the
		// next access rebuilds an empty one at the new generation.
		this.tableFormats.set(tableName, {
			format: format?.format ?? 2,
			log: true,
			baseGen: newGen,
			...(format?.tombstones ? { tombstones: true } : {}),
			...(format?.automatic ? { automatic: true } : {}),
		});
		await this.stampFormat(tableName);
		await overlay.dispose();
		this.overlays.delete(this.overlayKey(tableName));
		if (globalConfig[this.databasePath].tables?.get(tableName)?.config.cache)
			await this.clearCache(tableName);
		return newGen;
	}

	public async getTableSchema(tableName: string) {
		this.validateName(tableName);

		const tablePath = join(this.databasePath, tableName);
		let schemaFile: string | undefined;
		let schema: Schema | undefined;

		if (
			!(await File.isExists(
				join(tablePath, `schema.${this.schemaFileExtension}`),
			))
		) {
			const otherSchemaFileExtension =
				this.schemaFileExtension === "json" ? "inis" : "json";
			if (
				!(await File.isExists(
					join(tablePath, `schema.${otherSchemaFileExtension}`),
				))
			)
				return undefined;

			schemaFile = await readFile(
				join(tablePath, `schema.${otherSchemaFileExtension}`),
				"utf8",
			);

			if (!schemaFile) return undefined;

			schema =
				otherSchemaFileExtension === "json"
					? JSON.parse(schemaFile)
					: Inison.unstringify(schemaFile);

			// Mirror the legacy schema file into the preferred extension and
			// drop the old one (fsync-backed; this read-path migration must
			// survive a crash).
			await File.write(
				join(tablePath, `schema.${this.schemaFileExtension}`),
				this.schemaFileExtension === "json"
					? JSON.stringify(schema, null, 2)
					: Inison.stringify(schema),
			);
			await unlink(join(tablePath, `schema.${otherSchemaFileExtension}`));
			await File.syncDir(tablePath);
		} else
			schemaFile = await readFile(
				join(tablePath, `schema.${this.schemaFileExtension}`),
				"utf8",
			);

		if (!schemaFile) return undefined;

		if (!schema)
			schema =
				this.schemaFileExtension === "json"
					? JSON.parse(schemaFile)
					: Inison.unstringify(schemaFile);

		return [
			{
				id: 0,
				key: "id",
				type: "id",
				required: true,
			},
			...(schema || []),
			{
				id: -1,
				key: "createdAt",
				type: "date",
				required: true,
			},
			{
				id: -2,
				key: "updatedAt",
				type: "date",
			},
		] as Schema;
	}

	private async throwErrorIfTableEmpty(tableName: string): Promise<void> {
		const table = await this.loadTable(tableName);

		if (!table?.schema) throw this.createError("NO_SCHEMA", tableName);

		if (
			!(await File.isExists(
				join(
					this.databasePath,
					tableName,
					`id${this.getFileExtension(tableName)}`,
				),
			))
		)
			throw this.createError("TABLE_EMPTY", tableName);
	}

	public validateData(
		data: Data | Data[],
		schema: Schema,
		skipRequiredField = false,
	): void {
		if (Utils.isArrayOfObjects(data)) {
			for (const single_data of data as Data[])
				this.validateData(single_data, schema, skipRequiredField);
			return;
		}
		if (Utils.isObject(data)) {
			for (const field of schema) {
				// Computed columns are never user-settable: their value is
				// always derived by the engine at write time.
				if (typeof field.computed !== "undefined") {
					if (Object.hasOwn(data, field.key))
						throw this.createError("COMPUTED_FIELD_SETTABLE", field.key);
					continue;
				}
				if (
					!Object.hasOwn(data, field.key) ||
					data[field.key] === null ||
					data[field.key] === undefined ||
					data[field.key] === ""
				) {
					if (field.required && !skipRequiredField)
						throw this.createError("FIELD_REQUIRED", field.key);
					continue;
				}

				if (!Utils.validateFieldType(data[field.key], field))
					throw this.createError("INVALID_TYPE", [
						field.key,
						(Array.isArray(field.type) ? field.type.join(", ") : field.type) +
							(field.children
								? Array.isArray(field.children)
									? Utils.isArrayOfObjects(field.children)
										? "[object]"
										: `[${field.children.join("|")}]`
									: `[${field.children}]`
								: ""),
						data[field.key],
					]);
				if (
					(field.type === "array" || field.type === "object") &&
					field.children &&
					Utils.isArrayOfObjects(field.children)
				)
					this.validateData(data[field.key], field.children, skipRequiredField);
				else {
					if (
						field.table &&
						Utils.isObject(data[field.key]) &&
						Object.hasOwn(data[field.key], "id")
					)
						data[field.key] = data[field.key].id;

					if (field.regex) {
						const regex = UtilsServer.getCachedRegex(field.regex);
						if (
							(Array.isArray(data[field.key]) &&
								data[field.key].some((v: unknown) => !regex.test(String(v)))) ||
							!regex.test(String(data[field.key]))
						)
							throw this.createError("INVALID_REGEX_MATCH", [field.key]);
					}
					if (field.unique && field.id !== undefined) {
						const fieldId: number = field.id;
						const uniqueKey: string | number =
							typeof field.unique === "boolean" ? fieldId : field.unique;
						if (!this.uniqueMap.has(uniqueKey))
							this.uniqueMap.set(uniqueKey, {
								exclude: new Set(),
								columnsValues: new Map(),
							});

						if (!this.uniqueMap.get(uniqueKey)?.columnsValues.has(fieldId))
							this.uniqueMap
								?.get(uniqueKey)
								?.columnsValues.set(fieldId, new Set());

						if (data.id) this.uniqueMap.get(uniqueKey)?.exclude.add(-data.id);
						if (
							this.uniqueContext.getStore() &&
							field.unique === true &&
							this.uniqueMap
								.get(uniqueKey)
								?.columnsValues.get(fieldId)
								?.has(data[field.key])
						)
							throw this.createError("FIELD_UNIQUE", field.key);

						this.uniqueMap
							.get(uniqueKey)
							?.columnsValues.get(fieldId)
							?.add(data[field.key]);
					}
				}
			}
		}
	}
	private async validateTableData(
		tableName: string,
		data: Data | Data[],
		skipRequiredField = false,
		excludeLines: number[] = [],
		allowInputExclusions = true,
	): Promise<void> {
		return this.uniqueContext.run(new Map(), async () => {
			// `data` is always a private clone owned by the caller (post/put already
			// cloned it once), so validate in place instead of re-cloning — otherwise
			// every bulk write holds several full copies of the payload in memory.
			// Skip ID and (created|updated)At
			this.validateData(
				data,
				globalConfig[this.databasePath].tables
					?.get(tableName)
					?.schema?.slice(1, -2) ?? [],
				skipRequiredField,
			);
			for (const state of this.uniqueMap.values()) {
				if (!allowInputExclusions) state.exclude.clear();
				for (const line of excludeLines) state.exclude.add(-line);
			}
			await this.checkUnique(tableName);
		});
	}

	private cleanObject<T extends Record<string, any>>(obj: T): T | null {
		const cleanedObject = Object.entries(obj).reduce((acc, [key, value]) => {
			if (value !== undefined && value !== null && value !== "")
				acc[key] = value;
			return acc;
		}, {} as T);

		return Object.keys(cleanedObject).length > 0 ? cleanedObject : null;
	}

	private formatField(
		value: Data | number | string,
		field?: Field,
		_formatOnlyAvailiableKeys?: boolean,
	): Data | number | string | null;
	private formatField(
		value: (number | string | Data)[],
		field?: Field,
		_formatOnlyAvailiableKeys?: boolean,
	): (number | string | null | Data)[];
	private formatField(
		value: Data | number | string | (number | string | Data)[],
		field?: Field,
		_formatOnlyAvailiableKeys?: boolean,
	): Data | Data[] | number | string | null {
		if (value === null || value === undefined || value === "") return value;
		if (!field) return value as Data | Data[] | number | string | null;

		let _fieldType = field.type;
		if (Array.isArray(_fieldType))
			_fieldType = Utils.detectFieldType(value, _fieldType) ?? _fieldType[0];

		if (Array.isArray(value) && !["array", "json"].includes(_fieldType))
			value = value[0];

		switch (_fieldType) {
			case "array":
				if (!field.children) return null;

				if (!Array.isArray(value)) value = [value];

				if (Utils.isArrayOfObjects(field.children))
					return this.formatData(
						value as Data[],
						field.children,
						_formatOnlyAvailiableKeys,
					);

				if (!value.length) return null;

				return (value as (string | number | Data)[]).map((_value) =>
					this.formatField(_value, {
						...field,
						type: field.children as FieldType | FieldType[],
					} as Field),
				);
			case "object":
				if (Utils.isArrayOfObjects(field.children))
					return this.formatData(
						value as Data,
						field.children,
						_formatOnlyAvailiableKeys,
					);
				break;
			case "table":
				if (Utils.isObject(value)) {
					if (
						Object.hasOwn(value, "id") &&
						(Utils.isValidID((value as Data).id) ||
							Utils.isNumber((value as Data).id))
					)
						return Utils.isNumber((value as Data).id)
							? Number((value as Data).id)
							: UtilsServer.decodeID((value as Data).id as string);
				} else if (Utils.isValidID(value) || Utils.isNumber(value))
					return Utils.isNumber(value)
						? Number(value)
						: UtilsServer.decodeID(value);
				break;
			case "password":
				return Utils.isPassword(value)
					? value
					: UtilsServer.hashPassword(String(value));
			case "number":
				return Utils.isNumber(value)
					? typeof value === "number"
						? value
						: Number((value as string).trim())
					: 0;
			case "date":
				return Utils.dateToTimestamp(value);
			case "id":
				return Utils.isNumber(value)
					? value
					: UtilsServer.decodeID(value as string);
			case "json": {
				if (typeof value === "string" && Utils.isStringified(value))
					return value;
				if (Utils.isObject(value)) {
					const cleanedObject = this.cleanObject(value as Data);
					if (cleanedObject) return Inison.stringify(cleanedObject);
				} else return Inison.stringify(value);
				return null;
			}
			default:
				return typeof value === "string" ? value.trim() : value;
		}
		return null;
	}

	private async checkUnique(tableName: string) {
		const tablePath = join(this.databasePath, tableName);
		const flattenSchema = Utils.flattenSchema(
			globalConfig[this.databasePath].tables?.get(tableName)?.schema ?? [],
		);
		function hasDuplicates(setA: Set<number>, setB: Set<number>) {
			for (const value of setA) if (setB.has(value)) return true; // Stop and return true if a duplicate is found
			return false; // No duplicates found
		}
		for await (const [_uniqueID, valueObject] of this.uniqueMap) {
			let index = 0;
			let shouldContinueParent = false; // Flag to manage parent loop continuation
			const mergedLineNumbers = new Set<number>();
			const fieldsKeys = [];
			for await (const [columnID, values] of valueObject.columnsValues) {
				index++;
				const field = flattenSchema.find(({ id }) => id === columnID);
				if (!field) continue;
				fieldsKeys.push(field.key);
				const [_, totalLines, lineNumbers] = await File.search(
					join(tablePath, `${field.key}${this.getFileExtension(tableName)}`),
					"[]",
					Array.from(values),
					undefined,
					valueObject.exclude,
					{ ...field, databasePath: this.databasePath },
					1,
					undefined,
					false,
					undefined,
					await this.overlayColumnOverrides(tableName, field.key),
				);
				if (totalLines > 0) {
					if (
						valueObject.columnsValues.size === 1 ||
						(valueObject.columnsValues.size === index &&
							!!(lineNumbers && hasDuplicates(lineNumbers, mergedLineNumbers)))
					) {
						this.uniqueMap.clear();

						if (valueObject.columnsValues.size > 1)
							throw this.createError("GROUP_UNIQUE", [
								fieldsKeys.join(" & "),
								field.key,
							]);

						throw this.createError("FIELD_UNIQUE", [
							fieldsKeys.join(" & "),
							Array.from(values).join(", "),
						]);
					}
					lineNumbers?.forEach(mergedLineNumbers.add, mergedLineNumbers);
				} else {
					shouldContinueParent = true; // Flag to skip the rest of this inner loop
					break; // Exit the inner loop
				}
			}
			if (shouldContinueParent) continue;
		}
		this.uniqueMap.clear();
	}

	private formatData<TData extends Record<string, any> & Partial<Data>>(
		data: TData & Data,
		schema: Schema,
		formatOnlyAvailiableKeys?: boolean,
	): TData & Data;
	private formatData<TData extends Record<string, any> & Partial<Data>>(
		data: (TData & Data) | (TData & Data)[],
		schema: Schema,
		formatOnlyAvailiableKeys?: boolean,
	): (TData & Data)[];
	private formatData<TData extends Record<string, any> & Partial<Data>>(
		data: (TData & Data) | (TData & Data)[],
		schema: Schema,
		formatOnlyAvailiableKeys?: boolean,
	): (TData & Data) | (TData & Data)[] {
		// formatData only reads its input (all transformations produce new
		// values), so no defensive clone is needed. Callers pass data they no
		// longer need, and skipping the copy halves the payload footprint of
		// every bulk post/put.
		const clonedData: (TData & Data) | (TData & Data)[] = data;
		if (Utils.isArrayOfObjects(clonedData))
			return clonedData.map((singleData) =>
				this.formatData(singleData, schema, formatOnlyAvailiableKeys),
			);
		if (Utils.isObject(clonedData)) {
			const RETURN: Record<string, any> = {};
			for (const field of schema) {
				if (!Object.hasOwn(clonedData, field.key)) {
					if (formatOnlyAvailiableKeys) RETURN[field.key] = "undefined";
					else RETURN[field.key] = this.getDefaultValue(field);
					continue;
				}
				if (
					Array.isArray(clonedData[field.key]) &&
					!clonedData[field.key].length
				) {
					RETURN[field.key] = this.getDefaultValue(field);
					continue;
				}
				RETURN[field.key] = this.formatField(
					clonedData[field.key],
					field,
					formatOnlyAvailiableKeys,
				);
			}
			return RETURN as TData & Data;
		}
		return [];
	}

	private getDefaultValue(field: Field): any {
		if (Array.isArray(field.type))
			return this.getDefaultValue({
				...field,
				type: field.type.sort(
					(a: FieldType, b: FieldType) =>
						Number(b === "array") - Number(a === "array") ||
						Number(a === "number") - Number(b === "number") ||
						Number(a === "string") - Number(b === "string"),
				)[0],
			} as Field);

		switch (field.type) {
			case "array":
			case "object": {
				if (!field.children || !Utils.isArrayOfObjects(field.children))
					return null;
				const RETURN: Record<string, any> = {};
				for (const f of field.children) RETURN[f.key] = this.getDefaultValue(f);
				return RETURN;
			}
			case "number":
				return 0;
			case "boolean":
				return false;
			default:
				return "";
		}
	}

	private _combineObjectsToArray(
		input: any[],
	): Record<
		string,
		string | boolean | number | null | (string | boolean | number | null)[]
	> {
		return input.reduce((result, current) => {
			for (const [key, value] of Object.entries(current))
				if (Object.hasOwn(result, key) && Array.isArray(result[key]))
					result[key].push(value);
				else result[key] = [value];

			return result;
		}, {});
	}
	private _CombineData(
		data: Data | Data[],
		prefix?: string,
	): Record<
		string,
		string | boolean | number | null | (string | boolean | number | null)[]
	> {
		if (Utils.isArrayOfObjects(data))
			return this._combineObjectsToArray(
				data.map((single_data) => this._CombineData(single_data)),
			);

		const RETURN: Record<
			string,
			string | boolean | number | null | (string | boolean | number | null)[]
		> = {};

		for (const [key, value] of Object.entries(data)) {
			if (Utils.isObject(value))
				Object.assign(
					RETURN,
					this._CombineData(value, `${(prefix ?? "") + key}.`),
				);
			else if (Utils.isArrayOfObjects(value)) {
				Object.assign(
					RETURN,
					this._CombineData(
						this._combineObjectsToArray(value),
						`${(prefix ?? "") + key}.`,
					),
				);
			} else if (
				Utils.isArrayOfArrays(value) &&
				value.every(Utils.isArrayOfObjects)
			)
				Object.assign(
					RETURN,
					this._CombineData(
						this._combineObjectsToArray(value.map(this._combineObjectsToArray)),
						`${(prefix ?? "") + key}.`,
					),
				);
			else if (value !== "undefined")
				RETURN[(prefix ?? "") + key] = File.encode(
					Array.isArray(value)
						? value.map((_value) =>
								typeof _value === "string" && _value === "undefined"
									? ""
									: _value,
							)
						: value,
				);
		}

		return RETURN;
	}

	private joinPathesContents(tableName: string, data: Data | Data[]) {
		const tablePath = join(this.databasePath, tableName);
		const combinedData = this._CombineData(data);
		const newCombinedData: Record<string, any> = {};

		for (const [key, value] of Object.entries(combinedData))
			newCombinedData[
				join(tablePath, `${key}${this.getFileExtension(tableName)}`)
			] = value;

		return newCombinedData;
	}

	private _processSchemaDataHelper(
		RETURN: Record<number, Data>,
		item: Data,
		index: number,
		field: Field,
	) {
		// If the item is an object, we need to process its children
		if (Utils.isObject(item)) {
			if (!RETURN[index]) RETURN[index] = {}; // Ensure the index exists
			if (!RETURN[index][field.key]) RETURN[index][field.key] = [];

			// Process children fields (recursive if needed)
			for (const child_field of (field.children as Schema).filter(
				(children) =>
					children.type === "array" &&
					Utils.isArrayOfObjects(children.children),
			)) {
				if (Utils.isObject(item[child_field.key])) {
					for (const [key, value] of Object.entries(item[child_field.key])) {
						for (let _i = 0; _i < value.length; _i++) {
							if (
								value[_i] === null ||
								(Array.isArray(value[_i]) && Utils.isArrayOfNulls(value[_i]))
							)
								continue;

							if (!RETURN[index][field.key][_i])
								RETURN[index][field.key][_i] = {};
							if (!RETURN[index][field.key][_i][child_field.key])
								RETURN[index][field.key][_i][child_field.key] = [];

							if (!Array.isArray(value[_i])) {
								if (!RETURN[index][field.key][_i][child_field.key][0])
									RETURN[index][field.key][_i][child_field.key][0] = {};
								RETURN[index][field.key][_i][child_field.key][0][key] =
									value[_i];
							} else {
								for (let _index = 0; _index < value[_i].length; _index++) {
									const element = value[_i][_index];
									if (element === null) continue;
									// Recursive call to handle nested structure
									this._processSchemaDataHelper(
										RETURN,
										element,
										_index,
										child_field,
									);

									// Perform property assignments
									if (!RETURN[index][field.key][_i][child_field.key][_index])
										RETURN[index][field.key][_i][child_field.key][_index] = {};
									RETURN[index][field.key][_i][child_field.key][_index][key] =
										element;
								}
							}
						}
					}
				}
			}
		}
	}
	private async processSchemaData<
		TData extends Record<string, any> & Partial<Data>,
	>(
		tableName: string,
		schema: Schema,
		linesNumber?: number[],
		options?: Options,
		prefix?: string,
	): Promise<Record<number, TData & Data>> {
		const RETURN: Record<number, TData & Data> = {};

		// Sparse path: for an explicit finite selection, stream each top-level
		// simple column only up to the last requested line (never to EOF) and
		// decode it independently, instead of pasting every column through a
		// shell pipeline that always scans the whole table and can misalign on
		// values containing a literal tab. Nested (prefixed) schemas keep the
		// per-column path below.
		let batchedKeys: Set<string> | null = null;
		if (!prefix && linesNumber?.length) {
			const simpleFields = schema.filter((field) =>
				this.isSimpleField(field.type),
			);
			const decodeID =
				globalConfig[this.databasePath].tables?.get(tableName)?.config
					.decodeID === true;
			const extension = this.getFileExtension(tableName);
			const reads = await Promise.all(
				simpleFields.map(async (field) => {
					const fieldPath = join(
						this.databasePath,
						tableName,
						`${field.key}${extension}`,
					);
					if (!(await File.isExists(fieldPath))) return null;
					const items = await File.getLines(fieldPath, linesNumber, {
						...field,
						type: field.key === "id" && decodeID ? "number" : field.type,
						databasePath: this.databasePath,
					});
					return { key: field.key, items };
				}),
			);
			batchedKeys = new Set(simpleFields.map((field) => field.key));
			for (const read of reads) {
				if (!read) continue;
				for (const [line, value] of Object.entries(read.items)) {
					if (typeof value === "undefined") continue;
					if (!RETURN[line]) RETURN[line] = {} as TData & Data;
					Object.assign(RETURN[line], { [read.key]: value });
				}
			}
		}

		for (const field of schema) {
			// Batch-read fields were already merged into RETURN.
			if (batchedKeys?.has(field.key)) continue;

			// If the field is of simple type (non-recursive), process it directly
			if (this.isSimpleField(field.type)) {
				await this.processSimpleField(
					tableName,
					field,
					RETURN,
					linesNumber,
					prefix,
				);
			} else if (this.isArrayField(field.type)) {
				// Process array fields (recursive if needed)
				await this.processArrayField(
					tableName,
					field,
					RETURN,
					linesNumber,
					options,
					prefix,
				);
			} else if (this.isObjectField(field.type)) {
				// Process object fields (recursive if needed)
				await this.processObjectField(
					tableName,
					field,
					RETURN,
					linesNumber,
					options,
					prefix,
				);
			} else if (this.isTableField(field.type)) {
				// Process table reference fields
				await this.processTableField(
					tableName,
					field,
					RETURN,
					linesNumber,
					options,
					prefix,
				);
			}
		}

		await this.mergeOverlayIntoRows(tableName, schema, RETURN);

		return RETURN;
	}

	/**
	 * Fold the table's un-compacted update-log overlay onto decoded rows.
	 *
	 * `RETURN` is keyed by line number and its `id` is the user-facing id, so
	 * the overlay (keyed by the internal numeric id) is matched through a fresh
	 * id-column read of just the requested lines. Only columns present in
	 * `schema` (which is already narrowed to the requested `columns`) are
	 * written, so a partial projection never grows extra keys. Legacy tables
	 * (no `.format` marker) return immediately.
	 */
	private async mergeOverlayIntoRows(
		tableName: string,
		schema: Schema,
		RETURN: Record<number, any>,
	): Promise<void> {
		if (!this.isLogTable(tableName)) return;
		const lines = Object.keys(RETURN).map(Number);
		if (!lines.length) return;

		const overlay = await this.getOverlay(tableName);
		if (!overlay || overlay.size === 0) return;

		const lineIds = await this.overlayLineIds(tableName, lines);
		if (!lineIds.size) return;

		const allowed = new Map<string, Field>();
		for (const field of schema) allowed.set(field.key, field);
		const hasUpdatedAt = allowed.has("updatedAt");

		for (const line of lines) {
			const id = lineIds.get(line);
			if (id === undefined) continue;
			const entry = await overlay.get(id);
			if (!entry) continue;
			if (entry.deleted) {
				delete RETURN[line];
				continue;
			}
			const row = RETURN[line];
			if (!row) continue;
			for (const [key, encoded] of Object.entries(entry.cols)) {
				const field = allowed.get(key);
				if (!field) continue;
				row[key] = File.decode(encoded as string | number, {
					...field,
					databasePath: this.databasePath,
				});
			}
			if (hasUpdatedAt && entry.updatedAt !== undefined)
				row.updatedAt = entry.updatedAt;
		}
	}

	private async livePageLines(
		tableName: string,
		page: number,
		perPage: number,
	): Promise<number[]> {
		const overlay = await this.getOverlay(tableName);
		if (!overlay?.deletedCount)
			return Array.from(
				{ length: perPage },
				(_, i) => (page - 1) * perPage + i + 1,
			);
		const result: number[] = [];
		let live = 0;
		for await (const [line, raw] of File.lines(
			join(
				this.databasePath,
				tableName,
				`id${this.getFileExtension(tableName)}`,
			),
		)) {
			if ((await overlay.get(Number(raw)))?.deleted) continue;
			live++;
			if (live > (page - 1) * perPage) result.push(line);
			if (result.length >= perPage) break;
		}
		return result;
	}

	/**
	 * Extract the raw expression from a field's `computed` property (string or
	 * persisted `{ expr, ast }` spec).
	 */
	private computedExprOf(field: Field): string {
		const computed = field.computed as string | ComputedFieldSpec;
		return typeof computed === "string" ? computed : (computed?.expr ?? "");
	}

	/**
	 * Every computed field of a schema as dotted keys (computed children of an
	 * array-of-objects column use their full path, e.g. `items.lineTotal`),
	 * with its raw expression — used for updateTable change detection.
	 */
	private computedEntries(schema: Schema): { key: string; expr: string }[] {
		const out: { key: string; expr: string }[] = [];
		const walk = (fields: Schema, prefix: string): void => {
			for (const field of fields) {
				const key = prefix ? `${prefix}.${field.key}` : field.key;
				if (typeof field.computed !== "undefined")
					out.push({ key, expr: this.computedExprOf(field) });
				if (field.children && Utils.isArrayOfObjects(field.children))
					walk(field.children, key);
			}
		};
		walk(schema, "");
		return out;
	}

	/**
	 * Compile every `computed` expression of a schema (which must already have
	 * ids assigned) into its persisted `{ expr, ast }` form, in dependency
	 * order. Throws `COMPUTED_FIELD_CYCLE` on cyclic fields. Used by DDL so the
	 * on-disk schema always carries compiled ASTs.
	 */
	private async compileComputedFields(schema: Schema): Promise<Schema> {
		const entries: {
			field: Field;
			key: string;
			elementRoot: { id: number; key: string } | null;
		}[] = [];
		const index = buildFieldIndex(schema);
		const walk = (fields: Schema, prefix: string): void => {
			for (const field of fields) {
				const key = prefix ? `${prefix}.${field.key}` : field.key;
				if (typeof field.computed !== "undefined") {
					const ref = index.get(field.id as number);
					entries.push({
						field,
						key,
						elementRoot: ref?.arrayAncestor
							? { id: ref.arrayAncestor.id, key: ref.arrayAncestor.key }
							: null,
					});
				}
				if (field.children && Utils.isArrayOfObjects(field.children))
					walk(field.children, key);
			}
		};
		walk(schema, "");
		if (!entries.length) return schema;

		const ctx: ResolveContext = {
			language: this.language,
			ownKey: "",
			index,
			getTableIndex: async (target: string) => this.tableFieldIndex(target),
			elementContext: null,
		};

		const resolved: {
			field: Field;
			key: string;
			elementRoot: { id: number; key: string } | null;
			ast: CompiledExpressionNode;
			deps: Set<number>;
		}[] = [];
		for (const entry of entries) {
			const ref = index.get(entry.field.id as number);
			if (!ref)
				throw this.createError("COMPUTED_FIELD_INVALID_TARGET", entry.key);
			if (entry.elementRoot) {
				// Element computed field (a child of an array-of-objects
				// column): must hold a plain value (never a container), and v1
				// keeps them numeric so writes are always summable.
				if (
					(ref.nestedInArrayOfArrays && ref.arrayAncestor) ||
					entry.field.type !== "number"
				)
					throw this.createError("COMPUTED_FIELD_INVALID_TARGET", entry.key);
				ctx.elementContext = {
					arrayRootId: entry.elementRoot.id,
				};
			} else {
				// Top-level computed field: cannot live inside an array.
				if (ref.arrayAncestor)
					throw this.createError("COMPUTED_FIELD_INVALID_TARGET", entry.key);
				ctx.elementContext = null;
			}
			ctx.ownKey = entry.key;
			const raw = parseExpression(
				this.computedExprOf(entry.field),
				this.language,
				entry.key,
			);
			const { ast, deps } = await resolveExpression(raw, ctx);
			resolved.push({
				field: entry.field,
				key: entry.key,
				elementRoot: entry.elementRoot,
				ast,
				deps,
			});
		}

		const ordered = topoSortComputedFields(
			resolved.map(({ field, deps }) => ({
				id: field.id as number,
				key: field.key,
				deps,
			})),
			this.language,
		);

		const specByKey = new Map<string, ComputedFieldSpec>();
		for (const meta of ordered) {
			const entry = resolved.find(({ field }) => field.id === meta.id);
			if (!entry) continue;
			specByKey.set(entry.key, {
				expr: this.computedExprOf(entry.field),
				ast: entry.ast,
			});
		}
		const applySpecs = (fields: Schema, prefix: string): Schema =>
			fields.map((field) => {
				const key = prefix ? `${prefix}.${field.key}` : field.key;
				let next: Field = field;
				if (typeof field.computed !== "undefined") {
					const spec = specByKey.get(key);
					if (spec) next = { ...field, computed: spec };
				}
				if (field.children && Utils.isArrayOfObjects(field.children))
					next = {
						...next,
						children: applySpecs(field.children, key),
					};
				return next;
			});
		return applySpecs(schema, "");
	}

	/**
	 * Build the evaluation plan (topological order + id index) for a table's
	 * computed fields. Throws on cycles or unresolvable expressions.
	 */
	private async buildComputedPlan(
		tableName: string,
		schema?: Schema,
	): Promise<ComputedPlan | null> {
		// Plans only depend on the persisted schema (compiled, id-based ASTs),
		// so cache per table and invalidate on schema changes. The explicit
		// `schema` argument (backfill during updateTable) always bypasses the
		// cache — the caller owns that freshly-migrated schema.
		if (schema === undefined) {
			const cached = this.computedPlanCache.get(tableName);
			if (cached !== undefined) return cached;
		}
		const s =
			schema ?? globalConfig[this.databasePath].tables?.get(tableName)?.schema;
		if (!s) return null;
		const index = buildFieldIndex(s);

		const fields: ComputedPlanField[] = [];
		const indexCache = new Map<string, Map<number, FieldRef>>();
		const ctx: ResolveContext = {
			language: this.language,
			ownKey: "",
			index,
			elementContext: null,
			getTableIndex: async (target: string) => {
				let cached = indexCache.get(target);
				if (!cached) {
					cached = await this.tableFieldIndex(target);
					if (cached) indexCache.set(target, cached);
				}
				return cached;
			},
		};

		// Collect every computed field: top-level ones and, when a schema
		// carries them, the computed children of array-of-objects columns.
		const walk = async (
			fieldsSchema: Schema,
			prefix: string,
		): Promise<void> => {
			for (const field of fieldsSchema) {
				const key = prefix ? `${prefix}.${field.key}` : field.key;
				if (typeof field.computed !== "undefined") {
					const ref = index.get(field.id as number);
					const elementRoot = ref?.arrayAncestor
						? { id: ref.arrayAncestor.id, key: ref.arrayAncestor.key }
						: null;
					const computed = field.computed as string | ComputedFieldSpec;
					if (typeof computed === "string") {
						ctx.ownKey = key;
						ctx.elementContext = elementRoot
							? { arrayRootId: elementRoot.id }
							: null;
						const raw = parseExpression(computed, this.language, key);
						const { ast, deps } = await resolveExpression(raw, ctx);
						fields.push({
							id: field.id as number,
							key,
							ast,
							deps,
							elementRoot,
						});
					} else
						fields.push({
							id: field.id as number,
							key,
							ast: computed.ast,
							deps: collectFieldDeps(computed.ast),
							elementRoot,
						});
				}
				if (field.children && Utils.isArrayOfObjects(field.children))
					await walk(field.children, key);
			}
		};
		await walk(s, "");
		if (!fields.length) {
			if (schema === undefined) this.computedPlanCache.set(tableName, null);
			return null;
		}

		const ordered = topoSortComputedFields(
			fields.map(({ id, key, deps }) => ({ id, key, deps })),
			this.language,
		);
		const byId = new Map(fields.map((f) => [f.id, f]));
		const planFields = ordered.map(
			(meta) => byId.get(meta.id) as ComputedPlanField,
		);
		const plan: ComputedPlan = {
			fields: planFields,
			index,
			hasHops: planFields.some((field) => astHasHops(field.ast)),
		};
		if (schema === undefined) this.computedPlanCache.set(tableName, plan);
		return plan;
	}

	/** Id index of a table's schema (link targets are re-resolved at write
	 *  time, so renames never retarget a compiled expression). */
	private async tableFieldIndex(
		tableName: string,
	): Promise<Map<number, FieldRef> | undefined> {
		const schema = await this.getTableSchema(tableName);
		return schema ? buildFieldIndex(schema) : undefined;
	}

	/**
	 * Evaluate a batch of (merged) rows against the table's computed fields.
	 * Returns `lineNo -> { computedKey -> value }` in dependency order.
	 *
	 * Batched link-hop reads: when the plan contains any link hop, a dry
	 * collection pass records every (table, column, id) triple the rows'
	 * expressions need (no file I/O), each distinct triple is then resolved
	 * exactly once — deduplicated across rows and fields — and a final pass
	 * evaluates against the warm cache. Plans without hops run the single
	 * evaluation pass unchanged.
	 */
	private async evaluateComputedRows(
		tableName: string,
		plan: ComputedPlan,
		rows: Record<number, Data>,
	): Promise<Record<number, ComputedLineValues>> {
		const out: Record<number, ComputedLineValues> = {};
		const indexCache = new Map<string, Map<number, FieldRef>>([
			[tableName, plan.index],
		]);
		const entries = Object.entries(rows);
		const reader = plan.hasHops ? this.createLinkReader() : null;
		if (reader) {
			for (const [, row] of entries)
				await this.evaluateRowComputed(
					tableName,
					plan,
					row as Data,
					indexCache,
					reader,
					true,
				);
			if (reader.hasPending) await reader.resolveAll();
		}
		for (const [line, row] of entries)
			out[Number(line)] = await this.evaluateRowComputed(
				tableName,
				plan,
				row as Data,
				indexCache,
				reader ?? undefined,
			);
		return out;
	}

	private createLinkReader(): LinkedRowReader {
		return new LinkedRowReader((table, column, id) =>
			this.readLinkedRow(table, id, column),
		);
	}

	/** Evaluate every computed field of one row (topological order) and merge
	 *  the results back into the row so dependent fields see them. */
	private async evaluateRowComputed(
		tableName: string,
		plan: ComputedPlan,
		row: Data,
		indexCache: Map<string, Map<number, FieldRef>>,
		links?: LinkedRowReader,
		collect = false,
	): Promise<ComputedLineValues> {
		const out: ComputedLineValues = {};
		// One structured frame per row, shared by every computed field: paths
		// resolve against the row in place (direct key-path reads), so no
		// flattened copy is ever built. Freshly evaluated values are written
		// back into the row — computed fields are top-level keys, so dependent
		// fields see earlier results through the same key-path reads.
		const env: ComputedEvalEnv = {
			table: tableName,
			index: plan.index,
			frame: row,
			row,
			strip: "",
			ownKey: "",
			indexCache,
			links,
			collect,
		};
		for (const field of plan.fields) {
			if (field.elementRoot) {
				// Element computed field (child of an array-of-objects column):
				// evaluate once per element (frame = element, strip =
				// `${rootKey}.`), write back into the element so other computed
				// fields and the flatten pass see it, and report the
				// per-element array under the dotted column key. Missing
				// operands read as 0 (`env.nullAsZero`), never an error.
				const rootKey = field.elementRoot.key;
				const childKey = field.key.slice(rootKey.length + 1);
				const elements = Array.isArray(env.row[rootKey])
					? (env.row[rootKey] as Data[])
					: [];
				const savedFrame = env.frame;
				const savedStrip = env.strip;
				const savedNullAsZero = env.nullAsZero;
				env.strip = `${rootKey}.`;
				env.ownKey = field.key;
				env.nullAsZero = true;
				const values: (number | string | null)[] = [];
				for (const element of elements) {
					if (!Utils.isObject(element)) {
						values.push(0);
						continue;
					}
					env.frame = element;
					const value = await this.evaluateNode(field.ast, env);
					const written = value === null || value === undefined ? 0 : value;
					element[childKey] = written;
					values.push(written);
				}
				env.frame = savedFrame;
				env.strip = savedStrip;
				env.nullAsZero = savedNullAsZero;
				out[field.key] = values;
				continue;
			}
			env.strip = "";
			env.ownKey = field.key;
			const value = await this.evaluateNode(field.ast, env);
			out[field.key] = value;
			row[field.key] = value;
		}
		return out;
	}

	private async evaluateNode(
		node: CompiledExpressionNode,
		env: ComputedEvalEnv,
	): Promise<number | string | null> {
		switch (node.kind) {
			case "num":
				return node.value;
			case "path":
				return this.evaluatePath(node, env);
			case "bin": {
				const a = await this.evaluateNode(node.left, env);
				const b = await this.evaluateNode(node.right, env);
				return this.applyBinaryOp(
					node.op,
					a,
					b,
					env.ownKey,
					env.collect,
					env.nullAsZero,
				);
			}
			case "fn": {
				const arrayRef = env.index.get(node.arrayFieldId);
				const arrayKey = arrayRef?.key;
				const raw = arrayKey ? env.row[arrayKey] : undefined;
				// formatData turns a missing/empty array-of-objects into `{}`;
				// treat anything that is not an actual array as empty.
				const elements = Array.isArray(raw) ? (raw as Data[]) : [];
				const values: number[] = [];
				// Reuse the env object across elements (only frame/strip
				// change) to avoid allocating a frame per element. Elements
				// are walked in place via direct key-path reads, so nothing is
				// flattened or cached.
				const savedFrame = env.frame;
				const savedStrip = env.strip;
				const stripPrefix = arrayKey ? `${arrayKey}.` : "";
				for (const element of elements) {
					if (!Utils.isObject(element)) continue;
					env.frame = element;
					env.strip = stripPrefix;
					const value = await this.evaluateNode(node.arg, env);
					if (value === null || value === undefined) continue;
					const num = this.coerceNumber(value, env.ownKey);
					values.push(num);
				}
				env.frame = savedFrame;
				env.strip = savedStrip;
				return this.aggregate(
					node.name,
					values,
					elements.length,
					env.ownKey,
					env.collect,
				);
			}
		}
	}

	/** Evaluate a path (`ids`, dot-separated link hops) against the current
	 *  frame. Returns `null` when an intermediate link value is missing. */
	private async evaluatePath(
		node: { kind: "path"; ids: number[] },
		env: ComputedEvalEnv,
	): Promise<number | string | null> {
		const ids = node.ids;
		let table = env.table;
		let index = env.index;
		let frame = env.frame;
		let strip = env.strip;
		let value: any;
		let ref: FieldRef | undefined;

		for (let i = 0; i < ids.length; i++) {
			ref = index.get(ids[i]);
			if (!ref)
				throw this.createError("COMPUTED_FIELD_UNKNOWN_FIELD", [
					env.ownKey,
					ids[i],
				]);
			const key =
				strip && ref.key.startsWith(strip)
					? ref.key.slice(strip.length)
					: ref.key;

			if (i === 0) {
				// Direct key-path read: walk the structured frame in place.
				value = resolveFramePath(frame, key);
				strip = "";
			} else {
				// `value` is the id of the row this hop lives in. Rows that
				// came off disk are eagerly resolved by processSchemaData, so
				// table children may already be linked objects — unwrap those
				// back to their id before the hop lookup. Nothing else hops.
				if (typeof value === "object" && value !== null)
					value = (value as Data & { id?: unknown }).id;
				if (
					value === undefined ||
					value === null ||
					value === "" ||
					(typeof value === "object" && value !== null)
				)
					return null;
				// A transaction cannot read a dependency table it has already
				// staged (no read-your-writes past its commit point).
				if (this.activeTransaction?.tables.has(table))
					throw this.createError("INVALID_PARAMETERS");
				// Batched link-hop reads: during the collection pass a hop
				// only records its (table, column, id) triple; the real pass
				// is served from the reader's warm cache. Without a reader
				// this is the plain per-hop engine read.
				const row = env.links
					? env.collect
						? (() => { env.links.record(table, ref.key, value); return null; })()
						: await env.links.read(table, ref.key, value)
					: await this.readLinkedRow(table, value, ref.key);
				if (!env.collect && (row === undefined || row === null))
					throw this.createError("COMPUTED_FIELD_DANGLING_LINK", [
						env.ownKey,
						table,
					]);
				// The linked row is the next frame, walked in place (no
				// flattened copy). readLinkedRow already fetched only the
				// `ref.key` column, so the frame is minimal.
				frame = row;
				value = row ? resolveFramePath(frame, ref.key) : null;
				index = (await this.indexFor(table, env.indexCache)) ?? index;
			}

			if (i < ids.length - 1) {
				if (ref.field.type !== "table" || typeof ref.field.table !== "string")
					throw this.createError("COMPUTED_FIELD_INVALID_LINK", [
						env.ownKey,
						ids[i + 1],
					]);
				table = ref.field.table;
				index = (await this.indexFor(table, env.indexCache)) ?? index;
			}
		}

		return value === undefined ? null : (value as number | string | null);
	}

	/** Id index lookup with a shared per-evaluation cache. */
	private async indexFor(
		tableName: string,
		cache: Map<string, Map<number, FieldRef>>,
	): Promise<Map<number, FieldRef> | undefined> {
		const cached = cache.get(tableName);
		if (cached) return cached;
		const index = await this.tableFieldIndex(tableName);
		if (index) cache.set(tableName, index);
		return index;
	}

	/** Read a single column of one linked row via `get`, or null when the
	 *  row does not exist (dangling link). */
	private async readLinkedRow(
		tableName: string,
		id: string | number,
		column: string,
	): Promise<Data | null> {
		const row = await this.get<Data>(
			tableName,
			id,
			{ columns: [column] },
			true,
		);
		return (row as Data) ?? null;
	}

	private coerceNumber(value: number | string, ownKey: string): number {
		const num = Number(value);
		if (!Number.isFinite(num))
			throw this.createError("COMPUTED_FIELD_ARITHMETIC", [
				ownKey,
				`non-numeric value '${String(value)}'`,
			]);
		return num;
	}

	private applyBinaryOp(
		op: BinaryOp,
		a: number | string | null,
		b: number | string | null,
		ownKey: string,
		collect = false,
		nullAsZero = false,
	): number {
		if (a === null || a === undefined || b === null || b === undefined) {
			// Collection passes must tolerate unresolved (null) link hops:
			// the pass only discovers which links are needed, so a neutral
			// result is fine. Real evaluation still throws.
			if (collect) return 0;
			// Element computed evaluation treats a missing operand as the
			// value 0 (per the element-sum feature), so a single missing
			// child never aborts the write.
			if (nullAsZero) {
				if (a === null || a === undefined) a = 0;
				if (b === null || b === undefined) b = 0;
			}
		}
		if (a === null || a === undefined || b === null || b === undefined)
			throw this.createError("COMPUTED_FIELD_ARITHMETIC", [
				ownKey,
				"missing or null operand",
			]);
		const an = this.coerceNumber(a, ownKey);
		const bn = this.coerceNumber(b, ownKey);
		switch (op) {
			case "add":
				return an + bn;
			case "sub":
				return an - bn;
			case "mul":
				return an * bn;
			case "div":
				if (bn === 0)
					throw this.createError("COMPUTED_FIELD_ARITHMETIC", [
						ownKey,
						"division by zero",
					]);
				return an / bn;
			case "mod":
				if (bn === 0)
					throw this.createError("COMPUTED_FIELD_ARITHMETIC", [
						ownKey,
						"modulo by zero",
					]);
				return an % bn;
		}
	}

	private aggregate(
		name: ComputedFunctionName,
		values: number[],
		elementCount: number,
		ownKey: string,
		collect = false,
	): number {
		switch (name) {
			case "count":
				// Aggregates iterate the row's actual array, so count is the
				// element count (regardless of value presence).
				return elementCount;
			case "sum":
				return values.reduce((acc, v) => acc + v, 0);
			case "avg": {
				if (!values.length) {
					// Collection passes may have skipped every value of an
					// array whose elements only held unresolved link hops.
					if (collect) return 0;
					throw this.createError("COMPUTED_FIELD_ARITHMETIC", [
						ownKey,
						"average over no values",
					]);
				}
				return values.reduce((acc, v) => acc + v, 0) / values.length;
			}
			case "min": {
				if (!values.length) {
					if (collect) return 0;
					throw this.createError("COMPUTED_FIELD_ARITHMETIC", [
						ownKey,
						"min over no values",
					]);
				}
				return Math.min(...values);
			}
			case "max": {
				if (!values.length) {
					if (collect) return 0;
					throw this.createError("COMPUTED_FIELD_ARITHMETIC", [
						ownKey,
						"max over no values",
					]);
				}
				return Math.max(...values);
			}
		}
	}

	/** Merge evaluated per-line computed values into a `pathesContents` map
	 *  as line-numbered replace records (encoded cells). */
	private mergeComputedLineRecords(
		tableName: string,
		plan: ComputedPlan,
		evaluated: Record<number, ComputedLineValues>,
		pathesContents: Record<string, any>,
		existing?: Record<number, Data>,
	): void {
		for (const field of plan.fields) {
			const path = join(
				this.databasePath,
				tableName,
				`${field.key}${this.getFileExtension(tableName)}`,
			);
			const entries = Object.entries(evaluated);
			// When the pre-update rows are available, compare each column's
			// re-evaluated line values against the stored ones (deterministic
			// encode). A column that is identical for every evaluated line is
			// left untouched — no content buffer, no File.replace, no fsync.
			if (existing) {
				let matches = true;
				for (const [line, values] of entries) {
					if (!Object.hasOwn(values, field.key)) continue;
					const lineValue = values[field.key] as number | string | null;
					const old = existing[Number(line)]?.[field.key];
					if (old === undefined || !this.sameCellValue(lineValue, old)) {
						matches = false;
						break;
					}
				}
				if (matches) continue;
			}
			const content: Record<number, string | number | boolean | null> =
				(pathesContents[path] as Record<
					number,
					string | number | boolean | null
				>) ?? {};
			for (const [line, values] of entries)
				if (Object.hasOwn(values, field.key) && values[field.key] !== undefined)
					content[Number(line)] = File.encode(
						values[field.key] as number | string | null,
					);
			pathesContents[path] = content;
		}
	}

	/** Compare a freshly evaluated cell value against a stored (already
	 *  decoded) one — both are scalar or index-aligned element arrays. */
	private sameCellValue(
		fresh: number | string | null,
		stored: unknown,
	): boolean {
		if (fresh === stored) return true;
		if (
			Array.isArray(fresh) &&
			Array.isArray(stored) &&
			fresh.length === stored.length
		) {
			for (let i = 0; i < fresh.length; i++)
				if (fresh[i] !== stored[i]) return false;
			return true;
		}
		return File.encode(fresh) === File.encode(stored as any);
	}

	// Helper function to determine if a field is simple
	private isSimpleField(fieldType: FieldType | FieldType[] | Schema): boolean {
		const complexTypes = ["array", "object", "table"];
		if (Array.isArray(fieldType))
			return fieldType.every(
				(type) => typeof type === "string" && !complexTypes.includes(type),
			);

		return !complexTypes.includes(fieldType);
	}

	// Process a simple field (non-recursive)
	private async processSimpleField(
		tableName: string,
		field: Field,
		RETURN: Record<number, Data>,
		linesNumber?: number[],
		prefix?: string,
	) {
		const fieldPath = join(
			this.databasePath,
			tableName,
			`${prefix ?? ""}${field.key}${this.getFileExtension(tableName)}`,
		);
		if (await File.isExists(fieldPath)) {
			const items = await File.get(fieldPath, linesNumber, {
				...field,
				type:
					field.key === "id" &&
					globalConfig[this.databasePath].tables?.get(tableName)?.config
						.decodeID
						? "number"
						: field.type,
				databasePath: this.databasePath,
			});
			if (items) {
				for (const [index, item] of Object.entries(items)) {
					if (typeof item === "undefined") continue; // Skip undefined items
					if (!RETURN[index]) RETURN[index] = {}; // Ensure the index exists
					RETURN[index][field.key] = item; // Assign item to the RETURN object
				}
			}
		}
	}

	// Helper function to check if the field type is array
	private isArrayField(fieldType: FieldType | FieldType[] | Schema): boolean {
		return (
			(Array.isArray(fieldType) &&
				fieldType.every((type) => typeof type === "string") &&
				fieldType.includes("array")) ||
			fieldType === "array"
		);
	}

	// Process array fields (recursive if needed)
	private async processArrayField(
		tableName: string,
		field: Field,
		RETURN: Record<number, Data>,
		linesNumber?: number[],
		options?: Options,
		prefix?: string,
	) {
		if (Array.isArray(field.children)) {
			if (this.isSimpleField(field.children)) {
				await this.processSimpleField(
					tableName,
					field,
					RETURN,
					linesNumber,
					prefix,
				);
			} else if (this.isTableField(field.children)) {
				await this.processTableField(
					tableName,
					field,
					RETURN,
					linesNumber,
					options,
					prefix,
				);
			} else {
				let _fieldChildren = field.children as Schema;
				// Handling array of objects and filtering nested arrays
				const nestedArrayFields = _fieldChildren.filter(
					(children: Field) =>
						children.type === "array" &&
						Utils.isArrayOfObjects(children.children),
				) as Schema;
				if (nestedArrayFields.length > 0) {
					// one of children has array field type and has children array of object = Schema
					const childItems = await this.processSchemaData(
						tableName,
						nestedArrayFields,
						linesNumber,
						options,
						`${(prefix ?? "") + field.key}.`,
					);

					if (childItems)
						for (const [index, item] of Object.entries(childItems))
							this._processSchemaDataHelper(RETURN, item, index, field);

					// Remove nested arrays after processing
					_fieldChildren = _fieldChildren.filter(
						(children: Field) =>
							!nestedArrayFields.map(({ key }) => key).includes(children.key),
					) as Schema;
				}

				// Process remaining items for the field's children
				const items = await this.processSchemaData(
					tableName,
					_fieldChildren,
					linesNumber,
					options,
					`${(prefix ?? "") + field.key}.`,
				);

				// Process the items after retrieval
				if (items) {
					for (const [index, item] of Object.entries(items)) {
						if (typeof item === "undefined") continue; // Skip undefined items
						if (!RETURN[index]) RETURN[index] = {};
						if (Utils.isObject(item)) {
							const itemEntries = Object.entries(item);
							// Values without a second per-row tuple array.
							const itemValues = Object.values(item);
							if (!Utils.isArrayOfNulls(itemValues)) {
								if (RETURN[index][field.key])
									for (let _index = 0; _index < itemEntries.length; _index++) {
										const [key, value] = itemEntries[_index];
										for (let _index = 0; _index < value.length; _index++) {
											if (value[_index] === null) continue;
											if (RETURN[index][field.key][_index])
												Object.assign(RETURN[index][field.key][_index], {
													[key]: value[_index],
												});
											else
												RETURN[index][field.key][_index] = {
													[key]: value[_index],
												};
										}
									}
								else if (
									itemValues.every((_i) => Utils.isArrayOfArrays(_i)) &&
									prefix
								)
									RETURN[index][field.key] = item;
								else {
									RETURN[index][field.key] = [];
									for (let _index = 0; _index < itemEntries.length; _index++) {
										const [key, value] = itemEntries[_index];
										if (!Array.isArray(value)) {
											RETURN[index][field.key][_index] = {};
											RETURN[index][field.key][_index][key] = value;
										} else
											for (let _i = 0; _i < value.length; _i++) {
												if (
													value[_i] === null ||
													(Array.isArray(value[_i]) &&
														Utils.isArrayOfNulls(value[_i]))
												)
													continue;

												if (!RETURN[index][field.key][_i])
													RETURN[index][field.key][_i] = {};
												RETURN[index][field.key][_i][key] = Array.isArray(
													value[_i],
												)
													? value[_i].filter(Boolean)
													: value[_i];
											}
									}
								}
							}
						} else RETURN[index][field.key] = item;
					}
				}
			}
		} else if (field.children != null && this.isSimpleField(field.children)) {
			// If `children` is FieldType, handle it as an array of simple types (no recursion needed here)
			await this.processSimpleField(
				tableName,
				field,
				RETURN,
				linesNumber,
				prefix,
			);
		} else if (field.children != null && this.isTableField(field.children)) {
			await this.processTableField(
				tableName,
				field,
				RETURN,
				linesNumber,
				options,
				prefix,
			);
		}
	}

	// Helper function to check if the field type is object
	private isObjectField(fieldType: FieldType | FieldType[] | Schema): boolean {
		return (
			fieldType === "object" ||
			(Array.isArray(fieldType) &&
				fieldType.every((type) => typeof type === "string") &&
				fieldType.includes("object"))
		);
	}

	// Process object fields (recursive if needed)
	private async processObjectField(
		tableName: string,
		field: Field,
		RETURN: Record<number, Data>,
		linesNumber?: number[],
		options?: Options,
		prefix?: string,
	) {
		if (Array.isArray(field.children)) {
			// If `children` is a Schema (array of Field objects), recurse
			const items = await this.processSchemaData(
				tableName,
				field.children as Schema,
				linesNumber,
				options,
				`${prefix ?? ""}${field.key}.`,
			);
			for (const [index, item] of Object.entries(items)) {
				if (typeof item === "undefined") continue; // Skip undefined items
				if (!RETURN[index]) RETURN[index] = {};
				if (Utils.isObject(item)) {
					if (!Object.values(item).every((i) => i === null || i === 0))
						RETURN[index][field.key] = item;
				}
			}
		}
	}

	// Helper function to check if the field type is table
	private isTableField(fieldType: FieldType | FieldType[] | Schema): boolean {
		return (
			fieldType === "table" ||
			(Array.isArray(fieldType) &&
				fieldType.every((type) => typeof type === "string") &&
				fieldType.includes("table"))
		);
	}

	// Process table reference fields
	private async processTableField(
		tableName: string,
		field: Field,
		RETURN: Record<number, Data>,
		linesNumber?: number[],
		options?: Options,
		prefix?: string,
	) {
		if (
			field.table &&
			(await File.isExists(join(this.databasePath, field.table)))
		) {
			const fieldPath = join(
				this.databasePath,
				tableName,
				`${prefix ?? ""}${field.key}${this.getFileExtension(tableName)}`,
			);
			if (await File.isExists(fieldPath)) {
				// add table to globalConfig
				await this.loadTable(field.table);

				const itemsIDs = (await File.get(fieldPath, linesNumber, {
					...field,
					databasePath: this.databasePath,
				})) as Record<number, number | number[]>;

				if (itemsIDs) {
					const searchableIDs = new Map<
						number,
						number | string | (number | string)[]
					>();
					for (const [lineNumber, lineContent] of Object.entries(itemsIDs)) {
						if (typeof lineContent === "undefined") continue; // Skip undefined items
						if (!RETURN[lineNumber]) RETURN[lineNumber] = {};
						if (lineContent !== null && lineContent !== undefined)
							searchableIDs.set(lineNumber, lineContent);
					}

					if (searchableIDs.size) {
						const items = await this.get(
							field.table,
							Array.from(new Set(Array.from(searchableIDs.values()).flat()))
								.flat()
								.filter((item) => item),
							{
								...options,
								perPage: -1,
								columns: (options?.columns as string[] | undefined)
									?.filter((column) => column.includes(`${field.key}.`))
									.map((column) => column.replace(`${field.key}.`, "")),
							},
						);

						const formatLineContent = (
							lineContent?: string | number | (string | number)[],
						): Data | Data[] | string | number | undefined =>
							Array.isArray(lineContent)
								? lineContent
										.map((singleContent) =>
											singleContent
												? Array.isArray(singleContent)
													? singleContent.map(formatLineContent)
													: items?.find(({ id }) => singleContent === id)
												: singleContent,
										)
										.filter((item) => item !== undefined)
								: items?.find(({ id }) => lineContent === id);
						for (const [lineNumber, lineContent] of searchableIDs.entries()) {
							if (!lineContent) continue;
							const formatedLineContent = formatLineContent(lineContent);
							if (
								formatedLineContent &&
								(!Array.isArray(formatedLineContent) ||
									formatedLineContent.length > 0)
							)
								RETURN[lineNumber][field.key] = formatedLineContent;
						}
					}
				}
			}
		}
	}

	private _setNestedKey(obj: any, path: string, value: any): void {
		const keys = path.split(".");
		const lastKey = keys.pop();
		const target = keys.reduce((acc, key) => {
			if (typeof acc[key] !== "object" || acc[key] === null) {
				acc[key] = {};
			}
			return acc[key];
		}, obj);
		if (lastKey !== undefined) target[lastKey] = value;
	}
	private async applyCriteria<
		TData extends Record<string, any> & Partial<Data>,
	>(
		tableName: string,
		options: Options,
		criteria?: Criteria,
		allTrue?: boolean,
		searchIn?: Set<number>,
	): Promise<Record<number, TData & Data> | null> {
		const tablePath = join(this.databasePath, tableName);

		let RETURN: Record<number, TData & Data> = {};

		if (!criteria || Object.keys(criteria).length === 0) return null;

		const criteriaAND = criteria.and;
		if (criteriaAND) delete criteria.and;

		const criteriaOR = criteria.or;
		if (criteriaOR) delete criteria.or;

		const schema =
			globalConfig[this.databasePath].tables?.get(tableName)?.schema ?? [];

		if (Object.keys(criteria).length) {
			if (allTrue === undefined) allTrue = true;

			for await (let [key, value] of Object.entries(criteria)) {
				const field = Utils.getField(key, schema);
				if (!field) continue;

				if (field.table && Utils.isObject(value)) {
					const items = await this.get(field.table, value as Criteria, {
						columns: "id",
						perPage: -1,
					});
					if (items?.length) value = `[]${items.map(({ id }) => id)}`;
					else if (allTrue) return null;
				}

				let searchOperator:
					| ComparisonOperator
					| ComparisonOperator[]
					| undefined;
				let searchComparedAtValue:
					| string
					| number
					| boolean
					| null
					| (string | number | boolean | null)[]
					| undefined;
				let searchLogicalOperator: "and" | "or" | undefined;

				if (Utils.isObject(value)) {
					/* nested object with .and / .or inside */
					const nestedAnd = (value as NonNullable<Criteria>).and;
					const nestedOr = (value as NonNullable<Criteria>).or;
					if (nestedAnd || nestedOr) {
						const logicalChild = nestedAnd ?? nestedOr;
						const logic: "and" | "or" = nestedAnd ? "and" : "or";

						if (logicalChild && !Array.isArray(logicalChild)) {
							const crit = Object.entries(logicalChild)
								.map((item) =>
									typeof item[1] === "string"
										? Utils.FormatObjectCriteriaValue(item[1] as string)
										: ["=", item[1]],
								)
								.filter(Boolean) as [ComparisonOperator, any][];

							if (crit.length) {
								searchOperator = crit.map((c) => c[0]);
								searchComparedAtValue = crit.map((c) => c[1]);
								searchLogicalOperator = logic;
							}
						} else if (Array.isArray(logicalChild)) {
							const crit = (
								logicalChild as (string | number | boolean | null)[]
							)
								.map((item) =>
									typeof item === "string"
										? Utils.FormatObjectCriteriaValue(item)
										: ["=", item],
								)
								.filter(Boolean) as [ComparisonOperator, any][];

							if (crit.length) {
								searchOperator = crit.map((c) => c[0]);
								searchComparedAtValue = crit.map((c) => c[1]);
								searchLogicalOperator = logic;
							}
						}

						delete (value as NonNullable<Criteria>)[logic];
					}
				} else if (typeof value === "string") {
					const [op, val] = Utils.FormatObjectCriteriaValue(value);
					searchOperator = op;
					searchComparedAtValue = val;
				} else {
					searchOperator = "=";
					searchComparedAtValue = value;
				}

				const searchStarted = performance.now();
				const [searchResult, totalLines, linesNumbers] = await File.search(
					join(tablePath, `${key}${this.getFileExtension(tableName)}`),
					searchOperator ?? "=",
					searchComparedAtValue ?? null,
					searchLogicalOperator,
					searchIn,
					{
						...field,
						databasePath: this.databasePath,
						table: field.table ?? tableName,
					},
					(options.perPage ?? 0) < 0 ? undefined : options.perPage,
					(options.perPage ?? 0) < 0
						? undefined
						: ((options.page as number) - 1) * (options.perPage as number) +
								((options.page ?? 1) > 1 ? 1 : 0),
					true,
					undefined,
					await this.overlayColumnOverrides(tableName, key),
				);
				if (
					!this.closed &&
					!this.activeTransaction &&
					!searchIn &&
					!key.includes(".") &&
					!field.table &&
					!field.computed &&
					searchOperator === "=" &&
					!searchLogicalOperator &&
					[
						"string",
						"text",
						"textarea",
						"html",
						"url",
						"email",
						"number",
						"date",
						"timestamp",
						"time",
						"id",
					].includes(String(field.type)) &&
					(typeof searchComparedAtValue === "number" ||
						(typeof searchComparedAtValue === "string" &&
							searchComparedAtValue !== "" &&
							!Utils.isNumber(searchComparedAtValue) &&
							!/^[{[]/.test(searchComparedAtValue)))
				) {
					observeEqualityScan(
						this.resources,
						tablePath,
						key,
						performance.now() - searchStarted,
						() => this.buildAutomaticIndex(tableName, key),
					);
				}
				if (!searchResult) {
					if (allTrue) return null;
					continue;
				}

				// Merge matched lines into RETURN. The old code round-tripped through
				// Object.entries(...).map(...) + Object.fromEntries, allocating two
				// tuple arrays + a map array per matched row; building the nested
				// result object directly keeps the exact same semantics with less
				// garbage. Note: in `allTrue` mode RETURN is *replaced* per key
				// (searchIn narrowing is what enforces the AND), so the assignment
				// below intentionally mirrors the original replace/merge behavior.
				const formatedSearchResult: Record<string, Data> = {};
				for (const id of Object.keys(searchResult)) {
					const nestedObj: Record<string, any> = {};
					this._setNestedKey(nestedObj, key, searchResult[id]);
					formatedSearchResult[id] = nestedObj;
				}

				RETURN = allTrue
					? formatedSearchResult
					: Utils.deepMerge(RETURN, formatedSearchResult);

				this.totalItems.set(`${tableName}-${key}`, totalLines);

				if (linesNumbers?.size && allTrue) searchIn = linesNumbers;
			}
		}

		if (criteriaAND && Utils.isObject(criteriaAND)) {
			const searchResult = await this.applyCriteria(
				tableName,
				criteriaOR ? { ...(options ?? {}), perPage: -1 } : options,
				criteriaAND as Criteria,
				true,
				searchIn,
			);

			if (searchResult) {
				searchIn = new Set(Object.keys(searchResult).map(Number));
				RETURN = Utils.deepMerge(
					RETURN,
					Object.fromEntries(
						Object.entries(searchResult).filter(
							([_k, v], _i) =>
								Object.keys(v).filter((key) =>
									Object.keys(criteriaAND).find(
										(criteriaKey) =>
											criteriaKey === key || criteriaKey.startsWith(`${key}.`),
									),
								).length,
						),
					),
				);
			} else return null;
		}

		if (criteriaOR && Utils.isObject(criteriaOR)) {
			const searchResult = await this.applyCriteria(
				tableName,
				options,
				criteriaOR as Criteria,
				false,
				searchIn,
			);

			if (searchResult) {
				RETURN = Utils.deepMerge(RETURN, searchResult);

				// Filter RETURN in place instead of rebuilding it through
				// Object.entries/fromEntries on every OR iteration. The key list of
				// criteriaOR is hoisted out of the per-row check as well.
				const orKeys = Object.keys(criteriaOR);
				for (const id of Object.keys(RETURN)) {
					const item = RETURN[id];
					const matches = Object.keys(item).some(
						(key) =>
							orKeys.includes(key) ||
							orKeys.some((criteriaKey) => criteriaKey.startsWith(`${key}.`)),
					);
					if (!matches) delete RETURN[id];
				}
				if (!Object.keys(RETURN).length) RETURN = {};
			} else RETURN = {};
		}

		return Object.keys(RETURN).length ? RETURN : null;
	}

	private _filterSchemaByColumns(schema: Schema, columns: string[]): Schema {
		return schema
			.map((field) => {
				if (columns.some((column) => column.startsWith("!")))
					return columns.includes(`!${field.key}`) ? null : field;

				if (columns.includes(field.key) || columns.includes("*")) return field;

				if (
					(field.type === "array" || field.type === "object") &&
					Utils.isArrayOfObjects(field.children) &&
					columns.filter(
						(column) =>
							column.startsWith(`${field.key}.`) ||
							column.startsWith(`!${field.key}.`),
					).length
				) {
					field.children = this._filterSchemaByColumns(
						field.children,
						columns
							.filter(
								(column) =>
									column.startsWith(`${field.key}.`) ||
									column.startsWith(`!${field.key}.`),
							)
							.map((column) => column.replace(`${field.key}.`, "")),
					);
					return field;
				}
				return null;
			})
			.filter((i) => i) as Schema;
	}

	/**
	 * Clear table cache
	 *
	 * @param {string} tableName
	 */
	public async clearCache(tableName: string) {
		this.validateName(tableName);

		const cacheFolderPath = join(this.databasePath, tableName, ".cache");
		await mkdir(cacheFolderPath, { recursive: true });
		// Query-cache invalidation must not unlink another reader's private
		// overlay storage. It is independently invalidated by log generations.
		for (const name of await readdir(cacheFolderPath))
			if (!name.startsWith("overlay-"))
				await rm(join(cacheFolderPath, name), { recursive: true, force: true });
	}

	/**
	 * Commit a multi-file mutation crash-atomically:
	 * 1. fsync every freshly-written temp file;
	 * 2. write the journal `begin` entry and fsync it;
	 * 3. rename the pagination metadata file first (atomic publication point:
	 *    the row count flips in a single rename, which is what lock-free
	 *    readers observe) and then swap each live file aside (backup) and
	 *    rename the temp into place;
	 * 4. write the journal `commit` marker and fsync it;
	 * 5. discard backups/temps + the journal, fsync the directories.
	 *
	 * On any failure before `commit`, the journal is rolled back so the table
	 * is left exactly as it was. `renameList` entries are [tempPath, livePath]
	 * pairs; a null tempPath means a pure removal (live file taken out).
	 */
	private async commitFiles(
		tablePath: string,
		renameList: (string | null)[][],
		pagination: { from: string; to: string } | null,
	): Promise<void> {
		await this.prepareAccelerators(tablePath, renameList);
		const txn = randomUUID();
		const ops: JournalFileOp[] = [];
		// Backups are parked in a per-transaction subdirectory
		// (.tmp/backup/<txn>/), so a later transaction can never collide with
		// the leftovers of an earlier crashed one.
		const backupDir = join(tablePath, ".tmp", "backup", txn);
		await mkdir(backupDir, { recursive: true });
		await File.syncDir(join(tablePath, ".tmp", "backup"));
		for (const [tmp, live] of renameList) {
			if (!live) continue;
			ops.push({
				live,
				backup: join(backupDir, basename(live)),
				tmp,
				existed: await File.isExists(live),
			});
		}

		const journal = new Journal(tablePath, txn);
		let commitAttempted = false;
		let cleanupSafe = false;
		try {
			// Make every replacement durable before it can be published.
			await settleWrites(
				await Promise.allSettled(
					ops
						.filter((op) => op.tmp)
						.map(async (op) => File.syncFile(op.tmp as string)),
				),
			);
			await File.syncDir(join(tablePath, ".tmp"));

			await journal.begin(ops, pagination);
			await File.syncDir(join(tablePath, ".tmp"));

			// Publish: the pagination rename is the atomic publication point
			// (row count flips in one rename) and MUST come first — readers
			// that snapshot file identities detect the flip and retry. Then
			// park each original and move the replacement in.
			if (pagination) await rename(pagination.from, pagination.to);
			for (const op of ops) {
				if (op.existed) await rename(op.live, op.backup);
				if (op.tmp) await rename(op.tmp, op.live);
			}
			await File.syncDir(backupDir);
			await File.syncDir(join(tablePath, ".tmp"));
			await File.syncDir(tablePath);

			commitAttempted = true;
			await journal.commit();
			cleanupSafe = true;
		} catch (error) {
			if (!commitAttempted) {
				await journal.rollback();
				cleanupSafe = true;
			}
			// A commit-fsync error has an unknown outcome: retain recovery state.
			throw error;
		} finally {
			await journal.dispose();
			if (cleanupSafe) {
				await Promise.allSettled(
					ops.map((op) => unlink(op.backup).catch(() => {})),
				);
				await rm(backupDir, { recursive: true, force: true });
				await File.syncDir(join(tablePath, ".tmp", "backup"));
				await unlink(journal.path).catch((error: any) => {
					if (error?.code !== "ENOENT") throw error;
				});
				await File.syncDir(join(tablePath, ".tmp"));
				await File.syncDir(tablePath);
			}
		}
	}

	/**
	 * Runs crash recovery for a table (and any crashed database transaction)
	 * before a read. Mutation paths get the same guarantee implicitly (the
	 * writer lock runs recovery on acquire); reads call this explicitly
	 * because they never take the table lock.
	 */
	private async ensureTableRecovered(tableName: string): Promise<void> {
		const tablePath = join(this.databasePath, tableName);
		if (await File.isExists(join(tablePath, ".tmp", "journal.jsonl"))) {
			await File.lock(join(tablePath, ".tmp"));
			await File.unlock(join(tablePath, ".tmp"));
		}
		// A database journal exists only while a live transaction holds the
		// database lock, or after one crashed. Recovery must never roll back a
		// live transaction, so acquire the database lock non-blocking here:
		// on success the previous owner is gone (recovery ran); on failure a
		// live transaction owns the lock across processes and readers simply
		// proceed against the committed state.
		const dbTmp = join(this.databasePath, ".tmp");
		if (await File.isExists(join(dbTmp, "journal.jsonl"))) {
			if (await File.tryLock(dbTmp)) await File.unlock(dbTmp);
		}
	}

	/**
	 * Blocking database-journal recovery, used by mutation paths (writers are
	 * serialized with live transactions on the database lock anyway).
	 */
	private async ensureDatabaseRecovered(): Promise<void> {
		const dbTmp = join(this.databasePath, ".tmp");
		if (await File.isExists(join(dbTmp, "journal.jsonl"))) {
			await File.lock(dbTmp);
			await File.unlock(dbTmp);
		}
	}

	private async ensureDatabaseTmpDir(): Promise<void> {
		await mkdir(join(this.databasePath, ".tmp"), { recursive: true });
	}

	/** Staged per-table entry of the open transaction, or null when none. */
	private txnTableEntry(tableName: string): TxnTableEntry | null {
		const txn = this.activeTransaction;
		if (!txn) return null;
		let entry = txn.tables.get(tableName);
		if (!entry) {
			entry = {
				locked: false,
				paginationFrom: "",
				lastId: 0,
				total: 0,
				staged: [],
			};
			txn.tables.set(tableName, entry);
		}
		return entry;
	}

	/** Lock a table for the open transaction (idempotent per transaction). */
	private async ensureTxnLock(tableName: string): Promise<void> {
		const entry = this.txnTableEntry(tableName);
		if (!entry) return;
		if (!entry.locked) {
			await File.lock(join(this.databasePath, tableName, ".tmp"));
			entry.locked = true;
		}
		await this.leaveAutomaticDeltas(tableName);
	}

	/**
	 * Resolve the pagination state a DML op should build on. Outside a
	 * transaction this reads the live pagination file (as before); inside a
	 * transaction the first touch reads it once and the entry keeps the staged
	 * id/count so chained ops (guarded to one per table) and commit() stay
	 * consistent without publishing anything early.
	 */
	private async resolvePagination(tableName: string): Promise<{
		filePath: string;
		lastId: number;
		total: number;
	}> {
		const tablePath = join(this.databasePath, tableName);
		const entry = this.txnTableEntry(tableName);
		if (entry?.paginationFrom) {
			return {
				filePath: entry.paginationFrom,
				lastId: entry.lastId,
				total: entry.total,
			};
		}
		let paginationFilePath = "";
		for await (const fileName of glob("*.pagination", { cwd: tablePath }))
			paginationFilePath = join(tablePath, fileName);
		const [lastId, total] = parse(paginationFilePath)
			.name.split("-")
			.map(Number) as [number, number];
		if (entry) {
			entry.paginationFrom = paginationFilePath;
			entry.lastId = lastId;
			entry.total = total;
		}
		return { filePath: paginationFilePath, lastId, total };
	}

	/**
	 * Stage one table mutation into the open transaction: fsync its temps and
	 * append an `op` entry to the database journal (no live file is touched;
	 * commit() performs the actual renames). One staged mutation per table per
	 * transaction (multi-table atomicity; a second touch of the same table
	 * would need read-your-writes composition).
	 */
	private async stageTxnOp(
		tableName: string,
		renameList: (string | null)[][],
		pagination: { from: string; to: string } | null,
	): Promise<void> {
		await this.prepareAccelerators(
			join(this.databasePath, tableName),
			renameList,
		);
		const txn = this.activeTransaction;
		const entry = this.txnTableEntry(tableName);
		if (!txn || !entry) throw this.createError("INVALID_PARAMETERS");
		if (entry.staged.length) throw this.createError("INVALID_PARAMETERS");
		const backupDir = join(this.databasePath, ".tmp", "backup", txn.id);
		await mkdir(backupDir, { recursive: true });
		const ops: JournalFileOp[] = [];
		for (const [tmp, live] of renameList) {
			if (!live) continue;
			// Benchmarks must be unique within the whole transaction: the same
			// column basename can exist in several tables, and rollback
			// restores by path. Namespace per table (one staged op per table).
			ops.push({
				live,
				backup: join(
					backupDir,
					`${entry.staged.length}-${tableName}-${basename(live)}`,
				),
				tmp,
				existed: await File.isExists(live),
			});
		}
		// Make every replacement durable before the journal records intent.
		await settleWrites(
			await Promise.allSettled(
				ops
					.filter((op) => op.tmp)
					.map(async (op) => File.syncFile(op.tmp as string)),
			),
		);
		await File.syncDir(join(this.databasePath, tableName, ".tmp"));
		await File.syncDir(backupDir);
		await File.syncDir(join(this.databasePath, ".tmp", "backup"));
		await txn.journal.op(ops, pagination);
		entry.staged.push({ ops, pagination });
		if (pagination) entry.paginationFrom = pagination.to;
	}

	/**
	 * Begin a database transaction. Mutations issued while the transaction is
	 * open (post/put/delete, including cascade deletes) are staged into the
	 * database journal and published atomically at commit(); rollback()
	 * discards them without touching any live file.
	 *
	 * @param tables Optional table names to pre-lock at begin() in sorted
	 * order (the deadlock-free way to span tables). Tables not listed are
	 * locked on first touch, in first-touch order.
	 */
	public async begin(tables: string[] = []): Promise<void> {
		return File.runWithLockStore(() => this._begin(tables));
	}

	private async _begin(tables: string[] = []): Promise<void> {
		if (this.activeTransaction) throw this.createError("INVALID_PARAMETERS");
		await this.ensureDatabaseTmpDir();
		// The database lock is the transaction mutex: it serializes
		// transactions and its acquisition runs crash recovery on any journal
		// left behind by a crashed transaction.
		await File.lock(join(this.databasePath, ".tmp"));
		const uniqueTables = [...new Set(tables)].sort();
		const acquired: string[] = [];
		try {
			// Validate every listed table before locking anything.
			for (const name of uniqueTables) {
				this.validateName(name);
				await this.loadTable(name); // throws TABLE_NOT_EXISTS
			}

			const id = randomUUID();
			this.activeTransaction = {
				id,
				journal: new DatabaseJournal(this.databasePath, id),
				tables: new Map(),
			};
			await this.activeTransaction.journal.begin(uniqueTables);

			for (const name of uniqueTables) {
				await File.lock(join(this.databasePath, name, ".tmp"));
				acquired.push(name);
				this.activeTransaction.tables.set(name, {
					locked: true,
					paginationFrom: "",
					lastId: 0,
					total: 0,
					staged: [],
				});
			}
		} catch (error) {
			// Release only the table locks this process actually took (an
			// unlock of a never-acquired path could unlink another process's
			// lock file).
			for (const name of acquired)
				await File.unlock(join(this.databasePath, name, ".tmp")).catch(
					() => {},
				);
			this.activeTransaction = null;
			await File.unlock(join(this.databasePath, ".tmp")).catch(() => {});
			throw error;
		}
	}

	/**
	 * Publish every staged mutation atomically: per table (sorted), the
	 * pagination rename comes first (the atomic publication point readers
	 * observe) and then live->backup + tmp->live swaps, before a single fsynced
	 * `commit` marker makes the whole transaction durable. A crash at any
	 * point is recovered by the journal rule (no marker -> roll back all
	 * tables, marker -> roll forward all tables).
	 */
	public async commit(): Promise<void> {
		const txn = this.activeTransaction;
		if (!txn) throw this.createError("INVALID_PARAMETERS");
		let commitAttempted = false;
		const hasWrites = Array.from(txn.tables.values()).some(
			(table) => table.staged.length > 0,
		);
		try {
			for (const tableName of [...txn.tables.keys()].sort()) {
				const entry = txn.tables.get(tableName);
				if (!entry) continue;
				for (const { ops, pagination } of entry.staged) {
					if (pagination) await rename(pagination.from, pagination.to);
					for (const op of ops) {
						if (op.existed) await rename(op.live, op.backup);
						if (op.tmp) await rename(op.tmp, op.live);
					}
				}
			}

			// Persist every publication and backup name before the commit marker.
			for (const tableName of txn.tables.keys()) {
				await File.syncDir(join(this.databasePath, tableName));
				await File.syncDir(join(this.databasePath, tableName, ".tmp"));
			}
			if (hasWrites)
				await File.syncDir(join(this.databasePath, ".tmp", "backup", txn.id));
			await File.syncDir(join(this.databasePath, ".tmp"));
			commitAttempted = true;
			await txn.journal.commit();

			// Clean the fast-path leftovers; recovery owns any crash leftovers.
			await txn.journal.dispose();
			await rm(join(this.databasePath, ".tmp", "backup", txn.id), {
				recursive: true,
				force: true,
			}).catch(() => {});
			if (hasWrites)
				await File.syncDir(join(this.databasePath, ".tmp", "backup"));
			await unlink(txn.journal.path).catch((error: any) => {
				if (error?.code !== "ENOENT") throw error;
			});
			await File.syncDir(join(this.databasePath, ".tmp"));
			await File.syncDir(this.databasePath);
			for (const tableName of txn.tables.keys()) {
				await File.syncDir(join(this.databasePath, tableName));
				await File.syncDir(join(this.databasePath, tableName, ".tmp"));
			}

			// A staged table's row count and derived caches were deliberately
			// left untouched while the transaction was open (nothing is
			// published before commit), so they must be refreshed here — the
			// single-table fast path does the same right after commitFiles().
			// Without this a committed `put` (row count unchanged) would keep
			// serving sorted/criteria .cache entries built before the write.
			for (const tableName of txn.tables.keys()) {
				const entry = txn.tables.get(tableName);
				if (!entry?.staged.length) continue; // pre-locked but untouched
				// Only trust entry.total when resolvePagination() recorded it.
				// A `put` selected by `where` never reads the pagination file
				// (its row count cannot change), so entry.total is still its
				// initial 0 — publishing that would corrupt the live counter.
				if (entry.paginationFrom)
					this.totalItems.set(`${tableName}-*`, entry.total);
				if (
					globalConfig[this.databasePath].tables?.get(tableName)?.config.cache
				)
					await this.clearCache(tableName);
			}
		} catch (error) {
			if (!commitAttempted) await txn.journal.rollback();
			else await txn.journal.dispose();
			throw error;
		} finally {
			for (const tableName of [...txn.tables.keys()].sort().reverse())
				await File.unlock(join(this.databasePath, tableName, ".tmp"));
			await File.unlock(join(this.databasePath, ".tmp"));
			this.activeTransaction = null;
		}
	}

	/**
	 * Discard the open transaction: temps and the journal are removed and no
	 * live file is touched (nothing is published before commit()).
	 */
	public async rollback(): Promise<void> {
		const txn = this.activeTransaction;
		if (!txn) throw this.createError("INVALID_PARAMETERS");
		try {
			await txn.journal.rollback();
		} finally {
			for (const tableName of [...txn.tables.keys()].sort().reverse())
				await File.unlock(join(this.databasePath, tableName, ".tmp"));
			await File.unlock(join(this.databasePath, ".tmp"));
			this.activeTransaction = null;
		}
	}

	/**
	 * Run `callback` inside a transaction, committing when it resolves and
	 * rolling back when it throws. Prefer this over a bare begin/commit pair:
	 * the database lock taken by begin() is held for the transaction's whole
	 * lifetime, so an exception between begin() and commit() would otherwise
	 * block every later write on this database for the full lock-wait timeout.
	 *
	 * @param tablesOrCallback Pre-lock list (sorted, deadlock-free) or the callback
	 * @param maybeCallback The callback, when tables were passed first
	 * @param tables Pre-lock list when the callback was passed first
	 * @return {*} Whatever the callback resolves to
	 */
	public async transaction<T>(
		tablesOrCallback: string[] | ((db: Inibase) => Promise<T>),
		maybeCallback?: (db: Inibase) => Promise<T>,
		tables: string[] = [],
	): Promise<T> {
		return File.runWithLockStore(() =>
			this._transaction(tablesOrCallback, maybeCallback, tables),
		);
	}

	private async _transaction<T>(
		tablesOrCallback: string[] | ((db: Inibase) => Promise<T>),
		maybeCallback?: (db: Inibase) => Promise<T>,
		tables: string[] = [],
	): Promise<T> {
		const callback =
			typeof tablesOrCallback === "function" ? tablesOrCallback : maybeCallback;
		if (!callback) throw this.createError("INVALID_PARAMETERS");
		if (Array.isArray(tablesOrCallback)) tables = tablesOrCallback;

		await this.begin(tables);
		let committed = false;
		try {
			const result = await callback(this);
			await this.commit();
			committed = true;
			return result;
		} finally {
			// commit() already rolled back and cleared the transaction when it
			// failed, so this only fires for a throwing callback (or one that
			// never committed) — the case that would otherwise leak the lock.
			if (!committed && this.activeTransaction)
				await this.rollback().catch(() => {});
		}
	}

	/**
	 * Snapshot the identity (dev:inode:mtime:size) of every column file and
	 * the pagination file. Reading data and then re-verifying this snapshot
	 * lets lock-free readers detect an in-flight writer commit and retry
	 * instead of returning a torn row set.
	 */
	private async snapshotTableFiles(
		tableName: string,
	): Promise<Map<string, string>> {
		const tablePath = join(this.databasePath, tableName);
		const extension = this.getFileExtension(tableName);
		const snapshot = new Map<string, string>();
		const directory = await stat(tablePath, { bigint: true });
		snapshot.set(
			tablePath,
			`dir:${directory.dev}:${directory.ino}:${directory.mtimeNs}:${directory.ctimeNs}`,
		);
		// A read may start after ensureTableRecovered() checked but while a
		// writer is paused between live->backup and tmp->live. File identities
		// can then stay unchanged for the entire torn read. Bracket the read
		// with journal absence as well; the existing writer-lock fallback waits
		// for publication or runs recovery instead of accepting that snapshot.
		const journalPath = join(tablePath, ".tmp", "journal.jsonl");
		snapshot.set(
			journalPath,
			(await File.isExists(journalPath))
				? "publication-busy"
				: "publication-clear",
		);
		for (const fileName of await readdir(tablePath).catch(() => [])) {
			if (
				!fileName.endsWith(extension) &&
				!fileName.endsWith(".pagination") &&
				fileName !== FORMAT_FILE &&
				fileName !== UPDATES_LOG_NAME
			)
				continue;
			const filePath = join(tablePath, fileName);
			const fileStat = await stat(filePath, { bigint: true }).catch(() => null);
			if (fileStat)
				snapshot.set(
					filePath,
					`${fileStat.dev}:${fileStat.ino}:${fileStat.mtimeNs}:${fileStat.size}`,
				);
		}
		return snapshot;
	}

	/** True when every snapshotted file is still present and unchanged. */
	private async verifyTableFiles(
		snapshot: Map<string, string>,
	): Promise<boolean> {
		for (const [filePath, identity] of snapshot) {
			if (identity === "publication-busy") return false;
			if (identity === "publication-clear") {
				if (await File.isExists(filePath)) return false;
				continue;
			}
			const fileStat = await stat(filePath, { bigint: true }).catch(() => null);
			const observed = !fileStat
				? "missing"
				: identity.startsWith("dir:")
					? `dir:${fileStat.dev}:${fileStat.ino}:${fileStat.mtimeNs}:${fileStat.ctimeNs}`
					: `${fileStat.dev}:${fileStat.ino}:${fileStat.mtimeNs}:${fileStat.size}`;
			if (!fileStat || observed !== identity) return false;
		}
		return true;
	}

	/**
	 * Retrieve item(s) from a table
	 *
	 * @param {string} tableName
	 * @param {(string | number | (string | number)[] | Criteria)} [where]
	 * @param {Options} [options]
	 * @param {boolean} [onlyOne]
	 * @param {boolean} [onlyLinesNumbers]
	 * @return {*}  {(Promise<Data | number | (Data | number)[] | null>)}
	 */
	get<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		where: string | number | (string | number)[] | Criteria | undefined,
		options: Options | undefined,
		onlyOne: true,
		onlyLinesNumbers?: false,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData) | null>;
	get<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		where: string | number,
		options?: Options,
		onlyOne?: boolean,
		onlyLinesNumbers?: false,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData) | null>;
	get<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		where?: string | number | (string | number)[] | Criteria,
		options?: Options,
		onlyOne?: boolean,
		onlyLinesNumbers?: false,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData)[] | null>;
	get<_TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		where: string | number | (string | number)[] | Criteria | undefined,
		options: Options | undefined,
		onlyOne: false | undefined,
		onlyLinesNumbers: true,
		_whereIsLinesNumbers?: boolean,
	): Promise<number[] | null>;
	get<_TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		where: string | number | (string | number)[] | Criteria | undefined,
		options: Options | undefined,
		onlyOne: true,
		onlyLinesNumbers: true,
		_whereIsLinesNumbers?: boolean,
	): Promise<number | null>;
	public async get<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		where?: string | number | (string | number)[] | Criteria,
		options: Options = {
			page: 1,
			perPage: 15,
		},
		onlyOne?: boolean,
		onlyLinesNumbers?: boolean,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData) | number | ((Data & TData) | number)[] | null> {
		return File.runWithLockStore(() =>
			this._get<TData>(
				tableName,
				where,
				options,
				onlyOne,
				onlyLinesNumbers,
				_whereIsLinesNumbers,
			),
		);
	}

	private async _get<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		where?: string | number | (string | number)[] | Criteria,
		options: Options = {
			page: 1,
			perPage: 15,
		},
		onlyOne?: boolean,
		onlyLinesNumbers?: boolean,
		_whereIsLinesNumbers?: boolean,
		materializedSort = false,
	): Promise<(Data & TData) | number | ((Data & TData) | number)[] | null> {
		this.validateName(tableName);
		await this.ensureTableRecovered(tableName);

		// Automatic deltas must not turn a bounded native/disk sort into the
		// explicit log backend's whole-table JavaScript materialization.
		if (options.sort && !materializedSort) {
			await this.loadTable(tableName);
			if ((await this.currentFormat(tableName))?.automatic) {
				const tmp = join(this.databasePath, tableName, ".tmp");
				await File.lock(tmp, undefined, undefined, this.resources);
				try {
					const overlay = await this.getOverlay(tableName, true);
					let stableWhere = where;
					if (overlay?.size) {
						if (_whereIsLinesNumbers && where !== undefined) {
							const ids = await this.overlayLineIds(
								tableName,
								(Array.isArray(where) ? where : [where]) as number[],
							);
							stableWhere = Array.isArray(where)
								? [...ids.values()]
								: [...ids.values()][0];
						}
						await this.compactLogTable(tableName);
						if (
							globalConfig[this.databasePath].tables?.get(tableName)?.config
								.cache
						)
							await this.clearCache(tableName);
					}
					return await this.resources.withWorking(
						Math.min(this.resources.limit, 2 * 1024 * 1024),
						() =>
							this._get<TData>(
								tableName,
								stableWhere,
								options,
								onlyOne,
								onlyLinesNumbers,
								_whereIsLinesNumbers && overlay?.size
									? false
									: _whereIsLinesNumbers,
								true,
							),
					);
				} finally {
					await File.unlock(tmp);
				}
			}
		}

		// Lock-free reads with optimistic retry: snapshot the identity of every
		// column + pagination file, run the read, then verify nothing changed
		// mid-scan. A writer commit flips at least one file identity, so a torn
		// read is detected and re-run instead of being returned.
		for (let attempt = 0; ; attempt++) {
			const snapshot = await this.snapshotTableFiles(tableName);
			let failure: unknown;
			let result: (Data & TData) | number | ((Data & TData) | number)[] | null =
				null;
			try {
				result = await this.getOnce<TData>(
					tableName,
					where,
					options,
					onlyOne,
					onlyLinesNumbers,
					_whereIsLinesNumbers,
				);
			} catch (error) {
				failure = error;
			}
			if (await this.verifyTableFiles(snapshot)) {
				if (failure) throw failure;
				return result;
			}
			if (attempt >= 2) {
				// Never return a knowingly inconsistent third attempt. Under
				// sustained churn, serialize once with the existing writer lock.
				const tmp = join(this.databasePath, tableName, ".tmp");
				await File.lock(tmp);
				try {
					return await this.getOnce<TData>(
						tableName,
						where,
						options,
						onlyOne,
						onlyLinesNumbers,
						_whereIsLinesNumbers,
					);
				} finally {
					await File.unlock(tmp);
				}
			}
		}
	}

	private async getOnce<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		where?: string | number | (string | number)[] | Criteria,
		options: Options = {
			page: 1,
			perPage: 15,
		},
		onlyOne?: boolean,
		onlyLinesNumbers?: boolean,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData) | number | ((Data & TData) | number)[] | null> {
		const tablePath = join(this.databasePath, tableName);

		// Ensure options.columns is an array
		if (options.columns) {
			options.columns = Array.isArray(options.columns)
				? options.columns
				: [options.columns];

			this.validateColumns(options.columns);

			if (options.columns.length && !options.columns.includes("id"))
				options.columns.push("id");
		}

		// Default values for page and perPage
		options.columns = options.columns || [];
		options.page = options.page || 1;
		options.perPage = options.perPage || 15;

		let total: number | undefined;
		let RETURN!: (Data & TData) | (Data & TData)[] | null;

		let schema = structuredClone((await this.loadTable(tableName))?.schema);

		if (!schema) throw this.createError("NO_SCHEMA", tableName);

		let pagination: [number, number] = [0, 0];
		for await (const paginationFileName of glob("*.pagination", {
			cwd: tablePath,
		}))
			pagination = parse(paginationFileName).name.split("-").map(Number) as [
				number,
				number,
			];

		if (!pagination[1]) return null;
		const readOverlay = this.isLogTable(tableName)
			? await this.getOverlay(tableName)
			: null;
		const liveTotal = pagination[1] - (readOverlay?.deletedCount ?? 0);
		if (liveTotal <= 0) return null;

		if (options.columns?.length)
			schema = this._filterSchemaByColumns(schema, options.columns as string[]);

		if (
			where &&
			((Array.isArray(where) && !where.length) ||
				(Utils.isObject(where) && !Object.keys(where).length))
		)
			where = undefined;

		if (options.sort) {
			// With an un-compacted overlay the shell `paste | sort | awk` path
			// would read stale base cells. Fall back to an in-process sort of
			// the merged rows, which is correct for every sort shape.
			if (this.isLogTable(tableName)) {
				const overlay = await this.getOverlay(tableName);
				if (overlay?.size)
					return await this.getOnceSortedWithOverlay<TData>(
						tableName,
						schema,
						where,
						options,
						onlyOne,
					);
			}

			let sortArray: [string, boolean][];
			let awkCommand = "";

			if (Utils.isObject(options.sort) && !Array.isArray(options.sort)) {
				// {name: "ASC", age: "DESC"}
				sortArray = Object.entries(options.sort).map(([key, value]) => [
					key,
					typeof value === "string" ? value.toLowerCase() === "asc" : value > 0,
				]);
			} else
				sortArray = ([] as string[])
					.concat(options.sort as string | string[])
					.map((column) => [column, true]);

			let cacheKey = "";
			const cacheGeneration = this.isLogTable(tableName)
				? [(await this.currentFormat(tableName))?.baseGen ?? 0]
				: [];
			// Criteria. The sort cache is versioned by the pagination row count
			// (see the criteria-cache note) so stale sorted line numbers from
			// before a post/delete are never replayed.
			if (globalConfig[this.databasePath].tables?.get(tableName)?.config.cache)
				cacheKey = UtilsServer.hashString(
					inspect([sortArray, pagination[1], ...cacheGeneration], {
						sorted: true,
					}),
				);

			if (where) {
				const lineNumbers = await this.get(
					tableName,
					where,
					undefined,
					undefined,
					true,
				);
				if (!lineNumbers?.length) return null;
				const itemsIDs = Object.values(
					(await File.get(
						join(tablePath, `id${this.getFileExtension(tableName)}`),
						lineNumbers,
						{ key: "BLABLA", type: "number" },
					)) ?? {},
				).map(Number);
				awkCommand = `awk '${itemsIDs.map((id) => `$1 == ${id}`).join(" || ")}'`;
			}
			// perPage < 0 means "no limit": select every line instead of
			// generating an empty awk window (with perPage -1 the old code
			// produced `awk ''`, which prints nothing and the empty stdout
			// decoded into a single hollow row).
			else
				awkCommand =
					options.perPage < 0
						? "awk '1'"
						: `awk '${Array.from(
								{ length: options.perPage },
								(_, index) =>
									((options.page as number) - 1) * (options.perPage as number) +
									index +
									1,
							)
								.map((lineNumber) => `NR==${lineNumber}`)
								.join(" || ")}'`;

			const filesPathes = (
				sortArray.find(([key]) => key === "id")
					? sortArray
					: [["id", true], ...sortArray]
			).map((column) =>
				join(tablePath, `${column[0]}${this.getFileExtension(tableName)}`),
			);
			for await (const path of filesPathes.slice(1))
				if (!(await File.isExists(path))) return null;

			// Construct the paste command to merge files and filter lines by IDs
			let pasteCommand = `paste '${filesPathes.join("' '")}'`;

			const _idPrepended = !sortArray.find(([key]) => key === "id");
			const sortColumns = sortArray
				.map(([key, ascending], i) => {
					const field = Utils.getField(key, schema);
					if (!field) return "";
					const colIndex = _idPrepended ? i + 2 : i + 1;
					return `-k${colIndex},${colIndex}${
						Utils.isFieldType(field, ["id", "number", "date"]) ? "n" : ""
					}${!ascending ? "r" : ""}`;
				})
				.join(" ");

			const sortCommand = `sort -S ${Math.min(1048576, Math.floor(this.resources.limit / 4))} ${sortColumns} -T='${join(tablePath, ".tmp")}'`;

			const sortTemps: string[] = [];
			try {
				if (cacheKey) await File.lock(join(tablePath, ".tmp"), cacheKey);
				const cachedSort =
					Boolean(cacheKey) &&
					(await File.isExists(
						join(tablePath, ".cache", `${cacheKey}${this.fileExtension}`),
					));
				if (!cachedSort) {
					const plain: string[] = [];
					for (const path of filesPathes) {
						const ready = await File.prepareSortColumn(path);
						plain.push(ready);
						if (ready !== path) sortTemps.push(ready);
					}
					pasteCommand = `paste '${plain.join("' '")}'`;
				}
				// Combine && Execute the commands synchronously
				let lines = (
					await UtilsServer.exec(
						globalConfig[this.databasePath].tables?.get(tableName)?.config.cache
							? cachedSort
								? `${awkCommand} '${join(
										tablePath,
										".cache",
										`${cacheKey}${this.fileExtension}`,
									)}'`
								: `${pasteCommand} | ${sortCommand} -o '${join(
										tablePath,
										".cache",
										`${cacheKey}${this.fileExtension}`,
									)}' && ${awkCommand} '${join(
										tablePath,
										".cache",
										`${cacheKey}${this.fileExtension}`,
									)}'`
							: `${pasteCommand} | ${sortCommand} | ${awkCommand}`,
						{
							encoding: "utf-8",
						},
					)
				).stdout
					.trimEnd()
					.split("\n");

				if (where && options.perPage >= 0)
					lines = lines.slice(
						((options.page as number) - 1) * (options.perPage as number),
						(options.page as number) * (options.perPage as number),
					);
				else if (!where && !this.totalItems.has(`${tableName}-*`))
					this.totalItems.set(`${tableName}-*`, pagination[1]);
				if (!lines.length) return null;

				// Parse the result and extract the specified lines
				const outputArray: (Data & TData)[] = lines.map((line) => {
					const splitedFileColumns = line.split("\t"); // Assuming tab-separated columns
					const outputObject: Record<string, any> = {};

					// Extract values for each file, including `id${this.getFileExtension(tableName)}`
					filesPathes.forEach((fileName, index) => {
						const field = Utils.getField(
							basename(fileName).slice(
								0,
								-this.getFileExtension(tableName).length,
							),
							schema,
						);
						if (field) {
							if (
								field.key === "id" &&
								globalConfig[this.databasePath].tables?.get(tableName)?.config
									.decodeID
							)
								outputObject[field.key as string] = splitedFileColumns[index];
							else
								outputObject[field.key as string] = File.decode(
									splitedFileColumns[index],
									{ ...field, databasePath: this.databasePath },
								);
						}
					});

					return outputObject;
				}) as (Data & TData)[];

				const restOfColumns = await this.get<TData>(
					tableName,
					outputArray
						.map(({ id }) => id)
						.filter((id): id is string | number => id !== undefined),
					(({ sort, ...rest }) => rest)(options),
				);

				const sortedRows = restOfColumns
					? outputArray.map((item) => ({
							...item,
							...restOfColumns.find(
								({ id }) =>
									id === (Utils.isNumber(item.id) ? Number(item.id) : item.id),
							),
						}))
					: outputArray;
				return onlyOne ? sortedRows[0] : sortedRows;
			} finally {
				await Promise.all(
					sortTemps.map((path) => unlink(path).catch(() => {})),
				);
				if (cacheKey) await File.unlock(join(tablePath, ".tmp"), cacheKey);
			}
		}

		if (!where) {
			// Display all data
			RETURN = Object.values(
				await this.processSchemaData(
					tableName,
					schema,
					options.perPage < 0
						? undefined
						: await this.livePageLines(
								tableName,
								options.page as number,
								options.perPage,
							),
					options,
				),
			);

			this.totalItems.set(`${tableName}-id`, liveTotal);
		} else if (
			((Array.isArray(where) && where.every(Utils.isNumber)) ||
				Utils.isNumber(where)) &&
			// Numeric where is a line number only through the internal
			// recursion (flag set). An external numeric where is an id — even
			// on non-decodeID tables, where ids are NOT line numbers (prepend
			// layout / rows deleted); using them as lines edited the wrong row
			// and padded the column file (Sep-2026 rename bug). Ids are
			// resolved by the next branch.
			_whereIsLinesNumbers
		) {
			// "where" in this case, is the line(s) number(s) and not id(s)
			let lineNumbers = where as number | number[];
			if (!Array.isArray(lineNumbers)) lineNumbers = [lineNumbers];

			this.totalItems.set(`${tableName}-id`, lineNumbers.length);

			// useless
			if (onlyLinesNumbers) return lineNumbers;

			RETURN = Object.values(
				(await this.processSchemaData<TData>(
					tableName,
					schema,
					lineNumbers,
					options,
				)) ?? {},
			);

			if (RETURN?.length && !Array.isArray(where))
				RETURN = (RETURN as (Data & TData)[])[0];
		} else if (
			(!_whereIsLinesNumbers &&
				((Array.isArray(where) && where.every(Utils.isNumber)) ||
					Utils.isNumber(where))) ||
			(Array.isArray(where) && where.every(Utils.isValidID)) ||
			Utils.isValidID(where)
		) {
			let Ids = where as string | number | (string | number)[];
			if (!Array.isArray(Ids)) Ids = [Ids];

			// Fast path for decodeID tables whose ids are the dense sequence
			// 1..N: when the requested numeric ids form a duplicate-free
			// consecutive range [min..max] with max within the row count, the
			// line numbers ARE the ids — no id-file scan required.
			let lineNumbers: Record<
				number,
				| number
				| string
				| boolean
				| null
				| undefined
				| (string | number | boolean | null)[]
			> | null = null;
			let countItems = 0;
			const isDecodeID =
				globalConfig[this.databasePath].tables?.get(tableName)?.config
					.decodeID === true &&
				!globalConfig[this.databasePath].tables?.get(tableName)?.config.prepend;
			if (
				isDecodeID &&
				this.idDensity.get(tableName) &&
				Ids.every(Utils.isNumber)
			) {
				const seen = new Set<number>();
				let min = Number.POSITIVE_INFINITY;
				let max = Number.NEGATIVE_INFINITY;
				let distinct = true;
				for (const raw of Ids) {
					const n = Number(raw);
					if (seen.has(n)) {
						distinct = false;
						break;
					}
					seen.add(n);
					if (n < min) min = n;
					if (n > max) max = n;
				}
				if (
					distinct &&
					min >= 1 &&
					max <= pagination[1] &&
					max - min + 1 === Ids.length
				) {
					lineNumbers = {};
					for (let line = min; line <= max; line++) lineNumbers[line] = line;
					countItems = Ids.length;
				}
			}
			if (!lineNumbers) {
				[lineNumbers, countItems] = await File.search(
					join(tablePath, `id${this.getFileExtension(tableName)}`),
					"[]",
					Ids.map((id) =>
						Utils.isNumber(id) ? Number(id) : UtilsServer.decodeID(id),
					),
					undefined,
					undefined,
					{ key: "BLABLA", type: "number" },
					Ids.length,
					0,
					// The caller only needs the matching line numbers, not a
					// whole-table count: stop as soon as every requested id has
					// been found instead of scanning the column to EOF.
					false,
					true,
				);
			}
			if (!lineNumbers) return null;
			if (readOverlay?.deletedCount) {
				for (const [line, id] of Object.entries(lineNumbers))
					if ((await readOverlay.get(Number(id)))?.deleted) {
						delete lineNumbers[Number(line)];
						countItems--;
					}
				if (!Object.keys(lineNumbers).length) return null;
			}

			this.totalItems.set(`${tableName}-id`, countItems);

			if (onlyLinesNumbers)
				return Object.keys(lineNumbers).length
					? Object.keys(lineNumbers).map(Number)
					: null;

			if (options.columns) {
				options.columns = (options.columns as string[]).filter(
					(column) => column !== "id",
				);
				if (!options.columns?.length) options.columns = undefined;
			}

			RETURN = Object.values(
				(await this.processSchemaData<TData>(
					tableName,
					schema,
					Object.keys(lineNumbers).map(Number),
					options,
				)) ?? {},
			);

			if (RETURN?.length && !Array.isArray(where))
				RETURN = (RETURN as (Data & TData)[])[0];
		} else if (Utils.isObject(where)) {
			let cachedFilePath = "";
			// The criteria cache is versioned by the row count only; a put
			// changes matching rows without changing the count, so a cached
			// line set would go stale. Bypass it entirely while an overlay
			// exists.
			const overlayActive =
				this.isLogTable(tableName) &&
				((await this.getOverlay(tableName))?.size ?? 0) > 0;
			// Criteria
			if (
				!overlayActive &&
				globalConfig[this.databasePath].tables?.get(tableName)?.config.cache
			) {
				// Cache entries are versioned by the pagination row count so a
				// stale cache written before a post/delete (in this process or
				// another) is detectable: the candidate filename simply stops
				// matching and the cache is rebuilt.
				const generationSuffix = this.isLogTable(tableName)
					? `-${(await this.currentFormat(tableName))?.baseGen ?? 0}`
					: "";
				cachedFilePath = join(
					tablePath,
					".cache",
					`${UtilsServer.hashString(inspect(where, { sorted: true }))}-${
						pagination[1]
					}${generationSuffix}${this.fileExtension}`,
				);

				if (await File.isExists(cachedFilePath)) {
					const cachedItems = (await readFile(cachedFilePath, "utf8")).split(
						",",
					);

					if (!this.totalItems.has(`${tableName}-*`))
						this.totalItems.set(`${tableName}-*`, cachedItems.length);

					if (onlyLinesNumbers)
						return onlyOne ? Number(cachedItems[0]) : cachedItems.map(Number);

					return this.get(
						tableName,
						cachedItems
							.slice(
								((options.page as number) - 1) * options.perPage,
								(options.page as number) * options.perPage,
							)
							.map(Number),
						options,
						onlyOne,
						undefined,
						true,
					) as any;
				}
			}
			const LineNumberDataObj = await this.applyCriteria<TData>(
				tableName,
				options,
				structuredClone(where) as Criteria,
			);

			if (LineNumberDataObj) {
				if (onlyLinesNumbers)
					return onlyOne
						? Number(Object.keys(LineNumberDataObj)[0])
						: Object.keys(LineNumberDataObj).map(Number);
				const alreadyExistsColumns = Object.keys(
					Object.values(LineNumberDataObj)[0],
				);
				const alreadyExistsColumnsIDs = Utils.flattenSchema(schema)
					.filter(({ key }) => alreadyExistsColumns.includes(key))
					.map(({ id }) => id);

				RETURN = Object.values(
					Utils.deepMerge(
						LineNumberDataObj,
						await this.processSchemaData(
							tableName,
							Utils.filterSchema(
								schema,
								(field) =>
									!alreadyExistsColumnsIDs.includes(field.id) ||
									Utils.isFieldType(field, "table"),
							),
							Object.keys(LineNumberDataObj).map(Number),
							options,
						),
					),
				);
				total = Math.min(
					...[...this.totalItems.entries()]
						.filter(([k]) => k.startsWith(`${tableName}-`))
						.map(([, v]) => v),
				);

				for (const [key] of this.totalItems)
					if (key.startsWith(`${tableName}-`) && key !== `${tableName}-id`)
						this.totalItems.delete(key);

				if (
					!overlayActive &&
					globalConfig[this.databasePath].tables?.get(tableName)?.config.cache
				)
					await writeFile(
						cachedFilePath,
						Object.keys(LineNumberDataObj).join(","),
					);
			}
		}

		if (
			!RETURN ||
			(Utils.isObject(RETURN) && !Object.keys(RETURN).length) ||
			(Array.isArray(RETURN) && !RETURN.length)
		)
			return null;

		if (total === undefined)
			total = this.totalItems.has(`${tableName}-*`)
				? (this.totalItems.get(`${tableName}-*`) ?? 0)
				: Math.max(
						...[...this.totalItems.entries()]
							.filter(([k]) => k.startsWith(`${tableName}-`))
							.map(([, v]) => v),
					);
		this.pageInfo[tableName] = {
			...(({ columns, ...restOfOptions }) => restOfOptions)(options),
			perPage: Array.isArray(RETURN) ? RETURN.length : 1,
			totalPages: options.perPage < 0 ? 1 : Math.ceil(total / options.perPage),
			total,
		};
		return onlyOne && Array.isArray(RETURN) ? RETURN[0] : RETURN;
	}

	/**
	 * In-process sort fallback for log tables with a non-empty overlay: the
	 * shell `paste | sort | awk` path reads base cells and would miss puts.
	 * Reads the merged rows for the (optionally filtered) lines, sorts them by
	 * the requested keys with type-aware comparison, then paginates.
	 */
	private async getOnceSortedWithOverlay<
		TData extends Record<string, any> & Partial<Data>,
	>(
		tableName: string,
		schema: Schema,
		where: string | number | (string | number)[] | Criteria | undefined,
		options: Options,
		onlyOne?: boolean,
	): Promise<(Data & TData) | (Data & TData)[] | null> {
		let sortArray: [string, boolean][];
		if (Utils.isObject(options.sort) && !Array.isArray(options.sort))
			sortArray = Object.entries(options.sort).map(([key, value]) => [
				key,
				typeof value === "string" ? value.toLowerCase() === "asc" : value > 0,
			]);
		else
			sortArray = ([] as string[])
				.concat(options.sort as string | string[])
				.map((column) => [column, true]);

		let lines: number[];
		if (where) {
			const found = await this.get(
				tableName,
				where,
				undefined,
				undefined,
				true,
			);
			if (!found) return null;
			lines = Array.isArray(found) ? (found as number[]) : [found as number];
		} else {
			const { total } = await this.resolvePagination(tableName);
			lines = Array.from({ length: total }, (_, index) => index + 1);
		}
		if (!lines.length) return null;

		const rows = Object.values(
			await this.processSchemaData<TData>(tableName, schema, lines, options),
		) as (Data & TData)[];

		const comparator = (a: Data & TData, b: Data & TData): number => {
			for (const [key, ascending] of sortArray) {
				const field = Utils.getField(key, Utils.flattenSchema(schema));
				const aValue = (a as Record<string, any>)?.[key];
				const bValue = (b as Record<string, any>)?.[key];
				let comparison: number;
				if (field && Utils.isFieldType(field, ["id", "number", "date"]))
					comparison = (Number(aValue) || 0) - (Number(bValue) || 0);
				else
					comparison = String(aValue ?? "").localeCompare(String(bValue ?? ""));
				if (comparison) return ascending ? comparison : -comparison;
			}
			// Deterministic tiebreak (legacy `sort` leaves ties unspecified).
			return (Number(a?.id) || 0) - (Number(b?.id) || 0);
		};
		rows.sort(comparator);

		const total = rows.length;
		const perPage = options.perPage as number;
		const pageRows =
			perPage < 0
				? rows
				: rows.slice(
						((options.page as number) - 1) * perPage,
						(options.page as number) * perPage,
					);
		if (!pageRows.length) return null;

		this.totalItems.set(`${tableName}-*`, total);
		this.pageInfo[tableName] = {
			...(({ columns, ...restOfOptions }) => restOfOptions)(options),
			perPage: pageRows.length,
			totalPages: perPage < 0 ? 1 : Math.ceil(total / perPage),
			total,
		};
		return onlyOne ? pageRows[0] : pageRows;
	}

	/**
	 * Create new item(s) in a table
	 *
	 * @param {string} tableName
	 * @param {((Data & TData) | (Data & TData)[])} data Can be array of objects or a single object
	 * @param {Options} [options] Pagination options, useful when the returnPostedData param is true
	 * @param {boolean} [returnPostedData] By default function returns void, if you want to get the posted data, set this param to true
	 * @return {*}  {Promise<Data | Data[] | null | void>}
	 *
	 * @remarks Without `returnPostedData` the return value is the new id: a
	 * `number` on a table created with `decodeID: true`, an encrypted
	 * `string` on every other table.
	 */
	post<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: Data & TData,
		options?: Options,
		returnPostedData?: boolean,
	): Promise<string | number>;
	post<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: (Data & TData)[],
		options?: Options,
		returnPostedData?: boolean,
	): Promise<(string | number)[]>;
	post<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: Data & TData,
		options: Options | undefined,
		returnPostedData: true,
	): Promise<(Data & TData) | null>;
	post<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: (Data & TData)[],
		options: Options | undefined,
		returnPostedData: true,
	): Promise<(Data & TData)[] | null>;
	public async post<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: (Data & TData) | (Data & TData)[],
		options?: Options,
		returnPostedData?: boolean,
	): Promise<
		| (Data & TData)
		| (Data & TData)[]
		| null
		| string
		| number
		| (string | number)[]
	> {
		return File.runWithLockStore(() =>
			this._post<TData>(tableName, data, options, returnPostedData),
		);
	}

	private async _post<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: (Data & TData) | (Data & TData)[],
		options?: Options,
		returnPostedData?: boolean,
	): Promise<
		| (Data & TData)
		| (Data & TData)[]
		| null
		| string
		| number
		| (string | number)[]
	> {
		if (!options)
			options = {
				page: 1,
				perPage: 15,
			};
		this.validateName(tableName);

		if (options.columns)
			this.validateColumns(
				(Array.isArray(options.columns)
					? options.columns
					: [options.columns]) as string[],
			);

		const tablePath = join(this.databasePath, tableName);
		if (!this.activeTransaction) await this.ensureDatabaseRecovered();
		await this.loadTable(tableName);

		if (!globalConfig[this.databasePath].tables?.get(tableName)?.schema)
			throw this.createError("NO_SCHEMA", tableName);

		if (!returnPostedData) returnPostedData = false;

		let clonedData = structuredClone(data);

		const renameList: (string | null)[][] = [];
		let txnStaged = false;
		try {
			// Inside a transaction the table lock is taken once per txn (and
			// held until commit/rollback); otherwise the usual writer lock.
			if (this.activeTransaction) await this.ensureTxnLock(tableName);
			else await File.lock(join(tablePath, ".tmp"));
			// Check uniqueness only after acquiring the cross-process writer lock.
			await this.validateTableData(tableName, clonedData, false, [], false);

			const {
				filePath: paginationFilePath,
				lastId,
				total: _totalItems,
			} = await this.resolvePagination(tableName);
			let lastIdValue = lastId;

			if (!this.activeTransaction)
				this.totalItems.set(`${tableName}-*`, _totalItems);

			if (Utils.isArrayOfObjects(clonedData))
				for (let index = 0; index < clonedData.length; index++) {
					const element = clonedData[index];
					element.id = ++lastIdValue as any;
					element.createdAt = Date.now();
					element.updatedAt = undefined;
				}
			else {
				clonedData.id = ++lastIdValue as any;
				clonedData.createdAt = Date.now();
				clonedData.updatedAt = undefined;
			}

			clonedData = this.formatData<TData>(
				clonedData,
				globalConfig[this.databasePath].tables?.get(tableName)?.schema ?? [],
				false,
			);

			// Derived columns: evaluate every computed expression against the
			// final formatted row (the row is pieced back in place so helpers
			// iterate the real array values and dependent fields see each
			// other). Evaluation happens before any file is touched.
			const computedPlan = await this.buildComputedPlan(tableName);
			if (computedPlan) {
				const rows = Array.isArray(clonedData)
					? clonedData
					: [clonedData as Data & TData];
				// Evaluate every row against the shared plan in one batch:
				// link hops are read once per distinct (table, column, id)
				// across the whole post instead of once per hop.
				await this.evaluateComputedRows(
					tableName,
					computedPlan,
					Object.fromEntries(rows.map((row, index) => [index, row])) as Record<
						number,
						Data
					>,
				);
			}

			const pathesContents = this.joinPathesContents(
				tableName,
				globalConfig[this.databasePath].tables?.get(tableName)?.config.prepend
					? Array.isArray(clonedData)
						? clonedData.toReversed()
						: clonedData
					: clonedData,
			);

			await settleWrites(
				await Promise.allSettled(
					Object.entries(pathesContents).map(async ([path, content]) =>
						renameList.push(
							globalConfig[this.databasePath].tables?.get(tableName)?.config
								.prepend
								? await File.prepend(path, content)
								: await File.append(path, content),
						),
					),
				),
			);

			const newTotal = _totalItems + (Array.isArray(data) ? data.length : 1);

			const pagination = {
				from: paginationFilePath,
				to: join(tablePath, `${lastIdValue}-${newTotal}.pagination`),
			};

			if (this.activeTransaction) {
				// Stage: journal the intent (fsynced op entry); the live files
				// only change when commit() publishes.
				await this.stageTxnOp(tableName, renameList, pagination);
				txnStaged = true;
				const stagedEntry = this.txnTableEntry(tableName);
				if (stagedEntry) {
					stagedEntry.lastId = lastIdValue;
					stagedEntry.total = newTotal;
				}
			} else {
				// Crash-atomic commit: journal + backup swap + pagination rename.
				await this.commitFiles(tablePath, renameList, pagination);

				const deleted = (await this.getOverlay(tableName))?.deletedCount ?? 0;
				this.totalItems.set(`${tableName}-*`, newTotal - deleted);

				if (
					globalConfig[this.databasePath].tables?.get(tableName)?.config.cache
				)
					await this.clearCache(tableName);
			}

			if (returnPostedData) {
				if (this.activeTransaction)
					// No read-your-writes yet: return the formatted staged rows
					// (ids + defaults) instead of a committed-state read.
					return (Array.isArray(clonedData) ? clonedData : clonedData) as any;
				return await this.get<TData>(
					tableName,
					globalConfig[this.databasePath].tables?.get(tableName)?.config.prepend
						? Array.isArray(clonedData)
							? clonedData.map((_, index) => index + 1).toReversed()
							: 1
						: Array.isArray(clonedData)
							? clonedData.map((_, index) => newTotal - index).toReversed()
							: newTotal,
					options,
					!Utils.isArrayOfObjects(clonedData), // return only one item if data is not array of objects
					undefined,
					true,
				);
			}

			// On a decodeID table the id *is* the plain number — that is the
			// whole point of the config: get(), put(), delete() and the
			// returnPostedData read all hand back raw numbers, so post() must
			// not encode it here. Every other table keeps returning the
			// encrypted id.
			const tableConfig =
				globalConfig[this.databasePath].tables?.get(tableName)?.config;
			const postedID = (id: string | number) =>
				tableConfig?.decodeID === true ? Number(id) : UtilsServer.encodeID(id);

			return Array.isArray(clonedData)
				? (tableConfig?.prepend ? clonedData.toReversed() : clonedData).map(
						({ id }) => postedID(id as string | number),
					)
				: postedID((clonedData as Data & TData).id as string | number);
		} finally {
			if (this.activeTransaction) {
				// Staged temps belong to the journal op; commit()/rollback()
				// owns them. Temps from a failed pre-stage attempt are cleaned
				// here so nothing leaks.
				if (!txnStaged && renameList.length)
					await Promise.allSettled(
						renameList
							.filter((pair): pair is [string, string] => Boolean(pair[0]))
							.map(async ([tempPath, _]) => unlink(tempPath)),
					);
			} else {
				if (renameList.length)
					await Promise.allSettled(
						renameList
							.filter((pair): pair is [string, string] => Boolean(pair[0]))
							.map(async ([tempPath, _]) => unlink(tempPath)),
					);
				await File.unlock(join(tablePath, ".tmp"));
			}
		}
	}

	/**
	 * Update item(s) in a table
	 *
	 * @param {string} tableName
	 * @param {(Data & TData) | (Data & TData[])} data
	 * @param {(number | string | (number | string)[] | Criteria)} [where]
	 * @param {Options} [options]
	 * @param {boolean} [returnUpdatedData]
	 * @return {*}  {Promise<Data | Data[] | null | undefined | void>}
	 */
	put<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data?: (Data & TData) | (Data & TData)[],
		where?: number | string | (number | string)[] | Criteria | undefined,
		options?: Options | undefined,
		returnUpdatedData?: false,
		_whereIsLinesNumbers?: boolean,
	): Promise<void>;
	put<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: Data & TData,
		where: number | string | (number | string)[] | Criteria | undefined,
		options: Options | undefined,
		returnUpdatedData: true | boolean,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData) | null>;
	put<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: (Data & TData)[],
		where: number | string | (number | string)[] | Criteria | undefined,
		options: Options | undefined,
		returnUpdatedData: true | boolean,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData)[] | null>;
	put<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: (Data & TData) | (Data & TData)[],
		where: number | string | (number | string)[] | Criteria | undefined,
		options: Options | undefined,
		returnUpdatedData: true | boolean,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData) | (Data & TData)[] | null>;
	public async put<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: (Data & TData) | (Data & TData)[],
		where?: number | string | (number | string)[] | Criteria,
		options: Options = {
			page: 1,
			perPage: 15,
		},
		returnUpdatedData?: boolean,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData) | (Data & TData)[] | null | undefined | undefined> {
		return File.runWithLockStore(() =>
			this.automaticDeltaWrite(
				tableName,
				Boolean(where) &&
					(!Array.isArray(where) || where.length <= 256) &&
					this.deltaPayloadFits(data),
				() =>
					this._put<TData>(
						tableName,
						data,
						where,
						options,
						returnUpdatedData,
						_whereIsLinesNumbers,
					),
			),
		);
	}

	/**
	 * Incremental `put` for format-2 (log) tables.
	 *
	 * Resolves the target rows to their stable internal ids, validates the
	 * payload against the merged view (uniqueness included), and appends one
	 * bounded frame instead of rewriting whole columns. The base files are left
	 * untouched; readers merge the overlay. Returns `undefined` when nothing
	 * matches, matching the legacy `put` contract.
	 */
	private async putViaLog<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: (Data & TData) | (Data & TData)[],
		where?: number | string | (number | string)[] | Criteria,
		options: Options = { page: 1, perPage: 15 },
		returnUpdatedData?: boolean,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData) | (Data & TData)[] | null | undefined> {
		const tablePath = join(this.databasePath, tableName);
		const schema =
			globalConfig[this.databasePath].tables?.get(tableName)?.schema ?? [];
		const payloads: (Data & TData)[] = Array.isArray(data) ? data : [data];
		const isWhereLess = !where;
		const isLines = _whereIsLinesNumbers === true;
		const scalarWhere =
			!isWhereLess &&
			!isLines &&
			!Array.isArray(where) &&
			!Utils.isObject(where);

		await this.throwErrorIfTableEmpty(tableName);

		let overlay: TableOverlay | null = null;
		let resolvedLines: number[] = [];
		let inlineLock = false;
		try {
			await File.lock(join(tablePath, ".tmp"));
			inlineLock = true;

			// Writer-side refresh: repairs a torn tail so the next frame is
			// never appended behind unreadable bytes, and gives us the current
			// committed generation.
			overlay = await this.getOverlay(tableName, true);
			if (!overlay) return undefined;

			// Backpressure before the write: if the log or the overlay has grown
			// past its bound, fold it into the base first. Compaction is
			// maintenance (it only materializes acknowledged frames), so a
			// failure surfaces as MAINTENANCE_REQUIRED without losing any
			// committed update.
			if (
				overlay.size >=
					((await this.currentFormat(tableName))?.automatic
						? Math.min(2048, maxOverlayRecords())
						: maxOverlayRecords()) ||
				(await overlay.log.bytes()) >=
					((await this.currentFormat(tableName))?.automatic
						? Math.min(8 * 1024 * 1024, maxLogBytes())
						: maxLogBytes())
			) {
				try {
					await this.compactLogTable(tableName);
				} catch (error: any) {
					throw this.createError(
						"MAINTENANCE_REQUIRED",
						`${tableName} (compaction failed: ${error?.message ?? error})`,
					);
				}
				overlay = await this.getOverlay(tableName, true);
				if (overlay.size >= maxOverlayRecords())
					throw this.createError(
						"MAINTENANCE_REQUIRED",
						`${tableName} (overlay still exceeds ${maxOverlayRecords()} rows after compaction)`,
					);
			}

			if (isWhereLess) {
				const { total } = await this.resolvePagination(tableName);
				resolvedLines = Array.from({ length: total }, (_, index) => index + 1);
			} else if (isLines) {
				resolvedLines = Array.isArray(where)
					? (where as number[])
					: [where as number];
			} else {
				const lines = await this.get(
					tableName,
					where,
					undefined,
					undefined,
					true,
				);
				if (!lines) return undefined;
				resolvedLines = Array.isArray(lines)
					? (lines as number[])
					: [lines as number];
			}
			if (!resolvedLines.length) return undefined;
			if (
				(resolvedLines.length > 256 ||
					!this.deltaPayloadFits(
						data,
						Math.ceil(resolvedLines.length / payloads.length),
					)) &&
				(await this.currentFormat(tableName))?.automatic
			) {
				const ids = await this.overlayLineIds(tableName, resolvedLines);
				await this.leaveAutomaticDeltas(tableName);
				return await this._put(
					tableName,
					data,
					[...ids.values()],
					options,
					returnUpdatedData,
					false,
				);
			}

			const lineIds = await this.overlayLineIds(tableName, resolvedLines);

			// Validate against the merged view: `checkUnique` searches the base
			// columns through `File.search` overrides, so this sees un-compacted
			// puts. Required fields are skipped (partial update).
			await this.validateTableData(
				tableName,
				structuredClone(payloads) as (Data & TData)[],
				true,
				resolvedLines,
			);
			if (payloads.length === 1 && resolvedLines.length > 1)
				for (const field of schema)
					if (field.unique === true && Object.hasOwn(payloads[0], field.key))
						throw this.createError("FIELD_UNIQUE", field.key);

			const now = Date.now();
			const records: UpdateRecord[] = [];
			for (let index = 0; index < resolvedLines.length; index++) {
				const id = lineIds.get(resolvedLines[index]);
				if (id === undefined) continue;
				const previous = await overlay.get(id);
				if (previous?.deleted) continue;
				const payload =
					payloads.length === 1
						? payloads[0]
						: (payloads[index % payloads.length] ?? payloads[0]);
				const formatted = this.formatData(payload, schema, true) as Record<
					string,
					any
				>;
				const cols: Record<string, unknown> = {};
				for (const [key, value] of Object.entries(formatted)) {
					if (key === "id" || key === "createdAt" || key === "updatedAt")
						continue;
					// Only columns the caller actually supplied are overlaid, so a
					// partial `put` never blanks untouched fields.
					if (!Object.hasOwn(payload, key)) continue;
					cols[key] = File.encode(value);
				}
				cols.updatedAt = now;
				if (
					(await this.currentFormat(tableName))?.automatic &&
					!this.deltaPayloadFits({ ...previous?.cols, ...cols })
				) {
					// Several individually small updates must not accumulate an
					// oversized merged row. Fold first and retry by stable IDs;
					// stay inside this operation's existing working reservation.
					const ids = [...lineIds.values()];
					await this.compactLogTable(tableName);
					return await this.putViaLog(
						tableName,
						data,
						scalarWhere ? ids[0] : ids,
						options,
						returnUpdatedData,
						false,
					);
				}
				records.push({ id, cols, updatedAt: now });
			}

			if (records.length) {
				const frames = buildFrames(
					records,
					overlay.committedGen + 1,
					DEFAULT_MAX_FRAME_BYTES,
					overlay.log.path,
				);
				if (frames.length === 1) await overlay.log.append(frames[0]);
				else {
					// Several self-committing frames must not expose a partially
					// applied public put after a process crash between frames.
					const staged = await overlay.log.stage(frames, tablePath);
					await this.commitFiles(tablePath, [staged], null);
				}
				await overlay.applyLocal(frames);
			}
		} finally {
			if (inlineLock) await File.unlock(join(tablePath, ".tmp"));
		}

		if (returnUpdatedData) {
			if (isWhereLess)
				return await this.get<TData>(tableName, undefined, options);
			if (scalarWhere)
				return await this.get<TData>(
					tableName,
					resolvedLines[0],
					options,
					true,
					undefined,
					true,
				);
			return await this.get<TData>(
				tableName,
				resolvedLines,
				options,
				undefined,
				undefined,
				true,
			);
		}
		return undefined;
	}

	private async _put<TData extends Record<string, any> & Partial<Data>>(
		tableName: string,
		data: (Data & TData) | (Data & TData)[],
		where?: number | string | (number | string)[] | Criteria,
		options: Options = {
			page: 1,
			perPage: 15,
		},
		returnUpdatedData?: boolean,
		_whereIsLinesNumbers?: boolean,
	): Promise<(Data & TData) | (Data & TData)[] | null | undefined | undefined> {
		const renameList: (string | null)[][] = [];
		let txnStaged = false;
		this.validateName(tableName);

		if (options.columns)
			this.validateColumns(
				(Array.isArray(options.columns)
					? options.columns
					: [options.columns]) as string[],
			);

		const tablePath = join(this.databasePath, tableName);
		if (!this.activeTransaction) await this.ensureDatabaseRecovered();
		await this.throwErrorIfTableEmpty(tableName);

		// Format-2 tables route every put through the append-only log, which
		// is proportional to the changed data. Transactions and DDL need a
		// compaction that 3.9 ships, so they are refused loudly rather than
		// silently falling back to a whole-column rewrite that would leave the
		// overlay shadowing newer base values.
		if (this.isLogTable(tableName)) {
			if (this.activeTransaction)
				throw this.createError(
					"MAINTENANCE_REQUIRED",
					`${tableName} (put inside a transaction on update-log table)`,
				);
			return this.putViaLog<TData>(
				tableName,
				data,
				where,
				options,
				returnUpdatedData,
				_whereIsLinesNumbers,
			);
		}

		let clonedData: (Data & TData) | (Data & TData)[] = structuredClone(data);

		if (!where) {
			if (Utils.isArrayOfObjects(clonedData)) {
				if (
					!clonedData.every(
						(item) => Object.hasOwn(item, "id") && Utils.isValidID(item.id),
					)
				)
					throw this.createError("INVALID_ID");

				return this.put<TData>(
					tableName,
					clonedData,
					clonedData
						.map(({ id }) => id)
						.filter((id): id is string | number => id !== undefined),
					options,
					returnUpdatedData as boolean,
				);
			}
			if (Object.hasOwn(clonedData, "id")) {
				if (!Utils.isValidID(clonedData.id))
					throw this.createError("INVALID_ID", clonedData.id);
				return this.put<TData>(
					tableName,
					clonedData,
					clonedData.id,
					options,
					returnUpdatedData as boolean,
				);
			}

			await this.validateTableData(tableName, clonedData, true);

			clonedData = this.formatData<TData>(
				clonedData,
				globalConfig[this.databasePath].tables?.get(tableName)?.schema ?? [],
				true,
			);

			const pathesContents = this.joinPathesContents(tableName, {
				...(({ id, ...restOfData }) => restOfData)(clonedData as TData & Data),
				updatedAt: Date.now(),
			});

			// Derived columns: a where-less put rewrites every row, so each
			// computed expression must be re-evaluated against the existing
			// row overlaid with the payload. The plan itself is schema-only.
			const computedPlan = await this.buildComputedPlan(tableName);

			try {
				if (this.activeTransaction) await this.ensureTxnLock(tableName);
				else await File.lock(join(tablePath, ".tmp"));

				const { total } = await this.resolvePagination(tableName);

				if (computedPlan) {
					const lineNumbers = Array.from(
						{ length: total },
						(_, index) => index + 1,
					);
					const schema =
						globalConfig[this.databasePath].tables?.get(tableName)?.schema ??
						[];
					// Read every stored column (computed ones included) so the
					// merge can skip columns whose re-evaluated values are
					// unchanged — no rewrite, no fsync for them.
					const existing = await this.processSchemaData<Data>(
						tableName,
						schema,
						lineNumbers,
					);
					const payloadRows = (
						Array.isArray(clonedData) ? clonedData : [clonedData]
					).map((row) =>
						Object.fromEntries(
							Object.entries(row).filter(([, v]) => v !== "undefined"),
						),
					);
					const mergedRows: Record<number, Data> = {};
					for (let index = 0; index < lineNumbers.length; index++) {
						const line = lineNumbers[index];
						mergedRows[line] = {
							...((existing[line] as Data) ?? {}),
							...(payloadRows[index % payloadRows.length] ?? {}),
							updatedAt: Date.now(),
						} as Data;
					}
					const evaluated = await this.evaluateComputedRows(
						tableName,
						computedPlan,
						mergedRows,
					);
					this.mergeComputedLineRecords(
						tableName,
						computedPlan,
						evaluated,
						pathesContents,
						existing,
					);
				}

				await settleWrites(
					await Promise.allSettled(
						Object.entries(pathesContents).map(async ([path, content]) =>
							renameList.push(await File.replace(path, content, total)),
						),
					),
				);

				if (this.activeTransaction) {
					// Stage instead of publishing: row count is unchanged so
					// there is no pagination rename to journal.
					await this.stageTxnOp(tableName, renameList, null);
					txnStaged = true;
				} else {
					// Crash-atomic commit (row count unchanged -> no pagination rename).
					await this.commitFiles(tablePath, renameList, null);

					if (
						globalConfig[this.databasePath].tables?.get(tableName)?.config.cache
					)
						await this.clearCache(tableName);
				}

				if (returnUpdatedData) {
					if (this.activeTransaction)
						// Reading the committed state would miss the staged
						// write (no read-your-writes yet).
						throw this.createError("INVALID_PARAMETERS");
					return await this.get<TData>(tableName, undefined, options);
				}
			} finally {
				if (this.activeTransaction) {
					// Staged temps belong to the journal op; commit()/rollback()
					// owns them.
					if (!txnStaged && renameList.length)
						await Promise.allSettled(
							renameList
								.filter((pair): pair is [string, string] => Boolean(pair[0]))
								.map(async ([tempPath, _]) => unlink(tempPath)),
						);
				} else {
					if (renameList.length)
						await Promise.allSettled(
							renameList
								.filter((pair): pair is [string, string] => Boolean(pair[0]))
								.map(async ([tempPath, _]) => unlink(tempPath)),
						);
					await File.unlock(join(tablePath, ".tmp"));
				}
			}
		} else if (
			((Array.isArray(where) && where.every(Utils.isNumber)) ||
				Utils.isNumber(where)) &&
			// Numeric where is a line number only through the internal
			// recursion (flag set). An external numeric where is an id — even
			// on non-decodeID tables, where ids are NOT line numbers (prepend
			// layout / rows deleted); using them as lines edited the wrong row
			// and padded the column file (Sep-2026 rename bug). Ids are
			// resolved by the next branch.
			_whereIsLinesNumbers
		) {
			// "where" in this case, is the line(s) number(s) and not id(s)

			await this.validateTableData(tableName, clonedData, true);

			clonedData = this.formatData<TData>(
				clonedData,
				globalConfig[this.databasePath].tables?.get(tableName)?.schema ?? [],
				true,
			);

			const pathesContents = Object.fromEntries(
				Object.entries(
					this.joinPathesContents(
						tableName,
						Array.isArray(clonedData)
							? clonedData.map((item) => ({
									...item,
									updatedAt: Date.now(),
								}))
							: { ...(clonedData as TData & Data), updatedAt: Date.now() },
					),
				).map(([path, content]) => [
					path,
					(Array.isArray(where) ? where : [where]).reduce(
						(obj: Record<number, any>, lineNum, index) => {
							obj[lineNum] = Array.isArray(content) ? content[index] : content;
							return obj;
						},
						{},
					),
				]),
			);

			// Derived columns re-evaluate the target lines: existing values +
			// payload overlay feed the expressions, results go back per line.
			const computedPlan = await this.buildComputedPlan(tableName);

			try {
				// One global lock per table serializes every writer; inside a
				// transaction the lock is held for the whole txn.
				if (this.activeTransaction) await this.ensureTxnLock(tableName);
				else await File.lock(join(tablePath, ".tmp"));

				if (computedPlan) {
					const whereLines = Array.isArray(where) ? where : [where];
					const schema =
						globalConfig[this.databasePath].tables?.get(tableName)?.schema ??
						[];
					// Read every stored column (computed ones included) so the
					// merge can skip columns whose re-evaluated values are
					// unchanged — no rewrite, no fsync for them.
					const existing = await this.processSchemaData<Data>(
						tableName,
						schema,
						whereLines,
					);
					const payloadRows = (
						Array.isArray(clonedData) ? clonedData : [clonedData]
					).map((row) =>
						Object.fromEntries(
							Object.entries(row).filter(([, v]) => v !== "undefined"),
						),
					);
					const evaluated: Record<number, ComputedLineValues> = {};
					const indexCache = new Map<string, Map<number, FieldRef>>([
						[tableName, computedPlan.index],
					]);
					for (let index = 0; index < whereLines.length; index++) {
						const line = whereLines[index];
						const merged = {
							...((existing[line] as Data) ?? {}),
							...(payloadRows[index] ?? {}),
							updatedAt: Date.now(),
						} as Data;
						evaluated[line] = await this.evaluateRowComputed(
							tableName,
							computedPlan,
							merged,
							indexCache,
						);
					}
					this.mergeComputedLineRecords(
						tableName,
						computedPlan,
						evaluated,
						pathesContents,
						existing,
					);
				}

				await settleWrites(
					await Promise.allSettled(
						Object.entries(pathesContents).map(async ([path, content]) =>
							renameList.push(await File.replace(path, content)),
						),
					),
				);

				if (this.activeTransaction) {
					await this.stageTxnOp(tableName, renameList, null);
					txnStaged = true;
				} else {
					await this.commitFiles(tablePath, renameList, null);

					if (
						globalConfig[this.databasePath].tables?.get(tableName)?.config.cache
					)
						await this.clearCache(tableName);
				}

				if (returnUpdatedData) {
					if (this.activeTransaction)
						throw this.createError("INVALID_PARAMETERS");
					// AWAITED readback: must complete inside the writer lock. An
					// async-tail `return this.get(...)` lets the finally below
					// unlock before the readback's file reads resume.
					return await this.get(
						tableName,
						where,
						options,
						!Array.isArray(where),
						undefined,
						true,
					);
				}
			} finally {
				if (this.activeTransaction) {
					if (!txnStaged && renameList.length)
						await Promise.allSettled(
							renameList
								.filter((pair): pair is [string, string] => Boolean(pair[0]))
								.map(async ([tempPath, _]) => unlink(tempPath)),
						);
				} else {
					if (renameList.length)
						await Promise.allSettled(
							renameList
								.filter((pair): pair is [string, string] => Boolean(pair[0]))
								.map(async ([tempPath, _]) => unlink(tempPath)),
						);
					await File.unlock(join(tablePath, ".tmp"));
				}
			}
		} else if (
			(!_whereIsLinesNumbers &&
				((Array.isArray(where) && where.every(Utils.isNumber)) ||
					Utils.isNumber(where))) ||
			(Array.isArray(where) && where.every(Utils.isValidID)) ||
			Utils.isValidID(where)
		) {
			// Resolve id -> line(s) WHILE holding the writer lock: a post
			// landing between the resolution and the write would shift every
			// line of a prepend table and the update would hit the wrong row.
			// The recursive call re-takes the lock reentrantly (same task), so
			// the lock is held continuously from resolution to publish.
			let inlineLock = false;
			try {
				if (this.activeTransaction) await this.ensureTxnLock(tableName);
				else {
					await File.lock(join(tablePath, ".tmp"));
					inlineLock = true;
				}
				const lineNumbers = await this.get(
					tableName,
					where,
					undefined,
					undefined,
					true,
				);
				if (lineNumbers)
					return await this.put<TData>(
						tableName,
						clonedData as TData & Data,
						// get() with onlyLinesNumbers always returns an array; a
						// single-id update must keep the scalar so the recursive
						// line-numbers branch returns a single row (matching the
						// shape of get(singleId)) instead of a one-element array.
						!Array.isArray(where) && Array.isArray(lineNumbers)
							? lineNumbers[0]
							: lineNumbers,
						options,
						returnUpdatedData as boolean,
						true,
					);
			} finally {
				// The recursion released its own (reentrant) acquisition;
				// release ours too (transactions keep the lock until commit).
				if (inlineLock) await File.unlock(join(tablePath, ".tmp"));
			}
		} else if (Utils.isObject(where)) {
			// Criteria resolve to physical lines too. Keep the writer lock from
			// selection through the awaited recursive write, exactly as for IDs.
			let inlineLock = false;
			try {
				if (this.activeTransaction) await this.ensureTxnLock(tableName);
				else {
					await File.lock(join(tablePath, ".tmp"));
					inlineLock = true;
				}
				const lineNumbers = await this.get(
					tableName,
					where,
					undefined,
					undefined,
					true,
				);
				if (lineNumbers)
					return await this.put<TData>(
						tableName,
						clonedData,
						lineNumbers,
						options,
						returnUpdatedData as boolean,
						true,
					);
			} finally {
				if (inlineLock) await File.unlock(join(tablePath, ".tmp"));
			}
		} else throw this.createError("INVALID_PARAMETERS");
	}

	/**
	 * Delete item(s) in a table
	 *
	 * @param {string} tableName
	 * @param {(number | string | (number | string)[] | Criteria)} [where]
	 * @return {boolean | null}  {(Promise<boolean | null>)}
	 */
	public async delete(
		tableName: string,
		where?: number | string | (number | string)[] | Criteria,
		_whereIsLinesNumbers?: boolean,
		_cascadeGuard?: Set<string>,
	): Promise<boolean | null> {
		return File.runWithLockStore(() =>
			this.automaticDeltaWrite(
				tableName,
				Boolean(where) && (!Array.isArray(where) || where.length <= 256),
				() =>
					this._delete(tableName, where, _whereIsLinesNumbers, _cascadeGuard),
			),
		);
	}

	private async deleteViaLog(
		tableName: string,
		where: number | string | (number | string)[] | Criteria,
		isLines: boolean,
		guard: Set<string>,
	): Promise<boolean> {
		const tablePath = join(this.databasePath, tableName);
		const ids: number[] = [];
		await File.lock(join(tablePath, ".tmp"));
		try {
			let overlay = await this.getOverlay(tableName, true);
			if (!overlay) throw this.createError("UNSUPPORTED_FORMAT", tableName);
			if (
				overlay.size >=
					((await this.currentFormat(tableName))?.automatic
						? Math.min(2048, maxOverlayRecords())
						: maxOverlayRecords()) ||
				(await overlay.log.bytes()) >=
					((await this.currentFormat(tableName))?.automatic
						? Math.min(8 * 1024 * 1024, maxLogBytes())
						: maxLogBytes())
			) {
				await this.compactLogTable(tableName);
				overlay = await this.getOverlay(tableName, true);
			}
			if (!overlay) throw this.createError("UNSUPPORTED_FORMAT", tableName);
			const found = isLines
				? Array.isArray(where)
					? (where as number[])
					: [Number(where)]
				: await this.get(tableName, where, { perPage: -1 }, undefined, true);
			if (!found) return false;
			const lines = Array.isArray(found)
				? (found as number[])
				: [Number(found)];
			if (
				lines.length > 256 &&
				(await this.currentFormat(tableName))?.automatic
			) {
				const ids = await this.overlayLineIds(tableName, lines);
				await this.leaveAutomaticDeltas(tableName);
				return (
					(await this._delete(tableName, [...ids.values()], false, guard)) ??
					false
				);
			}
			const lineIds = await this.overlayLineIds(tableName, lines);
			const records: UpdateRecord[] = [];
			const now = Date.now();
			for (const id of new Set(lineIds.values())) {
				if ((await overlay.get(id))?.deleted) continue;
				ids.push(id);
				records.push({ id, cols: {}, updatedAt: now, deleted: true });
			}
			if (!records.length) return false;
			const frames = buildFrames(records, overlay.committedGen + 1);
			if (frames.length === 1) await overlay.log.append(frames[0]);
			else
				await this.commitFiles(
					tablePath,
					[await overlay.log.stage(frames, tablePath)],
					null,
				);
			await overlay.applyLocal(frames);
			this.idDensity.set(tableName, false);
			const pagination = await this.resolvePagination(tableName);
			this.totalItems.set(
				`${tableName}-*`,
				pagination.total - overlay.deletedCount,
			);
		} finally {
			await File.unlock(join(tablePath, ".tmp"));
		}
		await this.cascadeDelete(tableName, ids, guard);
		return true;
	}

	private async _delete(
		tableName: string,
		where?: number | string | (number | string)[] | Criteria,
		_whereIsLinesNumbers?: boolean,
		_cascadeGuard?: Set<string>,
	): Promise<boolean | null> {
		this.validateName(tableName);

		if (!this.activeTransaction) await this.ensureDatabaseRecovered();
		const tablePath = join(this.databasePath, tableName);
		await this.throwErrorIfTableEmpty(tableName);

		if (this.isLogTable(tableName) && this.activeTransaction)
			throw this.createError(
				"MAINTENANCE_REQUIRED",
				`${tableName} (delete inside a transaction on update-log table)`,
			);
		if (where && (await this.currentFormat(tableName))?.tombstones)
			return this.deleteViaLog(
				tableName,
				where,
				_whereIsLinesNumbers === true,
				_cascadeGuard ?? new Set(),
			);

		// Fold any pending puts into the base before a tombstone rewrite, so the
		// log is empty and the rewritten base carries every acknowledged value.
		// `compact` is a no-op when there is nothing to fold.
		if (this.isLogTable(tableName)) await this.compact(tableName);

		if (!where) {
			let txnStaged = false;
			// Crash-atomic truncate: park every column file (pure removal
			// ops) and publish the empty row count in one journaled commit.
			const renameList: (string | null)[][] = [];
			try {
				if (this.activeTransaction) await this.ensureTxnLock(tableName);
				else await File.lock(join(tablePath, ".tmp"));

				const files = (await readdir(tablePath)) ?? [];
				renameList.push(
					...files
						.filter((fileName: string) =>
							fileName.endsWith(this.getFileExtension(tableName)),
						)
						.map((file) => [null, join(tablePath, file)] as (string | null)[]),
				);

				const {
					filePath: paginationFilePath,
					lastId,
					total,
				} = await this.resolvePagination(tableName);

				const pagination = {
					from: paginationFilePath,
					to: join(tablePath, `${lastId}-0.pagination`),
				};

				if (this.activeTransaction) {
					await this.stageTxnOp(tableName, renameList, pagination);
					txnStaged = true;
					const stagedEntry = this.txnTableEntry(tableName);
					if (stagedEntry) stagedEntry.total = 0;
				} else {
					await this.commitFiles(tablePath, renameList, pagination);

					if (
						globalConfig[this.databasePath].tables?.get(tableName)?.config.cache
					)
						await this.clearCache(tableName);
				}

				this.idDensity.set(tableName, true);

				// Deleting every row must also delete rows that reference them.
				if (total) {
					const allLines = Array.from({ length: total }, (_, i) => i + 1);
					await this.cascadeDelete(tableName, allLines, new Set());
				}

				return true;
			} finally {
				if (this.activeTransaction) {
					if (!txnStaged && renameList.length)
						await Promise.allSettled(
							renameList
								.filter((pair): pair is [string, string] => Boolean(pair[0]))
								.map(async ([tempPath, _]) => unlink(tempPath)),
						);
				} else {
					if (renameList.length)
						await Promise.allSettled(
							renameList
								.filter((pair): pair is [string, string] => Boolean(pair[0]))
								.map(async ([tempPath, _]) => unlink(tempPath)),
						);
					await File.unlock(join(tablePath, ".tmp"));
				}
			}
		}
		if (
			((Array.isArray(where) && where.every(Utils.isNumber)) ||
				Utils.isNumber(where)) &&
			// Numeric where is a line number only through the internal
			// recursion (flag set). An external numeric where is an id — even
			// on non-decodeID tables, where ids are NOT line numbers (prepend
			// layout / rows deleted); using them as lines edited the wrong row
			// and padded the column file (Sep-2026 rename bug). Ids are
			// resolved by the next branch.
			_whereIsLinesNumbers
		) {
			// "where" in this case, is the line(s) number(s) and not id(s)
			const files = (await readdir(tablePath))?.filter((fileName: string) =>
				fileName.endsWith(this.getFileExtension(tableName)),
			);

			if (files.length) {
				const renameList: (string | null)[][] = [];
				let txnStaged = false;
				try {
					if (this.activeTransaction) await this.ensureTxnLock(tableName);
					else await File.lock(join(tablePath, ".tmp"));

					const {
						filePath: paginationFilePath,
						lastId,
						total,
					} = await this.resolvePagination(tableName);

					const remaining = total - (Array.isArray(where) ? where.length : 1);

					if (total && remaining > 0) {
						this.idDensity.set(tableName, false);
						await settleWrites(
							await Promise.allSettled(
								files.map(async (file) =>
									renameList.push(
										await File.remove(join(tablePath, file), where),
									),
								),
							),
						);

						const pagination = {
							from: paginationFilePath,
							to: join(tablePath, `${lastId}-${remaining}.pagination`),
						};
						if (this.activeTransaction) {
							await this.stageTxnOp(tableName, renameList, pagination);
							txnStaged = true;
							const stagedEntry = this.txnTableEntry(tableName);
							if (stagedEntry) stagedEntry.total = remaining;
						} else {
							await this.commitFiles(tablePath, renameList, pagination);
						}
					} else {
						this.idDensity.set(tableName, true);
						// Deleting every remaining row: pure removals.
						const truncateList: (string | null)[][] = (await readdir(tablePath))
							?.filter((fileName: string) =>
								fileName.endsWith(this.getFileExtension(tableName)),
							)
							.map((file) => [null, join(tablePath, file)]);

						const pagination = {
							from: paginationFilePath,
							to: join(tablePath, `${lastId}-0.pagination`),
						};
						if (this.activeTransaction) {
							await this.stageTxnOp(tableName, truncateList, pagination);
							txnStaged = true;
							const stagedEntry = this.txnTableEntry(tableName);
							if (stagedEntry) stagedEntry.total = 0;
						} else {
							await this.commitFiles(tablePath, truncateList, pagination);
						}
					}

					// Cache still describes the committed state while a
					// transaction is open, so only clear it outside one.
					if (
						!this.activeTransaction &&
						globalConfig[this.databasePath].tables?.get(tableName)?.config.cache
					)
						await this.clearCache(tableName);

					// Cascade: rows in other tables referencing the deleted rows
					// (via `table`-typed fields) are removed too.
					await this.cascadeDelete(
						tableName,
						Array.isArray(where) ? where : [where],
						_cascadeGuard ?? new Set(),
					);

					return true;
				} finally {
					if (this.activeTransaction) {
						if (!txnStaged && renameList.length)
							await Promise.allSettled(
								renameList
									.filter((pair): pair is [string, string] => Boolean(pair[0]))
									.map(async ([tempPath, _]) => unlink(tempPath)),
							);
					} else {
						if (renameList.length)
							await Promise.allSettled(
								renameList
									.filter((pair): pair is [string, string] => Boolean(pair[0]))
									.map(async ([tempPath, _]) => unlink(tempPath)),
							);
						await File.unlock(join(tablePath, ".tmp"));
					}
				}
			}
		}
		if (
			(!_whereIsLinesNumbers &&
				((Array.isArray(where) && where.every(Utils.isNumber)) ||
					Utils.isNumber(where))) ||
			(Array.isArray(where) && where.every(Utils.isValidID)) ||
			Utils.isValidID(where)
		) {
			// Resolve id -> line(s) WHILE holding the writer lock (see put():
			// a concurrent post between resolution and delete would shift the
			// lines of a prepend table and remove the wrong row).
			let inlineLock = false;
			try {
				if (this.activeTransaction) await this.ensureTxnLock(tableName);
				else {
					await File.lock(join(tablePath, ".tmp"));
					inlineLock = true;
				}
				const lineNumbers = await this.get(
					tableName,
					where,
					undefined,
					undefined,
					true,
				);
				// Deleting a non-existent id must not fall through to the
				// "delete all rows" branch (this.delete(_, null, _) would truncate
				// the whole table), so resolve the id to line numbers first and
				// only delegate when something actually matched.
				if (lineNumbers)
					return await this.delete(
						tableName,
						lineNumbers,
						true,
						_cascadeGuard ?? new Set(),
					);
				return false;
			} finally {
				if (inlineLock) await File.unlock(join(tablePath, ".tmp"));
			}
		}
		if (Utils.isObject(where)) {
			let inlineLock = false;
			try {
				if (this.activeTransaction) await this.ensureTxnLock(tableName);
				else {
					await File.lock(join(tablePath, ".tmp"));
					inlineLock = true;
				}
				const lineNumbers = await this.get(
					tableName,
					where,
					undefined,
					undefined,
					true,
				);
				if (lineNumbers)
					return await this.delete(
						tableName,
						lineNumbers,
						true,
						_cascadeGuard ?? new Set(),
					);
			} finally {
				if (inlineLock) await File.unlock(join(tablePath, ".tmp"));
			}
		} else throw this.createError("INVALID_PARAMETERS");
		return false;
	}

	/**
	 * Cascade delete: remove rows in other tables whose `table`-typed schema
	 * fields reference the given rows. Reference columns store the numeric
	 * (line-number) id of the referenced row, so deleted ids are matched
	 * against them directly. Recursion into child tables happens through
	 * `delete` itself (which calls this method again); the `guard` set keeps
	 * deep/cyclic reference chains from re-processing the same (table, line).
	 */
	private async cascadeDelete(
		tableName: string,
		deletedLines: number[],
		guard: Set<string>,
	): Promise<void> {
		if (!deletedLines.length) return;

		for (const line of deletedLines) guard.add(`${tableName}:${line}`);

		const tables = globalConfig[this.databasePath]?.tables;
		if (!tables) return;

		for (const [candidateName, tableData] of tables) {
			if (candidateName === tableName || !tableData?.schema) continue;

			// Only direct `table`-typed columns hold one stored id per row;
			// arrays/objects of table refs serialize differently and are
			// intentionally out of scope for the cascade.
			const refFields = Utils.flattenSchema(tableData.schema, true).filter(
				(field) => field.table === tableName && field.type === "table",
			);
			if (!refFields.length) continue;

			for (const field of refFields) {
				const refPath = join(
					this.databasePath,
					candidateName,
					`${field.key}${this.getFileExtension(candidateName)}`,
				);
				if (!(await File.isExists(refPath))) continue;

				const matching = new Set<number>();
				for (const line of deletedLines) {
					try {
						const [, , found] = await File.search(
							refPath,
							"=",
							line,
							undefined,
							undefined,
							{
								key: field.key,
								type: "number",
								databasePath: this.databasePath,
							},
							undefined,
							undefined,
							false,
						);
						if (found) for (const l of found) matching.add(l);
					} catch (error) {
						// Unreadable/unsupported column -> skip this reference.
						// Inside a transaction a broken reference must abort the
						// whole cascade (all-or-nothing).
						if (this.activeTransaction) throw error;
					}
				}

				const toDelete = [...matching].filter((line) => {
					const key = `${candidateName}:${line}`;
					if (guard.has(key)) return false;
					guard.add(key);
					return true;
				});
				if (!toDelete.length) continue;

				try {
					await this.delete(candidateName, toDelete, true, guard);
				} catch (error) {
					// Cascade is best-effort outside a transaction: never break
					// the parent delete. Inside a transaction a cascade failure
					// must abort the whole txn (all-or-nothing).
					if (this.activeTransaction) throw error;
				}
			}
		}
	}

	/**
	 * Generate sum of column(s) in a table
	 *
	 * @param {string} tableName
	 * @param {string} columns
	 * @param {(number | string | (number | string)[] | Criteria)} [where]
	 * @return {*}  {Promise<number | Record<string, number>>}
	 */
	sum(
		tableName: string,
		columns: string,
		where?: number | string | (number | string)[] | Criteria,
		options?: AggregateOptions,
	): Promise<number>;
	sum(
		tableName: string,
		columns: string[],
		where?: number | string | (number | string)[] | Criteria,
		options?: AggregateOptions,
	): Promise<Record<string, number>>;
	public async sum(
		tableName: string,
		columns: string | string[],
		where?: number | string | (number | string)[] | Criteria,
		options?: AggregateOptions,
	): Promise<number | Record<string, number>> {
		this.validateName(tableName);

		if (!Array.isArray(columns)) columns = [columns];
		for (const column of columns) {
			// Nested columns are dotted child paths (validated structurally by
			// `sumNested`); everything else must be a plain safe name.
			if (!options?.nested) this.validateName(column);
		}

		await this.throwErrorIfTableEmpty(tableName);
		const RETURN: Record<string, number> = {};
		const tablePath = join(this.databasePath, tableName);

		if (options?.nested) {
			const nested = await this.sumNested(tableName, columns, where, tablePath);
			return columns.length > 1 ? nested : Object.values(nested)[0];
		}

		for await (const column of columns) {
			const columnPath = join(
				tablePath,
				`${column}${this.getFileExtension(tableName)}`,
			);
			if (await File.isExists(columnPath)) {
				if (where) {
					// `{ perPage: -1 }` so criteria matching is never capped by
					// the default page size (15): every matching row counts.
					const lineNumbers = await this.get(
						tableName,
						where,
						{ perPage: -1 },
						undefined,
						true,
					);

					RETURN[column] = lineNumbers
						? await File.sum(
								columnPath,
								lineNumbers,
								await this.overlayColumnOverrides(tableName, column),
							)
						: 0;
				} else
					RETURN[column] = await File.sum(
						columnPath,
						undefined,
						await this.overlayColumnOverrides(tableName, column),
					);
			}
		}
		return columns.length > 1 ? RETURN : Object.values(RETURN)[0];
	}

	/**
	 * Element-wise aggregation over an array-of-objects column (`nested` mode).
	 *
	 * `where` keys that resolve as children of the array root become per-element
	 * predicates (AND); everything else is a row-level filter. Only elements
	 * passing every element predicate, inside rows passing the row filters, are
	 * accumulated.
	 */
	private async sumNested(
		tableName: string,
		columns: string[],
		where?: number | string | (number | string)[] | Criteria,
		tablePath?: string,
	): Promise<Record<string, number>> {
		const tablePathSafe = tablePath ?? join(this.databasePath, tableName);
		const schema =
			globalConfig[this.databasePath].tables?.get(tableName)?.schema ?? [];
		const RETURN: Record<string, number> = {};

		// Resolve the array-of-objects root from the summed columns (v1: exactly
		// one nesting level, e.g. "items.quantity" -> root "items").
		let rootKey: string | null = null;
		let rootField: Field | null = null;
		const targetFields = new Map<string, Field>();
		for (const column of columns) {
			const dot = column.indexOf(".");
			if (
				dot <= 0 ||
				dot === column.length - 1 ||
				column.indexOf(".", dot + 1) !== -1
			)
				throw this.createError("INVALID_PARAMETERS", [
					`sum nested: '${column}' must be a single-level child path of an array-of-objects column`,
				]);
			const rk = column.slice(0, dot);
			if (rootKey !== null && rk !== rootKey)
				throw this.createError("INVALID_PARAMETERS", [
					"sum nested: all summed columns must share the same array root",
				]);
			rootKey = rk;
			// NB: `getField` on a single segment that resolves to an
			// array-of-objects field returns its *first child*, so resolve the
			// root field directly from the top-level schema.
			rootField = schema.find((f) => f.key === rk) ?? null;
			const okRoot =
				rootField &&
				rootField.type === "array" &&
				Array.isArray(rootField.children) &&
				Utils.isArrayOfObjects(rootField.children);
			if (!okRoot)
				throw this.createError("INVALID_PARAMETERS", [
					`sum nested: '${rk}' is not an array-of-objects column`,
				]);
			const child = Utils.getField(column, schema) as Field | null;
			if (!child || child.type === "array" || child.type === "object")
				throw this.createError("INVALID_PARAMETERS", [
					`sum nested: '${column}' does not resolve to a scalar child`,
				]);
			targetFields.set(column, child);
		}
		if (!rootKey) return RETURN;

		// Split `where` into element predicates (children of the root) and a
		// row-level filter (everything else, incl. `and`/`or` groups).
		const elementPredicates: {
			field: Field;
			operator: ComparisonOperator;
			comparedValue:
				| string
				| number
				| boolean
				| null
				| (string | number | boolean | null)[];
		}[] = [];
		const rowWhere: Criteria = {};
		let idWhere: number | string | (number | string)[] | undefined;
		if (where && Utils.isObject(where)) {
			for (const [key, value] of Object.entries(where as Record<string, any>)) {
				if (key === "and" || key === "or") {
					rowWhere[key] = value;
					continue;
				}
				const candidate = key.startsWith(`${rootKey}.`)
					? key
					: `${rootKey}.${key}`;
				const child = Utils.getField(candidate, schema) as Field | null;
				if (child) {
					if (Utils.isObject(value))
						throw this.createError("INVALID_PARAMETERS", [
							`sum nested: element predicate '${key}' must be a scalar, not an object`,
						]);
					const [operator, comparedValue] =
						typeof value === "string"
							? Utils.FormatObjectCriteriaValue(value)
							: (["=", value] as [
									ComparisonOperator,
									string | number | boolean | null,
								]);
					if (operator === "[]" || operator === "![]")
						throw this.createError("INVALID_PARAMETERS", [
							`sum nested: operator '${operator}' is not supported on element predicates`,
						]);
					elementPredicates.push({
						field: child,
						operator,
						comparedValue,
					});
				} else {
					if (!Utils.getField(key, schema))
						throw this.createError("INVALID_PARAMETERS", [
							`sum nested: criteria key '${key}' matches neither the array root nor a row column`,
						]);
					rowWhere[key] = value;
				}
			}
		} else if (
			typeof where === "number" ||
			typeof where === "string" ||
			Array.isArray(where)
		) {
			idWhere = where;
		}

		// Row-level narrowing (ids or criteria). `undefined` lines = whole file.
		let lines: number[] | null | undefined;
		if (idWhere !== undefined)
			lines = (await this.get(
				tableName,
				idWhere,
				{ perPage: -1 },
				undefined,
				true,
			)) as number[] | null;
		else if (Object.keys(rowWhere).length)
			lines = (await this.get(
				tableName,
				rowWhere,
				{ perPage: -1 },
				undefined,
				true,
			)) as number[] | null;
		if (lines === null) {
			for (const column of columns) RETURN[column] = 0;
			return RETURN;
		}

		const fieldOpt = (field: Field): Field & { databasePath?: string } => ({
			...field,
			databasePath: this.databasePath,
		});
		const ext = this.getFileExtension(tableName);

		// Element predicate cells, read once for every summed column.
		const predCells = new Map<string, Record<number, any> | null>();
		for (const p of elementPredicates) {
			const path = join(tablePathSafe, `${rootKey}.${p.field.key}${ext}`);
			if (!(await File.isExists(path))) continue;
			const cell = (await File.get(path, lines, fieldOpt(p.field))) as Record<
				number,
				any
			> | null;
			if (cell) predCells.set(p.field.key, cell);
		}

		for (const [column, child] of targetFields) {
			const path = join(tablePathSafe, `${column}${ext}`);
			if (!(await File.isExists(path))) {
				RETURN[column] = 0;
				continue;
			}
			const cell = (await File.get(path, lines, fieldOpt(child))) as Record<
				number,
				any
			> | null;
			if (!cell) {
				RETURN[column] = 0;
				continue;
			}

			let sum = 0;
			for (const [lineStr, values] of Object.entries(cell)) {
				if (!Array.isArray(values)) continue;
				for (let i = 0; i < values.length; i++) {
					const v = values[i];
					if (v === null || v === undefined) continue;
					let matches = true;
					for (const p of elementPredicates) {
						const pv = predCells.get(p.field.key)?.[Number(lineStr)]?.[i];
						if (
							pv === undefined ||
							!UtilsServer.compare(
								p.operator,
								pv,
								p.comparedValue,
								p.field.type,
							)
						) {
							matches = false;
							break;
						}
					}
					if (!matches) continue;
					const num = Number(v);
					if (Number.isNaN(num)) continue;
					sum += num;
				}
			}
			RETURN[column] = sum;
		}
		return RETURN;
	}

	/**
	 * Generate average of column(s) in a table
	 *
	 * @param {string} tableName
	 * @param {string} columns
	 * @param {(number | string | (number | string)[] | Criteria)} [where]
	 * @return {*}  {Promise<number | Record<string, number>>}
	 */
	avg(
		tableName: string,
		columns: string,
		where?: number | string | (number | string)[] | Criteria,
	): Promise<number>;
	avg(
		tableName: string,
		columns: string[],
		where?: number | string | (number | string)[] | Criteria,
	): Promise<Record<string, number>>;
	public async avg(
		tableName: string,
		columns: string | string[],
		where?: number | string | (number | string)[] | Criteria,
	): Promise<number | Record<string, number>> {
		this.validateName(tableName);

		if (!Array.isArray(columns)) columns = [columns];
		for (const column of columns) this.validateName(column);

		await this.throwErrorIfTableEmpty(tableName);
		const RETURN: Record<string, number> = {};
		const tablePath = join(this.databasePath, tableName);

		for await (const column of columns) {
			const columnPath = join(
				tablePath,
				`${column}${this.getFileExtension(tableName)}`,
			);
			if (await File.isExists(columnPath)) {
				if (where) {
					const lineNumbers = await this.get(
						tableName,
						where,
						{ perPage: -1 },
						undefined,
						true,
					);

					RETURN[column] = lineNumbers
						? await File.avg(
								columnPath,
								lineNumbers,
								await this.overlayColumnOverrides(tableName, column),
							)
						: 0;
				} else
					RETURN[column] = await File.avg(
						columnPath,
						undefined,
						await this.overlayColumnOverrides(tableName, column),
					);
			}
		}
		return columns.length > 1 ? RETURN : Object.values(RETURN)[0];
	}

	/**
	 * Generate max of column(s) in a table
	 *
	 * @param {string} tableName
	 * @param {string} columns
	 * @param {(number | string | (number | string)[] | Criteria)} [where]
	 * @return {*}  {Promise<number>}
	 */
	max(
		tableName: string,
		columns: string,
		where?: number | string | (number | string)[] | Criteria,
	): Promise<number>;
	max(
		tableName: string,
		columns: string[],
		where?: number | string | (number | string)[] | Criteria,
	): Promise<Record<string, number>>;
	public async max(
		tableName: string,
		columns: string | string[],
		where?: number | string | (number | string)[] | Criteria,
	): Promise<number | Record<string, number>> {
		this.validateName(tableName);

		if (!Array.isArray(columns)) columns = [columns];
		for (const column of columns) this.validateName(column);

		const RETURN: Record<string, number> = {};
		const tablePath = join(this.databasePath, tableName);
		await this.throwErrorIfTableEmpty(tableName);

		for await (const column of columns) {
			const columnPath = join(
				tablePath,
				`${column}${this.getFileExtension(tableName)}`,
			);
			if (await File.isExists(columnPath)) {
				if (where) {
					const lineNumbers = await this.get(
						tableName,
						where,
						{ perPage: -1 },
						undefined,
						true,
					);
					RETURN[column] = lineNumbers
						? await File.max(
								columnPath,
								lineNumbers,
								await this.overlayColumnOverrides(tableName, column),
							)
						: 0;
				} else
					RETURN[column] = await File.max(
						columnPath,
						undefined,
						await this.overlayColumnOverrides(tableName, column),
					);
			}
		}
		return RETURN;
	}

	/**
	 * Generate min of column(s) in a table
	 *
	 * @param {string} tableName
	 * @param {string} columns
	 * @param {(number | string | (number | string)[] | Criteria)} [where]
	 * @return {*}  {Promise<number>}
	 */
	min(
		tableName: string,
		columns: string,
		where?: number | string | (number | string)[] | Criteria,
	): Promise<number>;
	min(
		tableName: string,
		columns: string[],
		where?: number | string | (number | string)[] | Criteria,
	): Promise<Record<string, number>>;
	public async min(
		tableName: string,
		columns: string | string[],
		where?: number | string | (number | string)[] | Criteria,
	): Promise<number | Record<string, number>> {
		this.validateName(tableName);

		if (!Array.isArray(columns)) columns = [columns];
		for (const column of columns) this.validateName(column);

		const RETURN: Record<string, number> = {};
		const tablePath = join(this.databasePath, tableName);
		await this.throwErrorIfTableEmpty(tableName);

		for await (const column of columns) {
			const columnPath = join(
				tablePath,
				`${column}${this.getFileExtension(tableName)}`,
			);
			if (await File.isExists(columnPath)) {
				if (where) {
					const lineNumbers = await this.get(
						tableName,
						where,
						{ perPage: -1 },
						undefined,
						true,
					);
					RETURN[column] = lineNumbers
						? await File.min(
								columnPath,
								lineNumbers,
								await this.overlayColumnOverrides(tableName, column),
							)
						: 0;
				} else
					RETURN[column] = await File.min(
						columnPath,
						undefined,
						await this.overlayColumnOverrides(tableName, column),
					);
			}
		}
		return RETURN;
	}
}
