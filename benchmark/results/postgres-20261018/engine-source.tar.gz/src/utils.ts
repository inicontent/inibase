import { COMPUTED_EXPR_MAX_LENGTH } from "./expression.js";
import type {
	ComparisonOperator,
	Data,
	ErrorCode,
	ErrorLang,
	Field,
	FieldType,
	Schema,
} from "./index.js";

/**
 * Type guard function to check if the input is an array of objects.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input is an array of objects, false otherwise.
 *
 * Note: Considers empty arrays and arrays where every element is an object.
 */
export const isArrayOfObjects = (input: unknown): input is Record<any, any>[] =>
	Array.isArray(input) && (input.length === 0 || input.every(isObject));

/**
 * Type guard function to check if the input is an array of arrays.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input is an array of arrays, false otherwise.
 *
 * Note: Considers empty arrays and arrays where every element is also an array.
 */
export const isArrayOfArrays = (input: unknown): input is any[][] =>
	Array.isArray(input) && input.length > 0 && input.every(Array.isArray);

/**
 * Type guard function to check if the input is an array of nulls or an array of arrays of nulls.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input is an array consisting entirely of nulls or arrays of nulls, false otherwise.
 *
 * Note: Recursively checks each element, allowing for nested arrays of nulls.
 */
export const isArrayOfNulls = (input: unknown): input is null[] | null[][] =>
	Array.isArray(input) &&
	input.every((_input: null) =>
		Array.isArray(_input)
			? isArrayOfNulls(_input)
			: _input === null || _input === 0 || _input === undefined,
	);

/**
 * Type guard function to check if the input is an object.
 *
 * @param obj - The value to be checked.
 * @returns boolean - True if the input is an object (excluding arrays), false otherwise.
 *
 * Note: Checks if the input is non-null and either has 'Object' as its constructor name or is of type 'object' without being an array.
 */
export const isObject = (object: unknown): object is Record<any, any> =>
	object != null &&
	((typeof object === "object" && !Array.isArray(object)) ||
		object.constructor?.name === "Object");

/**
 * Type guard function to check if the input is a number.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input is a number, false otherwise.
 *
 * Note: Validates that the input can be parsed as a float and that subtracting zero results in a number, ensuring it's a numeric value.
 */
export const isNumber = (input: unknown): input is number => {
	// Case 1: It's already a number (and not NaN/Infinity).
	if (typeof input === "number")
		return !Number.isNaN(input) && Number.isFinite(input);

	// Case 2: It's a string that can parse to a finite number.
	if (typeof input === "string") {
		const trimmed = input.trim();
		// Empty string or whitespace-only => not numeric
		if (!trimmed) return false;

		const parsed = Number(trimmed); // or parseFloat(trimmed)
		return !Number.isNaN(parsed) && Number.isFinite(parsed);
	}

	// Otherwise, not a numeric string or number
	return false;
};

// As a literal (no double-escaping).
const emailPattern =
	/^[A-Za-z0-9!#%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#%&'*+/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?$/;
/**
 * Checks if the input is a valid email format.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input matches the email format, false otherwise.
 *
 * Note: Uses a regular expression to validate the email format, ensuring it has parts separated by '@' and contains a domain with a period.
 */
export const isEmail = (input: unknown) =>
	typeof input === "string" && emailPattern.test(String(input));

const urlPattern = new RegExp(
	"^" +
		// Optional protocol
		"(https?:\\/\\/)?" +
		// domain name (with underscore allowed), localhost, or ipv4
		"((([a-z\\d_]([a-z\\d_\\-]*[a-z\\d_])*)\\.)+[a-z]{2,}|" +
		"localhost|" +
		"((\\d{1,3}\\.){3}\\d{1,3}))" +
		// optional port
		"(\\:\\d+)?" +
		// path
		"(\\/[-a-z\\d%_.~+]*)*" +
		// query string
		"(\\?[;&a-z\\d%_.~+=-]*)?" +
		// fragment
		"(\\#[-a-z\\d_]*)?$",
	"i",
);
/**
 * Checks if the input is a valid URL format.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input matches the URL format, false otherwise.
 *
 * Note: Validates URLs including protocols (http/https), domain names, IP addresses, ports, paths, query strings, and fragments.
 *       Also recognizes 'tel:' and 'mailto:' as valid URL formats, as well as strings starting with '#' without spaces.
 */
export const isURL = (input: unknown) => {
	if (typeof input !== "string") return false;
	if (
		(input[0] === "#" && !input.includes(" ")) ||
		input.startsWith("tel:") ||
		input.startsWith("mailto:") ||
		URL.canParse(input)
	)
		return true;

	return urlPattern.test(input);
};

const htmlPattern =
	/<([A-Za-z][A-Za-z0-9-]*)(\s+[A-Za-z-]+(\s*=\s*(?:".*?"|'.*?'|[^'">\s]+))?)*\s*>/;
/**
 * Checks if the input contains HTML tags or entities.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input contains HTML tags or entities, false otherwise.
 *
 * Note: Uses a regular expression to detect HTML tags (like <tag>) and entities (like &entity;).
 *       Recognizes both opening and closing tags, as well as self-closing tags.
 */
export const isHTML = (input: unknown) =>
	typeof input === "string" && htmlPattern.test(input);

/**
 * Type guard function to check if the input is a string, excluding strings that match specific formats (number, boolean, email, URL, IP).
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input is a string that doesn't match the specific formats, false otherwise.
 *
 * Note: Validates the input against being a number, boolean, email, URL, or IP address to ensure it's a general string.
 */
export const isString = (input: unknown): input is string =>
	Object.prototype.toString.call(input) === "[object String]" &&
	(!isNumber(input) || String(input).at(0) === "0");

const ipPattern =
	/^(?:(?:2(?:5[0-5]|[0-4]\d)|1?\d?\d)\.){3}(?:2(?:5[0-5]|[0-4]\d)|1?\d?\d)$/;
/**
 * Checks if the input is a valid IP address format.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input matches the IP address format, false otherwise.
 *
 * Note: Uses a regular expression to validate IP addresses, ensuring they consist of four octets, each ranging from 0 to 255.
 */
export const isIP = (input: unknown): input is string =>
	typeof input === "string" && ipPattern.test(input);

/**
 * Type guard function to check if the input is a boolean or a string representation of a boolean.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input is a boolean value or 'true'/'false' strings, false otherwise.
 *
 * Note: Recognizes both boolean literals (true, false) and their string representations ("true", "false").
 */
export const isBoolean = (input: unknown): input is boolean =>
	typeof input === "boolean" || input === "true" || input === "false";

/**
 * Type guard function to check if the input is a password based on a specific length criterion.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the input is a string with a length of 161 characters, false otherwise.
 *
 * Note: Specifically checks for string length to determine if it matches the defined password length criterion.
 */
export const isPassword = (input: unknown): input is string =>
	typeof input === "string" && input.length === 97;

/**
 * Checks if the input can be converted to a valid date.
 *
 * @param input - The input to be checked, can be of any type.
 * @returns A boolean indicating whether the input is a valid date.
 */
export const dateToTimestamp = (input: unknown): number | null => {
	// Check if the input is null, undefined, or an empty string
	if (input == null || input === "") return null;

	if (typeof input === "string") {
		const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(input);
		if (match) {
			const year = Number(match[1]);
			const month = Number(match[2]);
			const day = Number(match[3]);
			const timestamp = Date.UTC(year, month - 1, day);
			const date = new Date(timestamp);
			return date.getUTCFullYear() === year &&
				date.getUTCMonth() === month - 1 &&
				date.getUTCDate() === day
				? timestamp
				: null;
		}
	}

	// Convert to number and check if it's a valid number
	const numTimestamp = Number(input);
	// Check if the converted number is NaN or not finite
	if (Number.isNaN(numTimestamp) || !Number.isFinite(numTimestamp)) return null;

	// Create a Date object from the timestamp
	const date = new Date(numTimestamp);
	// Check if the date is valid
	return date.getTime() === numTimestamp ? numTimestamp : null;
};

export const isDate = (input: unknown): boolean =>
	dateToTimestamp(input) !== null;

/**
 * Checks if the input is a valid ID.
 *
 * @param input - The input to be checked, can be of any type.
 * @returns A boolean indicating whether the input is a string representing a valid ID of length 32.
 */

export const isValidID = (input: unknown): input is string => {
	return typeof input === "string" && input.length === 32;
};

/**
 * Checks if a given string is a valid JSON.
 *
 * @param {string} input - The string to be checked.
 * @returns {boolean} Returns true if the string is valid JSON, otherwise false.
 */
export const isStringified = (input: unknown): boolean =>
	typeof input === "string" &&
	(input === "null" ||
		input === "undefined" ||
		input[0] === "{" ||
		input[0] === "[");

/**
 * Recursively merges properties from a source object into a target object. If a property exists in both, the source's value overwrites the target's.
 *
 * @param target - The target object to merge properties into.
 * @param source - The source object from which properties are merged.
 * @returns any - The modified target object with merged properties.
 *
 * Note: Performs a deep merge for nested objects. Non-object properties are directly overwritten.
 */
export const deepMerge = (target: any, source: any): any => {
	for (const key in source) {
		if (Object.hasOwn(source, key)) {
			if (isObject(source[key]) && isObject(target[key]))
				target[key] = deepMerge(target[key], source[key]);
			else if (source[key] !== null) target[key] = source[key];
		}
	}
	return target;
};

/**
 * Identifies and returns properties that have changed between two objects.
 *
 * @param obj1 - The first object for comparison, with string keys and values.
 * @param obj2 - The second object for comparison, with string keys and values.
 * @returns A record of changed properties with original values from obj1 and new values from obj2, or null if no changes are found.
 */
export const findChangedProperties = (
	obj1: Record<string, string>,
	obj2: Record<string, string>,
): Record<string, string | null> | null => {
	const result: Record<string, string | null> = {};

	for (const key1 in obj1) {
		if (Object.hasOwn(obj2, key1)) {
			if (obj1[key1] !== obj2[key1]) result[obj1[key1]] = obj2[key1];
		} else result[obj1[key1]] = null;
	}

	return Object.keys(result).length ? result : null;
};

/**
 * Detects the field type of an input based on available types.
 *
 * @param input - The input whose field type is to be detected.
 * @param availableTypes - An array of potential field types to consider.
 * @returns The detected field type as a string, or undefined if no matching type is found.
 */
export const detectFieldType = (
	input: any,
	availableTypes: FieldType[],
): FieldType | undefined => {
	if (input !== null && input !== undefined)
		if (!Array.isArray(input)) {
			if (
				(input === "0" ||
					input === "1" ||
					input === "true" ||
					input === "false") &&
				availableTypes.includes("boolean")
			)
				return "boolean";
			if (isNumber(input)) {
				if (availableTypes.includes("table")) return "table";
				if (availableTypes.includes("date")) return "date";
				if (availableTypes.includes("number")) return "number";
				if (availableTypes.includes("string") && String(input).at(0) === "0")
					return "string";
				if (availableTypes.includes("id")) return "id";
			} else if (typeof input === "string") {
				if (availableTypes.includes("table") && isValidID(input))
					return "table";
				if (input.startsWith("[") && availableTypes.includes("array"))
					return "array";
				if (availableTypes.includes("email") && isEmail(input)) return "email";
				if (availableTypes.includes("url") && isURL(input)) return "url";
				if (availableTypes.includes("password") && isPassword(input))
					return "password";
				if (availableTypes.includes("json") && isStringified(input))
					return "json";
				if (availableTypes.includes("json") && isDate(input)) return "json";
				if (availableTypes.includes("string") && isString(input))
					return "string";
				if (availableTypes.includes("ip") && isIP(input)) return "ip";
			}
		} else return "array";

	return undefined;
};

export const isFieldType = (field: Field, compareAtType: string | string[]) => {
	if (Array.isArray(field.type)) {
		if (
			field.type.some((type) =>
				Array.isArray(compareAtType)
					? compareAtType.includes(type)
					: compareAtType === type,
			)
		)
			return true;
	} else if (
		(Array.isArray(compareAtType) && compareAtType.includes(field.type)) ||
		compareAtType === field.type
	)
		return true;

	if (field.children) {
		if (Array.isArray(field.children)) {
			if (!isArrayOfObjects(field.children)) {
				if (
					field.children.some((type) =>
						Array.isArray(compareAtType)
							? compareAtType.includes(type)
							: compareAtType === type,
					)
				)
					return true;
			}
		} else if (
			(Array.isArray(compareAtType) &&
				compareAtType.includes(field.children)) ||
			compareAtType === field.children
		)
			return true;
	}

	return false;
};

// Function to recursively flatten an array of objects and their nested children
export const flattenSchema = (schema: Schema, keepParents = false) => {
	const result: Schema = [];

	const _flattenHelper = (item: Field, parentKey: string) => {
		if (item.children && isArrayOfObjects(item.children)) {
			if (keepParents) result.push((({ children, ...rest }) => rest)(item));
			for (const child of item.children) _flattenHelper(child, item.key);
		} else
			result.push({
				...item,
				key: parentKey ? `${parentKey}.${item.key}` : item.key,
			});
	};
	for (const item of schema) _flattenHelper(item, "");

	return result;
};

export const filterSchema = (
	schema: Schema,
	callback: (arg0: Field) => boolean,
) =>
	schema.filter((field) => {
		if (field.children && isArrayOfObjects(field.children))
			field.children = filterSchema(field.children, callback);
		return callback(field);
	});

/**
 * Validates if the given value matches the specified field type(s).
 *
 * @param value - The value to be validated.
 * @param field - Field object config.
 * @returns A boolean indicating whether the value matches the specified field type(s).
 */
export const validateFieldType = (value: any, field: Field): boolean => {
	if (value === null) return true;
	let _fieldType = field.type;
	if (Array.isArray(_fieldType)) {
		const detectedFieldType = detectFieldType(value, _fieldType);
		if (!detectedFieldType) return false;
		_fieldType = detectedFieldType;
	}

	if (_fieldType === "array" && field.children)
		return (
			Array.isArray(value) &&
			(isArrayOfObjects(field.children) ||
				value.every((v: any) => {
					let _fieldChildrenType = field.children as FieldType | FieldType[];
					if (Array.isArray(_fieldChildrenType)) {
						const detectedFieldType = detectFieldType(v, _fieldChildrenType);
						if (!detectedFieldType) return false;
						_fieldChildrenType = detectedFieldType;
					}
					return validateFieldType(v, {
						key: "BLABLA",
						type: _fieldChildrenType,
					});
				}))
		);

	switch (_fieldType) {
		case "string":
			return isString(value);
		case "password":
			return !Array.isArray(value) && !isObject(value); // accept
		case "number":
			return isNumber(value);
		case "html":
			return isHTML(value);
		case "ip":
			return isIP(value);
		case "boolean":
			return isBoolean(value);
		case "date":
			return isDate(value);
		case "object":
			return isObject(value);
		case "array":
			return Array.isArray(value);
		case "email":
			return isEmail(value);
		case "url":
			return isURL(value);
		case "table":
			// feat: check if id exists
			if (Array.isArray(value))
				return (
					(isArrayOfObjects(value) &&
						value.every(
							(element: Data) =>
								Object.hasOwn(element, "id") &&
								(isValidID(element.id) || isNumber(element.id)),
						)) ||
					value.every(isNumber) ||
					isValidID(value)
				);
			if (isObject(value))
				return (
					Object.hasOwn(value, "id") &&
					(isValidID((value as Data).id) || isNumber((value as Data).id))
				);
			return isNumber(value) || isValidID(value);
		case "id":
			return isNumber(value) || isValidID(value);
		case "json":
			return isStringified(value) || Array.isArray(value) || isObject(value);
		default:
			return false;
	}
};

export const FormatObjectCriteriaValue = (
	value: string,
): [
	ComparisonOperator,
	string | number | boolean | null | (string | number | null)[],
] => {
	switch (value[0]) {
		case ">":
		case "<":
			return value[1] === "="
				? [
						value.slice(0, 2) as ComparisonOperator,
						value.slice(2) as string | number,
					]
				: [
						value.slice(0, 1) as ComparisonOperator,
						value.slice(1) as string | number,
					];
		case "[":
			return value[1] === "]"
				? [
						"[]",
						(value.slice(2) as string | number)
							.toString()
							.split(",")
							.map((v) => (isNumber(v) ? Number(v) : v)),
					]
				: ["[]", value.slice(1) as string | number];
		case "!":
			return ["=", "*"].includes(value[1])
				? [
						value.slice(0, 2) as ComparisonOperator,
						value.slice(2) as string | number,
					]
				: value[1] === "["
					? [
							"![]",
							(value.slice(3) as string | number)
								.toString()
								.split(",")
								.map((v) => (isNumber(v) ? Number(v) : v)),
						]
					: [
							`${value.slice(0, 1)}=` as ComparisonOperator,
							value.slice(1) as string | number,
						];
		case "=":
			return ["=", value.slice(1) as string | number];
		case "*":
			return ["*", value.slice(1) as string | number];
		default:
			return ["=", value];
	}
};

/**
 * Get field from schema
 *
 * @export
 * @param {string} keyPath Support dot notation path
 * @param {Schema} schema
 */
export const getField = (keyPath: string, schema: Schema) => {
	let RETURN: Field | Schema | null = schema;
	const keyPathSplited = keyPath.split(".");
	for (const [index, key] of keyPathSplited.entries()) {
		if (!isArrayOfObjects(RETURN)) return null;
		const foundItem: Field | undefined = (RETURN as Schema).find(
			(item) => item.key === key,
		);
		if (!foundItem) return null;
		if (index === keyPathSplited.length - 1) RETURN = foundItem;
		if (
			(foundItem.type === "array" || foundItem.type === "object") &&
			foundItem.children &&
			isArrayOfObjects(foundItem.children)
		)
			RETURN = foundItem.children;
	}
	if (!RETURN) return null;
	return isArrayOfObjects(RETURN) ? RETURN[0] : RETURN;
};

/**
 * Override a schema field, key, type or other properties
 *
 * @export
 * @param {string} keyPath Support dot notation path
 * @param {Schema} schema
 * @param {(Omit<Field, "key" | "type"> & {
 * 		key?: string;
 * 		type?: FieldType | FieldType[];
 * 	})} field
 */
export const setField = (
	keyPath: string,
	schema: Schema,
	field: Omit<Field, "key" | "type"> & {
		key?: string;
		type?: FieldType | FieldType[];
	},
) => {
	const keyPathSplited = keyPath.split(".");
	for (const [index, key] of keyPathSplited.entries()) {
		const foundItem = schema.find((item) => item.key === key);
		if (!foundItem) return null;
		if (index === keyPathSplited.length - 1) {
			Object.assign(foundItem, field);
			return foundItem;
		}
		if (
			(foundItem.type === "array" || foundItem.type === "object") &&
			foundItem.children &&
			isArrayOfObjects(foundItem.children)
		)
			schema = foundItem.children as Schema;
	}
};

/**
 * Remove field from schema
 *
 * @export
 * @param {string} keyPath Support dot notation path
 * @param {Schema} schema
 */
export const unsetField = (keyPath: string, schema: Schema) => {
	const keyPathSplited = keyPath.split(".");
	let parent: any = null;
	let targetIndex: number | undefined;

	for (const [index, key] of keyPathSplited.entries()) {
		const foundItem = schema.find((item) => item.key === key);
		if (!foundItem) return null;
		if (index === keyPathSplited.length - 1) {
			if (parent) {
				if (Array.isArray(parent)) {
					if (targetIndex !== undefined) parent.splice(targetIndex, 1);
				} else delete parent[key];
			} else {
				const indexToRemove = schema.indexOf(foundItem);
				if (indexToRemove !== -1) schema.splice(indexToRemove, 1);
			}
			return foundItem;
		}
		if (
			(foundItem.type === "array" || foundItem.type === "object") &&
			foundItem.children &&
			isArrayOfObjects(foundItem.children)
		) {
			parent = foundItem.children;
			targetIndex = schema.indexOf(foundItem);
			schema = foundItem.children as Schema;
		} else {
			parent = foundItem;
			targetIndex = undefined;
		}
	}
};

export function toDotNotation(
	obj: Record<string, any>,
	skipKeys?: string[],
	currentPath = "",
): Record<string, any> {
	const result: Record<string, any> = {};

	for (const key in obj) {
		if (Object.hasOwn(obj, key)) {
			const value = obj[key];
			const newKey = currentPath ? `${currentPath}.${key}` : key;

			if (skipKeys?.includes(key.toLowerCase())) {
				// Preserve "or" and "and" keys with their exact values
				result[newKey] = value;
			} else if (
				typeof value === "object" &&
				value !== null &&
				!Array.isArray(value)
			) {
				// Recursively process nested objects
				const nested = toDotNotation(value, skipKeys, newKey);
				Object.assign(result, nested);
			} else {
				// Add primitive values directly
				result[newKey] = value;
			}
		}
	}

	return result;
}

// Function to recursively flatten an array of objects and their nested children
export const extractIdsFromSchema = (schema: Schema): number[] => {
	const result: number[] = [];

	for (const field of schema) {
		if (field.id) result.push(field.id);

		if (field.children && isArrayOfObjects(field.children))
			result.push(...extractIdsFromSchema(field.children));
	}

	return result;
};

/**
 * Finds the last ID number in a schema, potentially decoding it if encrypted.
 *
 * @param schema - The schema to search, defined as an array of schema objects.
 * @returns The last ID number in the schema, decoded if necessary.
 */
export const findLastIdNumber = (schema: Schema): number =>
	Math.max(...extractIdsFromSchema(schema));

/**
 * Adds or updates IDs in a schema, encoding them using a provided secret key or salt.
 *
 * @param schema - The schema to update, defined as an array of schema objects.
 * @param startWithID - An object containing the starting ID for generating new IDs.
 * @returns The updated schema with encoded IDs.
 */
export function addIdToSchema(schema: Schema, startWithID: { value: number }) {
	const clonedSchema = structuredClone(schema);
	function addIdToField(field: Field) {
		if (!field.id) {
			startWithID.value++;
			field.id = startWithID.value;
		}

		if (
			(field.type === "array" || field.type === "object") &&
			isArrayOfObjects(field.children)
		)
			field.children = addIdToSchemaHelper(field.children);
		return field;
	}
	const addIdToSchemaHelper = (schema: Schema) => schema.map(addIdToField);

	return addIdToSchemaHelper(clonedSchema);
}

/**
 * Translated error messages for every supported language and error code.
 * The `{variable}` placeholder is replaced with the relevant value by {@link createError}.
 */
export const ERROR_MESSAGES: Record<ErrorLang, Record<ErrorCode, string>> = {
	en: {
		TABLE_EMPTY: "Table {variable} is empty",
		TABLE_EXISTS: "Table {variable} already exists",
		TABLE_NOT_EXISTS: "Table {variable} doesn't exist",
		NO_SCHEMA: "Table {variable} does't have a schema",
		GROUP_UNIQUE:
			"Group {variable} should be unique, got duplicated content in {variable}",
		FIELD_UNIQUE: "Field {variable} should be unique, got {variable} instead",
		FIELD_REQUIRED: "Field {variable} is required",
		INVALID_ID: "The given ID(s) is/are not valid(s)",
		INVALID_TYPE: "Expect {variable} to be {variable}, got {variable} instead",
		INVALID_PARAMETERS: "The given parameters are not valid",
		INVALID_REGEX_MATCH: "Field {variable} does not match the expected pattern",
		INVALID_NAME: "Name {variable} is not valid",
		NO_ENV: "No environment file found",
		COMPUTED_FIELD_SYNTAX:
			"Invalid computed expression syntax in field {variable}",
		COMPUTED_FIELD_UNKNOWN_FIELD:
			"Field {variable} references unknown field id {variable}",
		COMPUTED_FIELD_INVALID_LINK:
			"Field {variable} has an invalid link at hop {variable}",
		COMPUTED_FIELD_INVALID_TARGET:
			"Field {variable} references an invalid target ({variable})",
		COMPUTED_FIELD_CONFLICT:
			"Field {variable} cannot be computed and required/unique/regex at the same time",
		COMPUTED_FIELD_CYCLE: "Computed fields form a cycle: {variable}",
		COMPUTED_FIELD_SETTABLE:
			"Field {variable} is computed and cannot be set directly",
		COMPUTED_FIELD_DANGLING_LINK:
			"Computed field {variable} references a missing row in table {variable}",
		COMPUTED_FIELD_ARITHMETIC:
			"Computed field {variable} failed evaluation ({variable})",
		UPDATE_LOG_CORRUPT:
			"Update log for table {variable} is corrupt and needs manual recovery",
		UPDATE_LOG_FRAME_TOO_LARGE:
			"Update log frame for table {variable} exceeds the maximum frame size",
		MAINTENANCE_REQUIRED:
			"Table {variable} needs compaction before it can accept more writes",
		UNSUPPORTED_FORMAT: "Unsupported database format (requires {variable})",
	},
	ar: {
		TABLE_EMPTY: "الجدول {variable} فارغ",
		TABLE_EXISTS: "الجدول {variable} موجود بالفعل",
		TABLE_NOT_EXISTS: "الجدول {variable} غير موجود",
		NO_SCHEMA: "الجدول {variable} ليس لديه مخطط",
		GROUP_UNIQUE:
			"المجموعة {variable} يجب أن تكون فريدة، تم العثور على محتوى مكرر في {variable}",
		FIELD_UNIQUE:
			"الحقل {variable} يجب أن يكون فريدًا، تم العثور على {variable} بدلاً من ذلك",
		FIELD_REQUIRED: "الحقل {variable} مطلوب",
		INVALID_ID: "المعرف أو المعرفات المقدمة غير صالحة",
		INVALID_TYPE:
			"من المتوقع أن يكون {variable} من النوع {variable}، لكن تم العثور على {variable} بدلاً من ذلك",
		INVALID_PARAMETERS: "المعلمات المقدمة غير صالحة",
		INVALID_REGEX_MATCH: "الحقل {variable} لا يتطابق مع النمط المتوقع",
		INVALID_NAME: "الاسم {variable} غير صالح",
		NO_ENV: "لم يتم العثور على ملف البيئة",
		COMPUTED_FIELD_SYNTAX: "صيغة الحقل المحسوب غير صالحة في الحقل {variable}",
		COMPUTED_FIELD_UNKNOWN_FIELD:
			"الحقل {variable} يشير إلى معرف حقل غير معروف {variable}",
		COMPUTED_FIELD_INVALID_LINK:
			"الحقل {variable} يحتوي على رابط غير صالح عند الخطوة {variable}",
		COMPUTED_FIELD_INVALID_TARGET:
			"الحقل {variable} يشير إلى هدف غير صالح ({variable})",
		COMPUTED_FIELD_CONFLICT:
			"لا يمكن أن يكون الحقل {variable} محسوبًا ومطلوبًا/فريدًا/بنمط في نفس الوقت",
		COMPUTED_FIELD_CYCLE: "الحقول المحسوبة تشكل دورة: {variable}",
		COMPUTED_FIELD_SETTABLE: "الحقل {variable} محسوب ولا يمكن تعيينه مباشرة",
		COMPUTED_FIELD_DANGLING_LINK:
			"الحقل المحسوب {variable} يشير إلى صف غير موجود في الجدول {variable}",
		COMPUTED_FIELD_ARITHMETIC:
			"فشل تقييم الحقل المحسوب {variable} ({variable})",
		UPDATE_LOG_CORRUPT:
			"سجل التحديثات للجدول {variable} تالف ويحتاج إلى استرداد يدوي",
		UPDATE_LOG_FRAME_TOO_LARGE:
			"إطار سجل التحديثات للجدول {variable} يتجاوز الحجم الأقصى للإطار",
		MAINTENANCE_REQUIRED:
			"يحتاج الجدول {variable} إلى ضغط قبل أن يتمكن من قبول المزيد من الكتابات",
		UNSUPPORTED_FORMAT: "تنسيق قاعدة بيانات غير مدعوم (يتطلب {variable})",
	},
	fr: {
		TABLE_EMPTY: "La table {variable} est vide",
		TABLE_EXISTS: "La table {variable} existe déjà",
		TABLE_NOT_EXISTS: "La table {variable} n'existe pas",
		NO_SCHEMA: "La table {variable} n'a pas de schéma",
		GROUP_UNIQUE:
			"Le groupe {variable} doit être unique, contenu dupliqué trouvé dans {variable}",
		FIELD_UNIQUE:
			"Le champ {variable} doit être unique, trouvé {variable} à la place",
		FIELD_REQUIRED: "Le champ {variable} est obligatoire",
		INVALID_ID: "Le(s) ID donné(s) n'est/ne sont pas valide(s)",
		INVALID_TYPE:
			"Attendu que {variable} soit de type {variable}, mais trouvé {variable} à la place",
		INVALID_PARAMETERS: "Les paramètres donnés ne sont pas valides",
		INVALID_REGEX_MATCH:
			"Le champ {variable} ne correspond pas au modèle attendu",
		INVALID_NAME: "Le nom {variable} n'est pas valide",
		NO_ENV: "Aucun fichier d'environnement trouvé",
		COMPUTED_FIELD_SYNTAX:
			"Syntaxe d'expression calculée invalide pour le champ {variable}",
		COMPUTED_FIELD_UNKNOWN_FIELD:
			"Le champ {variable} référence un identifiant de champ inconnu {variable}",
		COMPUTED_FIELD_INVALID_LINK:
			"Le champ {variable} possède un lien invalide à l'étape {variable}",
		COMPUTED_FIELD_INVALID_TARGET:
			"Le champ {variable} référence une cible invalide ({variable})",
		COMPUTED_FIELD_CONFLICT:
			"Le champ {variable} ne peut pas être calculé et requis/unique/regex à la fois",
		COMPUTED_FIELD_CYCLE: "Les champs calculés forment un cycle : {variable}",
		COMPUTED_FIELD_SETTABLE:
			"Le champ {variable} est calculé et ne peut pas être défini directement",
		COMPUTED_FIELD_DANGLING_LINK:
			"Le champ calculé {variable} référence une ligne manquante dans la table {variable}",
		COMPUTED_FIELD_ARITHMETIC:
			"L'évaluation du champ calculé {variable} a échoué ({variable})",
		UPDATE_LOG_CORRUPT:
			"Le journal de mises à jour de la table {variable} est corrompu et nécessite une récupération manuelle",
		UPDATE_LOG_FRAME_TOO_LARGE:
			"Une trame du journal de mises à jour de la table {variable} dépasse la taille maximale",
		MAINTENANCE_REQUIRED:
			"La table {variable} doit être compactée avant de pouvoir accepter d'autres écritures",
		UNSUPPORTED_FORMAT:
			"Format de base de données non pris en charge (nécessite {variable})",
	},
	es: {
		TABLE_EMPTY: "La tabla {variable} está vacía",
		TABLE_EXISTS: "La tabla {variable} ya existe",
		TABLE_NOT_EXISTS: "La tabla {variable} no existe",
		NO_SCHEMA: "La tabla {variable} no tiene un esquema",
		GROUP_UNIQUE:
			"El grupo {variable} debe ser único, se encontró contenido duplicado en {variable}",
		FIELD_UNIQUE:
			"El campo {variable} debe ser único, se encontró {variable} en su lugar",
		FIELD_REQUIRED: "El campo {variable} es obligatorio",
		INVALID_ID: "El/los ID proporcionado(s) no es/son válido(s)",
		INVALID_TYPE:
			"Se espera que {variable} sea {variable}, pero se encontró {variable} en su lugar",
		INVALID_PARAMETERS: "Los parámetros proporcionados no son válidos",
		INVALID_REGEX_MATCH:
			"El campo {variable} no coincide con el patrón esperado",
		INVALID_NAME: "El nombre {variable} no es válido",
		NO_ENV: "No se encontró el archivo de entorno",
		COMPUTED_FIELD_SYNTAX:
			"Sintaxis de expresión calculada no válida en el campo {variable}",
		COMPUTED_FIELD_UNKNOWN_FIELD:
			"El campo {variable} referencia un id de campo desconocido {variable}",
		COMPUTED_FIELD_INVALID_LINK:
			"El campo {variable} tiene un enlace no válido en el paso {variable}",
		COMPUTED_FIELD_INVALID_TARGET:
			"El campo {variable} referencia un destino no válido ({variable})",
		COMPUTED_FIELD_CONFLICT:
			"El campo {variable} no puede ser calculado y requerido/único/regex a la vez",
		COMPUTED_FIELD_CYCLE: "Los campos calculados forman un ciclo: {variable}",
		COMPUTED_FIELD_SETTABLE:
			"El campo {variable} es calculado y no puede establecerse directamente",
		COMPUTED_FIELD_DANGLING_LINK:
			"El campo calculado {variable} referencia una fila inexistente en la tabla {variable}",
		COMPUTED_FIELD_ARITHMETIC:
			"Falló la evaluación del campo calculado {variable} ({variable})",
		UPDATE_LOG_CORRUPT:
			"El registro de actualizaciones de la tabla {variable} está corrupto y necesita recuperación manual",
		UPDATE_LOG_FRAME_TOO_LARGE:
			"Un marco del registro de actualizaciones de la tabla {variable} supera el tamaño máximo",
		MAINTENANCE_REQUIRED:
			"La tabla {variable} necesita compactarse antes de aceptar más escrituras",
		UNSUPPORTED_FORMAT:
			"Formato de base de datos no compatible (requiere {variable})",
	},
};

/**
 * Creates a translated error exactly like the ones thrown by Inibase methods.
 *
 * @param language - The language to render the error message in.
 * @param name - The error code, also used as the error `name`.
 * @param variable - Optional value(s) used to fill the `{variable}` placeholders.
 * @returns An `Error` whose `name` is the error code and `message` is translated.
 */
export const createError = (
	language: ErrorLang,
	name: ErrorCode,
	variable?: string | number | (string | number)[],
): Error => {
	const errorMessage = ERROR_MESSAGES[language]?.[name];
	if (!errorMessage) return new Error("ERR");
	const error = new Error(
		variable
			? Array.isArray(variable)
				? errorMessage.replace(
						/\{variable\}/g,
						() => variable.shift()?.toString() ?? "",
					)
				: errorMessage.replaceAll("{variable}", `'${variable.toString()}'`)
			: errorMessage.replaceAll("{variable}", ""),
	);
	error.name = name;
	return error;
};

/**
 * Validates that a string is a safe name for a table, database or column.
 *
 * Instead of whitelisting allowed characters, this uses a blacklist that blocks
 * only characters known to cause problems with shell commands, filesystem
 * paths, or injection attacks. All Unicode letters (Latin, Arabic, Chinese,
 * etc.), digits, underscores, hyphens, spaces and forward slashes are allowed.
 *
 * Blocked characters: null bytes, control characters, `\`, `;`, `|`, `&`,
 * `<`, `>`, `$`, backtick, `!`, `'`, `"`, `{`, `}`, `(`, `)`, `~`, and `.`
 * (reserved as column-path separator).  Forward slash (`/`) is intentionally
 * allowed so that nested table names like `"user/logs"` work.
 *
 * Leading or trailing spaces are not allowed.
 *
 * @param input - The value to be checked.
 * @returns boolean - True if the name is safe to use, false otherwise.
 */
export const isValidName = (input: unknown): input is string =>
	typeof input === "string" &&
	input.length > 0 &&
	input.length <= 255 &&
	validNamePattern.test(input);

// Forbidden characters: control chars, path separators, shell metacharacters,
// quoting, grouping, history expansion, home-dir expansion and dot (reserved
// as column-path separator).  The forward slash (/) is intentionally allowed
// so that nested table names like "user/logs" work.
const nameForbiddenChars = "\\x00-\\x1F\\x7F.\\\\;|&<>$`!'\\" + "{}()~";

// Names must be 1-255 chars, start/end with a non-forbidden non-whitespace
// character, and contain no forbidden characters in between.
const validNamePattern = new RegExp(
	`^[^${nameForbiddenChars}\\s\\p{Z}\\p{Cf}][^${nameForbiddenChars}\\p{Cf}]*[^${nameForbiddenChars}\\s\\p{Z}\\p{Cf}]$|^[^${nameForbiddenChars}\\s\\p{Z}\\p{Cf}]$`,
	"u",
);

/**
 * Validates that a string is a safe name for a table, database or column and
 * throws a translated `INVALID_NAME` error if it is not.
 *
 * @param name - The name to validate.
 * @param language - The language to render the error message in.
 * @throws {Error} If the name is not a safe name.
 */
export const validateName = (
	name: string,
	language: ErrorLang = "en",
): void => {
	if (!isValidName(name)) throw createError(language, "INVALID_NAME", name);
};

/**
 * Recursively validates every field key of a schema.
 *
 * @param schema - The schema to validate.
 * @param language - The language to render the error message in.
 * @throws {Error} If any field key is not a safe name.
 */
export const validateSchema = (
	schema: Schema,
	language: ErrorLang = "en",
): void => {
	for (const field of schema) {
		validateName(field.key, language);
		if (field.table) validateName(field.table, language);
		if (typeof field.computed !== "undefined") {
			const computed = field.computed;
			const isValidForm =
				typeof computed === "string"
					? computed.length > 0 && computed.length <= COMPUTED_EXPR_MAX_LENGTH
					: typeof computed === "object" &&
						computed !== null &&
						typeof computed.expr === "string" &&
						typeof computed.ast === "object" &&
						computed.expr.length > 0 &&
						computed.expr.length <= COMPUTED_EXPR_MAX_LENGTH;
			if (!isValidForm)
				throw createError(language, "COMPUTED_FIELD_SYNTAX", field.key);
			if (
				field.required !== undefined ||
				field.unique !== undefined ||
				field.regex !== undefined
			)
				throw createError(language, "COMPUTED_FIELD_CONFLICT", field.key);
		}
		if (field.children && isArrayOfObjects(field.children))
			validateSchema(field.children, language);
	}
};
